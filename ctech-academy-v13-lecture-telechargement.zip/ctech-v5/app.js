/* C-TECH Academy — interface vanilla JS + Supabase (v2).
   Deux modes : démonstration (données en mémoire) et Supabase (données réelles, correction côté serveur). */
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const cfg = window.CTECH_CONFIG || {};
const STUDENT_DOMAIN = cfg.STUDENT_EMAIL_DOMAIN || 'students.ctech.cg';
const hasSupabase = !!(window.supabase && /^https:\/\//.test(cfg.SUPABASE_URL || '') && !String(cfg.SUPABASE_URL).includes('VOTRE-PROJET') && cfg.SUPABASE_ANON_KEY && !String(cfg.SUPABASE_ANON_KEY).includes('VOTRE_CLE'));
const sb = hasSupabase ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY) : null;
if (sb && window.CTECHExam) { window.CTECHExam.configure(sb); window.CTECHExam.onExit = () => { reload(false).then(() => navigate('assessments')); }; window.CTECHExam.onSubmitted = showExamFeedback; }

/* ---------- Utilitaires ---------- */
const esc = (s = '') => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const initials = (n = 'Utilisateur') => n.split(' ').filter(Boolean).slice(0, 2).map(x => x[0]).join('').toUpperCase();
function setAvatar(el, url, name) {
  if (!el) return;
  const fallback = initials(name || 'Utilisateur');
  el.replaceChildren(); el.classList.remove('has-photo');
  if (!url) { el.textContent = fallback; return; }
  const img = document.createElement('img');
  img.alt = `Photo de ${name || 'Utilisateur'}`; img.loading = 'eager'; img.decoding = 'async';
  img.src = `${url}${String(url).includes('?') ? '&' : '?'}v=${Date.now()}`;
  img.onerror = () => { el.replaceChildren(document.createTextNode(fallback)); el.classList.remove('has-photo'); };
  img.onload = () => el.classList.add('has-photo');
  el.appendChild(img);
}
const fmtDate = v => new Date(v).toLocaleString('fr-FR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
const fmtDay = v => new Date(v).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' });
const todayLabel = () => new Date().toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
const roleName = r => ({ admin:'Administrateur', teacher:'Formateur', student:'Étudiant' })[r] || 'Étudiant';
const isStaff = () => S.role === 'admin' || S.role === 'teacher';
const num = v => Number(String(v).replace(',', '.'));
function toast(msg) { const el = $('#toast'); el.textContent = msg; el.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove('show'), 3200); }
function at(day, hour) { const d = new Date(); d.setDate(d.getDate() + day); d.setHours(hour, 0, 0, 0); return d.toISOString(); }
const unwrap = ({ data, error }) => { if (error) throw new Error(error.message); return data; };
const bySort = (a, b) => (a.position ?? 0) - (b.position ?? 0);
function statusFor(a) { const n = Date.now(); return n < new Date(a.start_at) ? 'À venir' : n > new Date(a.end_at) ? 'Terminé' : 'En cours'; }
const statusClass = s => s === 'En cours' ? 'green' : s === 'Terminé' ? 'gray' : '';
const TYPE_LABEL = { mcq: 'QCM', true_false: 'Vrai/Faux', short_answer: 'Réponse courte' };

/* ---------- État ---------- */
const S = { user: null, role: 'student', demo: false, page: 'dashboard', courseId: null, assessmentId: null, chapterId: null };
let D = { courses: [], assessments: [], students: [], results: [] };
S.notifications = []; S.history = []; S.academicYear = null; let notificationChannel = null;
let exam = null;

/* Progression de lecture (par utilisateur, stockée dans le navigateur). */
const readKey = () => 'ctech:read:' + (S.user?.id || 'demo');
const readSet = () => { try { return new Set(JSON.parse(localStorage.getItem(readKey()) || '[]')); } catch { return new Set(); } };
const writeSet = s => { try { localStorage.setItem(readKey(), JSON.stringify([...s])); } catch { /* stockage indisponible */ } };
function courseProgress(c) {
  const ids = c.modules.flatMap(m => m.chapters.map(x => x.id)); if (!ids.length) return { total: 0, done: 0, pct: 0 };
  const r = readSet(); const done = ids.filter(i => r.has(i)).length; return { total: ids.length, done, pct: Math.round(done / ids.length * 100) };
}

/* ====================================================================
   COUCHE DONNÉES — mode démonstration
   ==================================================================== */
let uid = 100; const nid = () => 'd' + (uid++);
const demoStore = {
  courses: [
    { id: 'c1', title: 'Informatique générale', code: 'INF-101', description: 'Les fondamentaux de l’informatique, du matériel et des logiciels.', is_published: true, files: [], modules: [
      { id: 'm1', title: 'Module 1 — Découvrir l’ordinateur', position: 1, chapters: [
        { id: 'ch1', title: 'Qu’est-ce qu’un ordinateur ?', position: 1, content: 'Un ordinateur est une machine programmable qui traite des informations.\n\nIl reçoit des données (entrée), les traite grâce au processeur (CPU), les conserve (mémoire, stockage) et produit un résultat (sortie).' },
        { id: 'ch2', title: 'Matériel et logiciel', position: 2, content: 'Le matériel (hardware) regroupe les composants physiques : processeur, RAM, disque dur ou SSD, carte mère, périphériques.\n\nLe logiciel (software) regroupe les programmes : système d’exploitation, applications, pilotes.' }] },
      { id: 'm2', title: 'Module 2 — Systèmes d’exploitation', position: 2, chapters: [
        { id: 'ch3', title: 'Rôle d’un système d’exploitation', position: 1, content: 'Le système d’exploitation (Windows, Linux, macOS, Android) gère les ressources de la machine et fait le lien entre le matériel et les applications.' }] }] },
    { id: 'c2', title: 'Culture numérique', code: 'NUM-102', description: 'Environnement numérique et bonnes pratiques.', is_published: true, files: [], modules: [
      { id: 'm3', title: 'Module 1 — Bonnes pratiques', position: 1, chapters: [
        { id: 'ch4', title: 'Mots de passe et sécurité', position: 1, content: 'Utilisez des mots de passe longs et uniques, activez la double authentification et méfiez-vous des liens suspects (hameçonnage).' }] }] }
  ],
  assessments: [
    { id: 'a1', course_id: 'c1', title: 'Les composants de l’ordinateur', description: 'Évaluation sur les composants matériels et leurs fonctions.', start_at: at(-1, 6), end_at: at(1, 22), duration_minutes: 20, max_attempts: 2, points: 20, is_published: true },
    { id: 'a2', course_id: 'c1', title: 'Systèmes d’exploitation', description: 'Notions essentielles sur les systèmes d’exploitation.', start_at: at(2, 9), end_at: at(2, 11), duration_minutes: 15, max_attempts: 1, points: 20, is_published: true },
    { id: 'a3', course_id: 'c2', title: 'Évaluation diagnostique', description: 'Évaluation terminée.', start_at: at(-2, 8), end_at: at(-2, 10), duration_minutes: 15, max_attempts: 1, points: 20, is_published: true }
  ],
  questions: {
    a1: [
      { id: 'q1', prompt: 'Quel composant est considéré comme le cerveau de l’ordinateur ?', type: 'mcq', options: ['La mémoire RAM', 'Le processeur (CPU)', 'Le disque dur', 'La carte graphique'], correct: 1, points: 4 },
      { id: 'q2', prompt: 'La RAM conserve les données même lorsque l’ordinateur est éteint.', type: 'true_false', options: ['Vrai', 'Faux'], correct: 1, points: 4 },
      { id: 'q3', prompt: 'Quel périphérique permet de saisir du texte ?', type: 'mcq', options: ['Écran', 'Imprimante', 'Clavier', 'Haut-parleur'], correct: 2, points: 4 },
      { id: 'q4', prompt: 'Que signifie CPU ? (en anglais)', type: 'short_answer', options: [], accepted: ['central processing unit'], points: 4 },
      { id: 'q5', prompt: 'Un SSD est généralement plus rapide qu’un disque dur HDD.', type: 'true_false', options: ['Vrai', 'Faux'], correct: 0, points: 4 }
    ], a2: [], a3: []
  },
  students: [
    { id: 'ICT12141110', name: 'Grâce Mavoungou', class: 'L1 Informatique', active: true },
    { id: 'ICT12141111', name: 'Patrick Ngoma', class: 'L1 Informatique', active: true },
    { id: 'ICT12141112', name: 'Sarah Makosso', class: 'L1 Informatique', active: true }
  ],
  results: [
    { id: 'r1', name: 'Grâce Mavoungou', exam: 'Évaluation diagnostique', score: 16, max: 20, date: at(-2, 9) },
    { id: 'r2', name: 'Patrick Ngoma', exam: 'Évaluation diagnostique', score: 13, max: 20, date: at(-2, 9) },
    { id: 'r3', name: 'Sarah Makosso', exam: 'Évaluation diagnostique', score: 18, max: 20, date: at(-2, 9) }
  ],
  attempts: {}, targets: {}
};
const demoBlobs = {};
const courseTitle = id => (D.courses.find(c => c.id === id) || {}).title || '—';

const demoApi = {
  async load() {
    const st = structuredClone(demoStore);
    return {
      courses: st.courses.map(c => ({ ...c, modules: c.modules.sort(bySort).map(m => ({ ...m, chapters: m.chapters.sort(bySort) })) })),
      assessments: st.assessments.map(a => ({ ...a, questions_count: (st.questions[a.id] || []).length })),
      students: st.students,
      results: S.role === 'student' ? st.results.filter(r => r.name === S.user.name) : st.results
    };
  },
  async createCourse(c) { demoStore.courses.push({ id: nid(), ...c, modules: [], files: [] }); },
  async importStructure(courseId, modules) {
    const c = demoStore.courses.find(x => x.id === courseId);
    modules.forEach(m => c.modules.push({ id: nid(), title: m.title, position: c.modules.length + 1, chapters: m.chapters.map((ch, i) => ({ id: nid(), title: ch.title, content: ch.content, position: i + 1 })) }));
  },
  async attachFile(courseId, file) { const id = nid(); demoBlobs[id] = file; demoStore.courses.find(c => c.id === courseId).files.push({ id, name: file.name, size: file.size }); },
  async fileUrl(f) { return URL.createObjectURL(demoBlobs[f.id]); },
  async deleteFile(courseId, f) { const c = demoStore.courses.find(x => x.id === courseId); c.files = c.files.filter(x => x.id !== f.id); delete demoBlobs[f.id]; },
  async setCoursePublished(id, v) { demoStore.courses.find(c => c.id === id).is_published = v; },
  async addModule(courseId, title) { const c = demoStore.courses.find(x => x.id === courseId); c.modules.push({ id: nid(), title, position: c.modules.length + 1, chapters: [] }); },
  async addChapter(moduleId, title, content) { const m = demoStore.courses.flatMap(c => c.modules).find(x => x.id === moduleId); m.chapters.push({ id: nid(), title, content, position: m.chapters.length + 1 }); },
  async createAssessment(a) { const x = { id: nid(), is_published: false, ...a }; demoStore.assessments.unshift(x); demoStore.questions[x.id] = []; return x; },
  async saveAssessmentTargets(id,t){demoStore.targets[id]=structuredClone(t);},
  async getAssessmentTargets(id){return demoStore.targets[id]||null;},
  async updateAssessment(id,a){const x=demoStore.assessments.find(z=>z.id===id);Object.assign(x,a);demoStore.targets[id]=structuredClone(a.target);},
  async deleteAssessment(id){demoStore.assessments=demoStore.assessments.filter(x=>x.id!==id);delete demoStore.questions[id];delete demoStore.targets[id];},
  async setAssessmentPublished(id, v) { demoStore.assessments.find(a => a.id === id).is_published = v; },
  async reopenAssessment(id,start,end) { const a=demoStore.assessments.find(x=>x.id===id); a.start_at=start; a.end_at=end; a.max_attempts=(a.max_attempts||1)+1; a.is_published=true; },
  async listQuestions(aid) {
    const rows = unwrap(await sb.from('questions').select('id,prompt,question_type,options,points,position,correct_answer,accepted_answers').eq('assessment_id', aid).order('position'));
    return rows.map(r => ({id:r.id,prompt:r.prompt,type:r.question_type,options:r.options||[],points:Number(r.points),correct:r.correct_answer,accepted:r.accepted_answers||[]}));
  },
  async addQuestion(aid,q) {
    const n=(await this.listQuestions(aid)).length+1;
    unwrap(await sb.from('questions').insert({assessment_id:aid,prompt:q.prompt,question_type:q.type,options:q.options,points:q.points,position:n,correct_answer:q.correct??null,accepted_answers:q.accepted||[]}));
  },
  async deleteQuestion(aid, qid) { demoStore.questions[aid] = (demoStore.questions[aid] || []).filter(q => q.id !== qid); },
  async createStudent(s) { demoStore.students.push({ id: s.student_code, name: s.full_name, class: s.class_name, active: true }); },
  async startAttempt(aid) {
    const a = demoStore.assessments.find(x => x.id === aid), list = demoStore.attempts[aid] ||= [];
    const open = list.find(t => !t.done && t.deadline > Date.now()); if (open) return open;
    if (list.length >= a.max_attempts) throw new Error('Nombre maximal de tentatives atteint');
    const t = { id: nid(), aid, deadline: Math.min(Date.now() + a.duration_minutes * 60000, new Date(a.end_at).getTime()), answers: {}, done: false };
    list.push(t); return t;
  },
  async getQuestions(t) { return demoStore.questions[t.aid].map(({ correct, accepted, ...q }) => ({ ...q, answer: t.answers[q.id] ?? null })); },
  async saveAnswer(t, qid, val) { t.answers[qid] = val; },
  async submit(t) {
    const a = demoStore.assessments.find(x => x.id === t.aid), qs = demoStore.questions[t.aid]; let got = 0, total = 0;
    qs.forEach(q => { total += q.points; const v = t.answers[q.id];
      if (q.type === 'short_answer' ? (q.accepted || []).some(x => x.trim().toLowerCase() === String(v ?? '').trim().toLowerCase()) : v === q.correct) got += q.points; });
    t.done = true; const score = total ? Math.round(got / total * a.points * 100) / 100 : 0;
    demoStore.results.unshift({ id: nid(), name: S.user.name, exam: a.title, score, max: a.points, date: new Date().toISOString() });
    return { score, max: a.points };
  }
};

/* ====================================================================
   COUCHE DONNÉES — Supabase
   ==================================================================== */
const sbApi = {
  async load() {
    const [courseRows, assessmentRows, resultRows, allowedRows, historyRows, yearRows, fileRows] = await Promise.all([
      sb.from('courses').select('*, modules(*, lessons(*))').order('created_at').then(unwrap),
      sb.from('assessments').select('*').order('starts_at', { ascending: false }).then(unwrap),
      (isStaff()?sb.from('results').select('id,score,total_points,published_at,student_id,assessment_id,grading_status').order('published_at',{ascending:false}):sb.from('results').select('id,score,total_points,published_at,student_id,assessment_id,grading_status').not('published_at','is',null).order('published_at',{ascending:false})).then(unwrap),
      isStaff()?Promise.resolve([]):sb.rpc('student_list_assessment_ids').then(unwrap),
      sb.rpc('student_assessment_history').then(unwrap),
      sb.from('academic_settings').select('academic_year').eq('id',true).maybeSingle().then(unwrap),
      sb.from('course_files').select('id,course_id,name,path,size,mime').order('created_at').then(unwrap)
    ]);
    S.history = historyRows || []; S.academicYear = yearRows?.academic_year || null;
    const students = isStaff() ? await sb.from('profiles').select('id,full_name,matricule,username,is_active,level_code,academic_year').eq('role', 'student').order('full_name').then(unwrap) : [];
    const courses = courseRows.map(c => ({ ...c, code: c.subject_id ? 'Matière' : '—', files: (fileRows||[]).filter(f=>f.course_id===c.id), modules: (c.modules || []).sort(bySort).map(m => ({ ...m, chapters: (m.lessons || []).sort(bySort).map(l => ({ ...l, content: l.content || '' })) })) }));
    const qCounts = await sb.from('questions').select('assessment_id').then(unwrap); const countMap = qCounts.reduce((m,q)=>(m[q.assessment_id]=(m[q.assessment_id]||0)+1,m),{});
    const allowedTargetIds=new Set(allowedRows.map(t=>t.assessment_id));
    const assessments = assessmentRows.filter(a=>isStaff()||allowedTargetIds.has(a.id)).map(a => ({ ...a, course_id: a.course_id, start_at: a.starts_at, end_at: a.ends_at, points: Number(a.total_points || 20), description: a.instructions, assessment_type:a.assessment_type||'DST1', is_published: ['published','scheduled'].includes(a.status), questions_count: countMap[a.id] || 0 }));
    const studentIds=[...new Set(resultRows.map(r=>r.student_id).filter(Boolean))], assessmentIds=[...new Set(resultRows.map(r=>r.assessment_id).filter(Boolean))];
    const [studentRows, resultAssessments]=await Promise.all([studentIds.length?sb.from('profiles').select('id,full_name').in('id',studentIds).then(unwrap):[],assessmentIds.length?sb.from('assessments').select('id,title,course_id,assessment_type').in('id',assessmentIds).then(unwrap):[]]);
    const studentMap=Object.fromEntries(studentRows.map(x=>[x.id,x.full_name])), assessmentMap=Object.fromEntries(resultAssessments.map(x=>[x.id,x]));
    const results = resultRows.map(r => { const a=assessmentMap[r.assessment_id]||{}; return { id:r.id, student_id:r.student_id, course_id:a.course_id, assessment_type:a.assessment_type, name:studentMap[r.student_id]||'', exam:a.title||'', score:Number(r.score??0), max:Number(r.total_points??20), date:r.published_at, grading_status:r.grading_status }; });
    return { courses, assessments, students: students.map(p => ({ id: p.matricule || p.username || '—', name: p.full_name, class: [p.level_code,p.academic_year].filter(Boolean).join(' · ') || '—', active: p.is_active })), results };
  },
  async createCourse(c) {
    // Un cours correspond à une matière. Le RPC crée/réutilise le sujet
    // technique puis rattache directement le cours au formateur choisi.
    unwrap(await sb.rpc('create_course_from_subject_name', {
      p_title: c.title,
      p_class_id: c.class_id || null,
      p_teacher_id: c.teacher_id || null,
      p_description: c.description || null,
      p_is_published: !!c.is_published
    }));
  },
  async importStructure(courseId, modules) {
    const base = D.courses.find(c => c.id === courseId).modules.length;
    const created = unwrap(await sb.from('modules').insert(modules.map((m, i) => ({ course_id: courseId, title: m.title, position: base + i + 1 }))).select('id,position')).sort(bySort);
    const rows = []; created.forEach((mod, i) => modules[i].chapters.forEach((ch, j) => rows.push({ module_id: mod.id, title: ch.title, content: ch.content, position: j + 1 })));
    if (rows.length) { const { error } = await sb.from('lessons').insert(rows); if (error) { await sb.from('modules').delete().in('id', created.map(x => x.id)); throw new Error(error.message); } }
  },
  async attachFile(courseId, file) {
    const safe = file.name.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z0-9._-]+/g, '_').slice(-80);
    const path = `${courseId}/${crypto.randomUUID()}-${safe}`;
    const up = await sb.storage.from('course-files').upload(path, file, { contentType: file.type || undefined }); if (up.error) throw new Error(up.error.message);
    const { error } = await sb.from('course_files').insert({ course_id: courseId, name: file.name, path, size: file.size, mime: file.type || null, created_by: S.user.id });
    if (error) { await sb.storage.from('course-files').remove([path]); throw new Error(error.message); }
  },
  async fileUrl(f, download = false) { const options = download ? { download: f.name } : {}; const { data, error } = await sb.storage.from('course-files').createSignedUrl(f.path, 900, options); if (error) throw new Error(error.message); return data.signedUrl; },
  async deleteFile(courseId, f) { await sb.storage.from('course-files').remove([f.path]); unwrap(await sb.from('course_files').delete().eq('id', f.id)); },
  async setCoursePublished(id, v) { unwrap(await sb.from('courses').update({ is_published: v }).eq('id', id)); },
  async addModule(courseId, title) { const n = D.courses.find(c => c.id === courseId).modules.length + 1; unwrap(await sb.from('modules').insert({ course_id: courseId, title, position: n })); },
  async addChapter(moduleId, title, content) { const m = D.courses.flatMap(c => c.modules).find(x => x.id === moduleId); unwrap(await sb.from('lessons').insert({ module_id: moduleId, title, content, position: m.chapters.length + 1 })); },
  async createAssessment(a) {
    return unwrap(await sb.from('assessments').insert({ course_id: a.course_id, title: a.title, instructions: a.description, starts_at: a.start_at, ends_at: a.end_at,
      duration_minutes: a.duration_minutes, max_attempts: a.max_attempts, total_points: a.points, assessment_type:a.assessment_type||'DST1', status: 'draft', results_visible: false, delivery_mode: 'classic', shuffle_questions: true, shuffle_options: true, created_by: S.user.id }).select().single());
  },
  async saveAssessmentTargets(id, target) {
    unwrap(await sb.from('assessment_targets').upsert({assessment_id:id,domain_ids:target.domain_ids,filiere_ids:target.filiere_ids,level_codes:target.level_codes,updated_at:new Date().toISOString()}));
  },
  async updateAssessment(id, a) {
    unwrap(await sb.from('assessments').update({course_id:a.course_id,title:a.title,instructions:a.description,starts_at:a.start_at,ends_at:a.end_at,duration_minutes:a.duration_minutes,max_attempts:a.max_attempts,total_points:a.points,assessment_type:a.assessment_type}).eq('id',id));
    await this.saveAssessmentTargets(id,a.target);
  },
  async deleteAssessment(id) {
    const {count,error}=await sb.from('attempts').select('id',{count:'exact',head:true}).eq('assessment_id',id); if(error)throw new Error(error.message);
    if(count)throw new Error('Cette évaluation possède déjà des copies. Elle ne peut pas être supprimée pour préserver les résultats. Dépubliez-la plutôt.');
    unwrap(await sb.from('assessments').delete().eq('id',id));
  },
  async getAssessmentTargets(id) { const {data,error}=await sb.from('assessment_targets').select('*').eq('assessment_id',id).maybeSingle(); if(error)throw new Error(error.message); return data; },
  async setAssessmentPublished(id, v) { unwrap(await sb.from('assessments').update({ status: v ? 'published' : 'draft' }).eq('id', id)); },
  async reopenAssessment(id, start, end) { const a=D.assessments.find(x=>x.id===id); unwrap(await sb.from('assessments').update({starts_at:start,ends_at:end,status:'published',max_attempts:Number(a.max_attempts||1)+1,results_visible:false}).eq('id',id)); },
  async listQuestions(aid) {
    const rows = unwrap(await sb.from('questions').select('id,prompt,question_type,options,points,position,correct_answer,accepted_answers').eq('assessment_id', aid).order('position'));
    return rows.map(r => ({ id:r.id, prompt:r.prompt, type:r.question_type, options:r.options||[], points:Number(r.points), correct:r.correct_answer, accepted:r.accepted_answers||[] }));
  },
  async addQuestion(aid, q) {
    const n = (await this.listQuestions(aid)).length + 1;
    unwrap(await sb.from('questions').insert({ assessment_id:aid, prompt:q.prompt, question_type:q.type, options:q.options||[], points:q.points, position:n, correct_answer:q.correct??null, accepted_answers:q.accepted||[] }));
  },
  async updateQuestion(qid,q) { unwrap(await sb.from('questions').update({prompt:q.prompt,question_type:q.type,options:q.options||[],points:q.points,correct_answer:q.correct??null,accepted_answers:q.accepted||[]}).eq('id',qid)); },
  async deleteQuestion(aid, qid) { unwrap(await sb.from('questions').delete().eq('id', qid)); },
  async createStudent(s) {
    const { data, error } = await sb.functions.invoke('create-user', { body: { ...s, role: 'student' } });
    if (error) throw new Error((await error.context?.json?.().catch(() => null))?.error || error.message);
    if (data?.error) throw new Error(data.error);
  },
  async startAttempt(aid) { return unwrap(await sb.rpc('student_start_attempt', { p_assessment_id:aid })); },
  async getQuestions(t) { return t.questions || []; },
  async saveAnswer(t,qid,val) { return unwrap(await sb.rpc('student_save_answer',{p_attempt_id:t.attempt_id,p_question_id:qid,p_answer:val})); },
  async submit(t) { return unwrap(await sb.rpc('student_submit_attempt',{p_attempt_id:t.attempt_id})); }
};
const api = () => (S.demo ? demoApi : sbApi);

/* ===== Notifications persistantes Supabase ===== */
async function loadNotifications(){
 if(!sb || S.demo || !S.user?.id)return;
 const rows=unwrap(await sb.from('notifications').select('id,title,body,category,link_page,related_id,created_at,read_at').eq('recipient_id',S.user.id).order('created_at',{ascending:false}).limit(50));
 S.notifications=rows; const unread=rows.filter(x=>!x.read_at).length; const b=$('.notification-btn b'); if(b){b.textContent=unread>99?'99+':String(unread);b.classList.toggle('has-unread',unread>0);}
}
async function openNotifications(){
 if(S.demo){modal(`${mHead('Notifications')}<p class="muted">Les notifications persistantes sont disponibles après connexion.</p>`);return;}
 await loadNotifications();
 const rows=S.notifications.map(n=>`<button type="button" class="notification-item ${n.read_at?'':'unread'}" data-act="readNotification" data-id="${n.id}" data-page="${esc(n.link_page||'dashboard')}" data-related="${esc(n.related_id||'')}"><span class="notification-icon"><i class="fa-solid ${n.category==='assessment'?'fa-clipboard-check':n.category==='result'?'fa-award':n.category==='course'?'fa-book-open':'fa-bullhorn'}"></i></span><span><strong>${esc(n.title)}</strong><small>${esc(n.body)}</small><time>${fmtDate(n.created_at)}</time></span>${n.read_at?'':'<i class="fa-solid fa-circle unread-dot"></i>'}</button>`).join('');
 modal(`${mHead('Centre de notifications')}<div class="notification-list">${rows||empty('fa-bell','Aucune notification pour le moment.')}</div><div class="modal-actions"><button class="btn btn-light" data-act="markAllNotifications">Tout marquer comme lu</button><button class="btn btn-primary" data-act="closeModal">Fermer</button></div>`,'wide');
}
async function markNotification(id){unwrap(await sb.from('notifications').update({read_at:new Date().toISOString()}).eq('id',id).eq('recipient_id',S.user.id));await loadNotifications();}

/* ====================================================================
   AUTHENTIFICATION
   ==================================================================== */
function showAuth() { $('#authView').classList.remove('hidden'); $('#appView').classList.add('hidden'); }
async function showApp(user, role, demo) {
  Object.assign(S, { user, role, demo, page: 'dashboard', courseId: null, assessmentId: null });
  $('#authView').classList.add('hidden'); $('#appView').classList.remove('hidden');
  const name = user.name || user.email || 'Utilisateur';
  $('#sideName').textContent = name; $('#sideRole').textContent = roleName(role);
  setAvatar($('#sideAvatar'), user.avatar_url, name); setAvatar($('#topAvatar'), user.avatar_url, name); $('#todayLabel').textContent = todayLabel();
  $('#pageContent').innerHTML = '<p class="muted">Chargement…</p>';
  try { D = await api().load(); if(!demo) await loadNotifications(); } catch (e) { toast('Chargement impossible : ' + e.message); }
  if(!demo){ if(notificationChannel)sb.removeChannel(notificationChannel); notificationChannel=sb.channel('ctech-notifications-'+user.id).on('postgres_changes',{event:'INSERT',schema:'public',table:'notifications',filter:'recipient_id=eq.'+user.id},async()=>{await loadNotifications();toast('Vous avez une nouvelle notification.');}).subscribe(); }
  navigate('dashboard');
}
async function reload(keepPage = true) {
  try { D = await api().load(); if(!S.demo) await loadNotifications(); } catch (e) { toast('Actualisation impossible : ' + e.message); }
  if (keepPage) navigate(S.page);
}
function loginEmail(id) { id = id.trim(); return id.includes('@') ? id.toLowerCase() : `${id.toLowerCase()}@${STUDENT_DOMAIN}`; }
async function login(identifier, password) {
  if (!sb) { toast('Supabase n’est pas configuré. Utilisez la démonstration.'); return; }
  const { data, error } = await sb.auth.signInWithPassword({ email: loginEmail(identifier), password });
  if (error) { toast('Identifiants incorrects.'); return; }
  const p = await sb.from('profiles').select('*').eq('id', data.user.id).single();
  if (p.error || !p.data.is_active) { toast('Compte introuvable ou désactivé. Contactez l’administration.'); await sb.auth.signOut(); return; }
  await showApp({ name:p.data.full_name, email:data.user.email, id:data.user.id, avatar_url:p.data.avatar_url }, p.data.role, false);
}

/* ====================================================================
   NAVIGATION ET PAGES
   ==================================================================== */
const navItems = {
  student: [['PRINCIPAL', 'dashboard', 'Tableau de bord', 'fa-house'], ['APPRENTISSAGE', 'courses', 'Mes cours', 'fa-book-open'], ['ÉVALUATIONS', 'assessments', 'Mes évaluations', 'fa-clipboard-check'], ['RÉSULTATS', 'results', 'Mes résultats', 'fa-chart-column'], ['VIE DE CLASSE', 'maClasse', 'Ma classe', 'fa-people-group'], ['PROGRESSION', 'monEvolution', 'Mon évolution', 'fa-arrow-trend-up']],
  teacher: [['PÉDAGOGIE', 'dashboard', 'Tableau de bord', 'fa-house'], ['GESTION DES COURS', 'courses', 'Cours & modules', 'fa-book-open'], ['ÉVALUATIONS', 'assessments', 'Évaluations', 'fa-clipboard-check'], ['SUIVI', 'results', 'Résultats étudiants', 'fa-chart-column'], ['GESTION', 'students', 'Étudiants', 'fa-users'], ['VIE DE CLASSE', 'maClasse', 'Ma classe', 'fa-people-group'], ['PROGRESSION', 'monEvolution', 'Mon évolution', 'fa-arrow-trend-up']],
  admin: [['ADMINISTRATION', 'dashboard', 'Vue générale', 'fa-house'], ['PÉDAGOGIE', 'courses', 'Cours & matières', 'fa-book-open'], ['ÉVALUATIONS', 'assessments', 'Évaluations', 'fa-clipboard-check'], ['UTILISATEURS', 'students', 'Étudiants', 'fa-user-graduate'], ['UTILISATEURS', 'teachers', 'Formateurs', 'fa-chalkboard-user'], ['RÉSULTATS', 'results', 'Résultats', 'fa-chart-column'], ['VIE DE CLASSE', 'maClasse', 'Ma classe', 'fa-people-group'], ['PROGRESSION', 'monEvolution', 'Mon évolution', 'fa-arrow-trend-up']]
};
const navKey = p => ({ course: 'courses', assessment: 'assessments' })[p] || p;
function buildNav() {
  const items = [...navItems[S.role], ['COMPTE', 'profile', 'Mon Profil', 'fa-user-pen']]; let last = '';
  $('#sideNav').innerHTML = items.map(([cap, key, label, icon]) => {
    const head = cap !== last ? `<div class="nav-caption">${cap}</div>` : ''; last = cap;
    return `${head}<button class="nav-item ${navKey(S.page) === key ? 'active' : ''}" data-act="go" data-page="${key}"><i class="fa-solid ${icon}"></i>${label}</button>`;
  }).join('');
}
const CRUMBS = { maClasse: 'Ma classe', monEvolution: 'Mon évolution', professeur: 'Le Professeur', profile: 'Mon Profil', dashboard: 'Tableau de bord', courses: 'Cours & matières', course: 'Cours', assessments: 'Évaluations', assessment: 'Évaluation', results: 'Résultats', students: 'Étudiants' };
function navigate(page) {
  if (exam || window.CTECHExam?.isActive?.()) { toast('Terminez ou soumettez l’évaluation en cours.'); return; }
  if (page === 'students' && !isStaff()) page = 'dashboard';
  S.page = page; $('#crumb').textContent = CRUMBS[page] || 'Tableau de bord'; buildNav();
  const views = { maClasse: maClasseHTML, monEvolution: monEvolutionHTML, professeur: professeurHTML, profile: profileHTML, dashboard: dashboardHTML, courses: coursesHTML, course: courseHTML, assessments: assessmentsHTML, assessment: assessmentHTML, results: resultsHTML, students: studentsHTML, classes: classesHTML, teachers: teachersHTML, audit: auditHTML };
  const out = (views[page] || dashboardHTML)();
  if (out && typeof out.then === 'function') { $('#pageContent').innerHTML = '<p class="muted">Chargement…</p>'; out.then(h => { if (S.page === page) $('#pageContent').innerHTML = h; }).catch(e => toast(e.message)); }
  else $('#pageContent').innerHTML = out;
  $('#sidebar').classList.remove('open'); document.body.classList.remove('sidebar-open'); window.scrollTo(0, 0);
}
const pageHead = (title, desc, action = '') => `<div class="page-heading"><div><span class="eyebrow blue">ESPACE ${roleName(S.role).toUpperCase()}</span><h1>${title}</h1><p>${desc}</p></div>${action}</div>`;
const stat = (icon, value, label, color = '') => `<div class="stat-card"><div class="stat-icon ${color}"><i class="fa-solid ${icon}"></i></div><div><strong>${esc(value)}</strong><span>${esc(label)}</span></div></div>`;
const fmtSize = b => !b ? '' : b < 1048576 ? Math.max(1, Math.round(b / 1024)) + ' Ko' : (b / 1048576).toFixed(1) + ' Mo';
const empty = (icon, text) => `<div class="empty-state"><i class="fa-solid ${icon}"></i><p>${esc(text)}</p></div>`;
const pct = r => r.max ? Math.round(r.score / r.max * 100) : 0;

function dashboardHTML() {
  const visible = D.assessments.filter(a => isStaff() || a.is_published);
  const open = visible.filter(a => statusFor(a) !== 'Terminé');
  const avg = D.results.length ? (D.results.reduce((s, r) => s + pct(r), 0) / D.results.length) : null;
  const first = (S.user.name || '').split(' ')[0];
  return `${pageHead('Bonjour' + (first ? ', ' + esc(first) : '') + ' 👋', 'Voici un aperçu de votre activité pédagogique.', S.role==='admin'?`<div class="head-actions"><button class="btn btn-light" data-act="newAnnouncement"><i class="fa-solid fa-bullhorn"></i> Annoncer</button><button class="btn btn-primary" data-act="editAcademicYear"><i class="fa-solid fa-calendar-days"></i> Année : ${esc(S.academicYear||'À définir')}</button></div>`:`<span class="date-chip"><i class="fa-regular fa-calendar"></i> ${esc(S.academicYear||todayLabel())}</span>`)}
  <div class="hero-card"><div class="hero-text"><span class="eyebrow">INSTITUT CONGO TECHNOLOGIE · C-TECH</span><h2>${S.role === 'student' ? 'Votre réussite commence ici.' : 'Pilotez votre espace pédagogique.'}</h2><p>${S.role === 'student' ? 'Retrouvez vos cours et préparez vos prochaines évaluations.' : 'Gérez vos cours, planifiez vos examens et suivez les performances.'}</p></div><div class="hero-illustration"><i class="fa-solid fa-graduation-cap"></i></div></div>
  <div class="stat-grid">${stat('fa-book-open', D.courses.length, 'Cours disponibles')}${stat('fa-clipboard-check', visible.length, 'Évaluations')}${stat('fa-chart-line', avg === null ? '—' : Math.round(avg) + '%', S.role === 'student' ? 'Moyenne de mes résultats' : 'Taux moyen de réussite', 'green')}${stat('fa-clock', open.length, 'À venir / en cours', 'orange')}</div>
  <div class="content-grid"><div class="panel"><div class="panel-head"><h3>Évaluations à venir et en cours</h3><button data-act="go" data-page="assessments">Tout voir <i class="fa-solid fa-arrow-right"></i></button></div>${open.length ? open.slice(0, 5).map(assessmentRow).join('') : empty('fa-clipboard-check', 'Aucune évaluation à venir.')}</div>
  <div><div class="panel"><div class="panel-head"><h3>Mes cours</h3><button data-act="go" data-page="courses">Voir tout</button></div>${D.courses.length ? D.courses.slice(0, 4).map(courseMini).join('') : empty('fa-book-open', 'Aucun cours pour le moment.')}</div></div></div>`;
}
function assessmentRow(a) {
  const s = statusFor(a);
  return `<div class="assessment-row"><div class="assessment-symbol"><i class="fa-solid fa-file-circle-check"></i></div><div><strong>${esc(a.title)}</strong><small>${esc(courseTitle(a.course_id))} · ${a.duration_minutes} min · ${fmtDate(a.start_at)}</small></div><span class="status ${statusClass(s)}">${s}</span></div>`;
}
function courseMini(c) {
  const p = courseProgress(c);
  return `<div class="course-card clickable" data-act="openCourse" data-id="${esc(c.id)}" tabindex="0" role="button"><div class="course-art"><i class="fa-solid fa-laptop-code"></i></div><div style="flex:1"><strong>${esc(c.title)}</strong><p>${p.total} chapitre${p.total > 1 ? 's' : ''} · ${esc(c.code)}${c.is_published ? '' : ' · <b class="draft">Brouillon</b>'}</p><div class="progress"><span style="width:${p.pct}%"></span></div></div><span class="course-meta">${p.pct}%</span></div>`;
}

/* ----- Cours ----- */
function coursesHTML() {
  const list = D.courses.filter(c => isStaff() || c.is_published);
  return `${pageHead('Cours & matières', 'Explorez les enseignements mis à votre disposition.', isStaff() ? '<button class="btn btn-primary" data-act="newCourse"><i class="fa-solid fa-plus"></i> Ajouter un cours</button>' : '')}
  ${list.length ? `<div class="course-list">${list.map(courseMini).join('')}</div>` : empty('fa-book-open', isStaff() ? 'Créez votre premier cours.' : 'Aucun cours publié pour le moment.')}`;
}
function courseHTML() {
  const c = D.courses.find(x => x.id === S.courseId); if (!c) return coursesHTML();
  const read = readSet(), p = courseProgress(c), staff = isStaff();
  const chapters = c.modules.flatMap(m => m.chapters), cur = chapters.find(x => x.id === S.chapterId) || chapters[0];
  const modules = c.modules.map(m => `<div class="module-block"><div class="module-title"><strong>${esc(m.title)}</strong>${staff ? `<button class="link-btn" data-act="newChapter" data-id="${esc(m.id)}"><i class="fa-solid fa-plus"></i> Chapitre</button>` : ''}</div>
    ${m.chapters.length ? m.chapters.map(ch => `<button class="chapter-item ${cur && cur.id === ch.id ? 'active' : ''}" data-act="readChapter" data-id="${esc(ch.id)}"><i class="${read.has(ch.id) ? 'fa-solid fa-circle-check done' : 'fa-regular fa-circle'}"></i>${esc(ch.title)}</button>`).join('') : '<p class="muted small-note">Aucun chapitre.</p>'}</div>`).join('');
  const body = cur ? `<span class="eyebrow blue">CHAPITRE</span><h2>${esc(cur.title)}</h2><div class="chapter-body">${esc(cur.content || 'Contenu à venir.').split(/\n{2,}/).map(t => `<p>${t.replace(/\n/g, '<br>')}</p>`).join('')}</div>
    ${staff ? '' : `<button class="btn ${read.has(cur.id) ? 'btn-light' : 'btn-primary'} fit" data-act="toggleRead" data-id="${esc(cur.id)}">${read.has(cur.id) ? '<i class="fa-solid fa-rotate-left"></i> Marquer comme non lu' : '<i class="fa-solid fa-check"></i> Marquer comme lu'}</button>`}`
    : empty('fa-book', staff ? 'Ajoutez un module puis des chapitres, ou importez un support PDF / Word.' : 'Le contenu sera publié prochainement.');
  const files = c.files || [];
  const filesHTML = files.length ? `<div class="panel files-panel"><div class="panel-head"><h3>Supports de cours</h3><small class="muted">Lecture en ligne et téléchargement</small></div>${files.map(f => `<div class="file-row"><i class="fa-regular fa-file-lines"></i><span>${esc(f.name)}<small>${fmtSize(f.size)} · ${esc((f.name.split('.').pop()||'Fichier').toUpperCase())}</small></span><button class="btn btn-light fit" data-act="previewFile" data-id="${esc(f.id)}"><i class="fa-regular fa-eye"></i> Lire</button><button class="btn btn-primary fit" data-act="downloadFile" data-id="${esc(f.id)}"><i class="fa-solid fa-download"></i> Télécharger</button>${staff ? `<button class="icon-btn" aria-label="Supprimer le fichier" data-act="deleteFile" data-id="${esc(f.id)}"><i class="fa-regular fa-trash-can"></i></button>` : ''}</div>`).join('')}</div>` : '';
  const act = staff ? `<button class="btn btn-light" data-act="importCourse" data-id="${esc(c.id)}"><i class="fa-solid fa-file-import"></i> Importer un support</button><button class="btn btn-light" data-act="togglePublishCourse" data-id="${esc(c.id)}">${c.is_published ? 'Repasser en brouillon' : 'Publier le cours'}</button><button class="btn btn-primary" data-act="newModule" data-id="${esc(c.id)}"><i class="fa-solid fa-plus"></i> Module</button>` : '';
  return `<button class="back-link" data-act="go" data-page="courses"><i class="fa-solid fa-arrow-left"></i> Tous les cours</button>
  ${pageHead(esc(c.title), esc(c.description || '') + (c.is_published ? '' : ' — <b class="draft">Brouillon (invisible pour les étudiants)</b>'), `<div class="head-actions">${act}</div>`)}
  <div class="progress" style="height:7px;margin-bottom:6px"><span style="width:${p.pct}%"></span></div><p class="muted" style="font-size:11px;margin:0 0 18px">${p.done}/${p.total} chapitres lus · ${p.pct}%</p>
  ${filesHTML}<div class="course-layout"><aside class="panel module-list">${modules || empty('fa-layer-group', 'Aucun module.')}</aside><section class="panel chapter-view">${body}</section></div>`;
}

/* ----- Évaluations ----- */
function assessmentsHTML() {
  const list = D.assessments.filter(a => isStaff() || a.is_published);
  return `${pageHead(isStaff() ? 'Gestion des évaluations' : 'Mes évaluations', 'Les épreuves sont accessibles uniquement pendant la période définie par l’enseignant.', isStaff() ? '<button class="btn btn-primary" data-act="newAssessment"><i class="fa-solid fa-plus"></i> Programmer une évaluation</button>' : '')}
  <div class="toolbar"><div class="search-box"><i class="fa-solid fa-magnifying-glass"></i><input id="assessmentSearch" placeholder="Rechercher une évaluation..." aria-label="Rechercher"></div><select class="select-control" id="assessmentFilter" aria-label="Filtrer par statut"><option value="all">Tous les statuts</option><option>À venir</option><option>En cours</option><option>Terminé</option></select></div>
  <div class="assessment-grid" id="assessmentGrid">${list.length ? list.map(assessmentCard).join('') : empty('fa-clipboard-check', 'Aucune évaluation.')}</div>`;
}
function assessmentCard(a) {
  const s = statusFor(a), can = s === 'En cours' && !isStaff();
  const btn = isStaff() ? `<button class="btn btn-light" data-act="openAssessment" data-id="${esc(a.id)}">Gérer l’évaluation <i class="fa-solid fa-arrow-right"></i></button>`
    : `<button class="btn ${can ? 'btn-primary' : 'btn-light'}" data-act="start" data-id="${esc(a.id)}" ${can ? '' : 'disabled'}>${can ? 'Commencer l’évaluation' : s === 'À venir' ? 'Disponible le ' + fmtDate(a.start_at) : s === 'Terminé' ? 'Évaluation terminée' : 'Indisponible'}</button>`;
  return `<article class="assessment-card" data-title="${esc(a.title.toLowerCase())}" data-status="${s}"><div class="assessment-card-top"><span class="eyebrow blue">${esc(courseTitle(a.course_id))} · ${esc(a.assessment_type||'DST1')}</span><span class="status ${statusClass(s)}">${s}</span></div>
  <h3>${esc(a.title)}</h3><p class="eyebrow blue">${esc(a.assessment_type||'DST1')}</p><p>${esc(a.description || 'Évaluation pédagogique')}</p>${isStaff() && !a.is_published ? '<p><b class="draft">Brouillon — invisible pour les étudiants</b></p>' : ''}
  <div class="assessment-details"><span><i class="fa-regular fa-clock"></i>${a.duration_minutes} min</span><span><i class="fa-regular fa-circle-question"></i>${a.questions_count || 0} questions</span><span><i class="fa-solid fa-star"></i>${a.points || 20} points</span></div>${btn}</article>`;
}
async function assessmentHTML() {
  const a = D.assessments.find(x => x.id === S.assessmentId); if (!a) return assessmentsHTML();
  const qs = await api().listQuestions(a.id), s = statusFor(a), targetInfo = await api().getAssessmentTargets(a.id);
  const total = qs.reduce((t, q) => t + q.points, 0);
  const qlist = qs.map((q, i) => {
    const ans = q.type === 'short_answer' ? 'Correction manuelle' : 'Bonne réponse : ' + String(q.correct ?? '—');
    return `<div class="q-item"><div><span class="eyebrow blue">Q${i + 1} · ${TYPE_LABEL[q.type]} · ${q.points} pt${q.points > 1 ? 's' : ''}</span><strong>${esc(q.prompt)}</strong>${q.type === 'short_answer' ? '' : `<ol>${q.options.map(o => `<li>${esc(o)}</li>`).join('')}</ol>`}<small class="ok-answer">${esc(ans)}</small></div><div class="head-actions"><button class="icon-btn" title="Modifier" aria-label="Modifier la question" data-act="editQuestion" data-id="${esc(q.id)}"><i class="fa-solid fa-pen"></i></button><button class="icon-btn" title="Supprimer" aria-label="Supprimer la question" data-act="delQuestion" data-id="${esc(q.id)}"><i class="fa-regular fa-trash-can"></i></button></div></div>`;
  }).join('');
  return `<button class="back-link" data-act="go" data-page="assessments"><i class="fa-solid fa-arrow-left"></i> Toutes les évaluations</button>
  ${pageHead(esc(a.title), `${esc(a.assessment_type||'DST1')} · ${esc(courseTitle(a.course_id))} · ${fmtDate(a.start_at)} → ${fmtDate(a.end_at)} · ${a.duration_minutes} min · ${a.max_attempts ?? 1} tentative(s) · <span class="status ${statusClass(s)}">${s}</span>`,
    `<div class="head-actions"><button class="btn btn-light" data-act="editAssessment" data-id="${esc(a.id)}"><i class="fa-solid fa-pen"></i> Modifier</button>${s==='Terminé'?`<button class="btn btn-orange" data-act="reopenAssessment" data-id="${esc(a.id)}"><i class="fa-solid fa-rotate"></i> Relancer</button>`:''}<button class="btn ${a.is_published ? 'btn-light' : 'btn-orange'}" data-act="togglePublishAssessment" data-id="${esc(a.id)}">${a.is_published ? 'Dépublier' : 'Publier'}</button><button class="btn btn-light" data-act="deleteAssessment" data-id="${esc(a.id)}"><i class="fa-regular fa-trash-can"></i> Supprimer</button></div>`)}
  ${targetInfo?`<div class="panel assessment-target-summary"><div><span class="eyebrow blue">PUBLIC CIBLE</span><h3>Affectation pédagogique</h3><p>Domaines : ${targetInfo.domain_ids.length} · Filières : ${targetInfo.filiere_ids.length} · Niveaux : ${targetInfo.level_codes.map(esc).join(', ')}</p><small class="muted">Les trois critères doivent correspondre au profil de l’étudiant.</small></div></div>`:''}
  <div class="content-grid"><div class="panel"><div class="panel-head"><h3>Questions (${qs.length}) · ${total} pts bruts</h3></div>${qlist || empty('fa-circle-question', 'Aucune question. Ajoutez-en avec le formulaire.')}</div>
  <div class="panel"><div class="panel-head"><h3>Ajouter une question</h3></div><form id="questionForm"><div class="form-grid">
    <div class="field"><label for="qType">Type</label><select id="qType" name="type"><option value="mcq">QCM</option><option value="true_false">Vrai / Faux</option><option value="short_answer">Réponse courte</option></select></div>
    <div class="field"><label for="qPoints">Points</label><input id="qPoints" name="points" type="number" min="0.5" step="0.5" value="1" required></div>
    <div class="field full"><label for="qPrompt">Énoncé</label><textarea id="qPrompt" name="prompt" required></textarea></div>
    <div id="qDynamic" class="field full">${questionFields('mcq')}</div></div><div class="modal-actions"><button class="btn btn-primary fit">Ajouter la question</button></div></form></div></div>
  ${isStaff() ? await gradingPanel(a.id) : ''}`;
}
async function gradingPanel(assessmentId) {
  const attempts = unwrap(await sb.from('attempts').select('id,student_id,attempt_number,submitted_at,status').eq('assessment_id',assessmentId).eq('status','submitted').order('submitted_at',{ascending:false}));
  if (!attempts.length) return `<div class="panel" style="margin-top:18px"><div class="panel-head"><h3>Copies des étudiants</h3></div>${empty('fa-inbox','Aucune copie soumise pour le moment.')}</div>`;
  const ids=attempts.map(x=>x.student_id), profiles=unwrap(await sb.from('profiles').select('id,full_name,matricule').in('id',ids));
  const names=Object.fromEntries(profiles.map(x=>[x.id,`${x.full_name} · ${x.matricule||''}`]));
  const rows=[];
  for(const at of attempts){
    const answers=unwrap(await sb.from('student_answers').select('question_id,answer,points_awarded').eq('attempt_id',at.id));
    const qids=answers.map(x=>x.question_id); const qs=qids.length?unwrap(await sb.from('questions').select('id,prompt,question_type').in('id',qids)):[];
    const qmap=Object.fromEntries(qs.map(q=>[q.id,q]));
    const needs=answers.filter(x=>x.points_awarded===null);
    rows.push(`<details class="panel" style="margin:12px 0"><summary style="cursor:pointer;padding:12px;font-weight:700">${esc(names[at.student_id]||'Étudiant')} — ${at.status==='submitted'?'Soumise':'En cours'} · ${fmtDate(at.submitted_at||new Date())} · ${needs.length} réponse(s) à corriger</summary><div style="padding:12px">${answers.map(ans=>{const q=qmap[ans.question_id]||{};const txt=typeof ans.answer==='string'?ans.answer:JSON.stringify(ans.answer??'—');return `<div class="q-item" style="display:block"><strong>${esc(q.prompt||'Question')}</strong><p style="white-space:pre-wrap">${esc(txt)}</p>${ans.points_awarded===null?`<form class="gradeForm" data-attempt="${at.id}" data-question="${ans.question_id}" style="display:flex;gap:8px;align-items:end"><div class="field"><label>Points attribués</label><input name="points" type="number" min="0" step="0.25" value="0" required></div><button class="btn btn-primary">Enregistrer la note</button></form>`:`<small class="muted">Note : ${ans.points_awarded}</small>`}</div>`}).join('')}</div></details>`);
  }
  const res=unwrap(await sb.from('results').select('grading_status').eq('assessment_id',assessmentId));
  const ready=res.length>0&&res.every(x=>['graded','auto_graded'].includes(x.grading_status));
  return `<div class="panel" style="margin-top:18px"><div class="panel-head"><h3>Copies et corrections (${attempts.length})</h3>${ready?`<button class="btn btn-orange" data-act="publishResults" data-id="${assessmentId}">Publier les résultats</button>`:'<span class="status">Correction en attente</span>'}</div>${rows.join('')}</div>`;
}
function questionFields(type) {
  if (type === 'true_false') return '<label for="qCorrectTF">Bonne réponse</label><select id="qCorrectTF" name="correctTF"><option value="0">Vrai</option><option value="1">Faux</option></select>';
  if (type === 'short_answer') return '<label for="qAccepted">Réponses acceptées (séparées par « ; »)</label><input id="qAccepted" name="accepted" placeholder="Ex. : central processing unit ; cpu" required><small class="muted">La casse et les espaces autour sont ignorés.</small>';
  return '<label for="qOptions">Options (une par ligne, 2 minimum)</label><textarea id="qOptions" name="options" placeholder="Option A&#10;Option B&#10;Option C" required></textarea><label for="qCorrect" style="margin-top:10px">Numéro de la bonne option</label><input id="qCorrect" name="correct" type="number" min="1" value="1" required>';
}

/* ----- Résultats / Étudiants ----- */
function resultsHTML() {
  const avg = D.results.length ? D.results.reduce((s, r) => s + r.score / (r.max || 20) * 20, 0) / D.results.length : null;
  const ok = D.results.length ? Math.round(D.results.filter(r => pct(r) >= 50).length / D.results.length * 100) : null;
  const rows = (isStaff()?D.results.map(r=>({...r,history_status:r.grading_status||'Corrigée'})):S.history).map(r=>{const score=r.score===null||r.score===undefined?null:Number(r.score),max=Number(r.total_points||r.max||20), published=!!(r.published_at||r.date), label=r.status==='in_progress'?'En cours':r.status==='expired'?'Expirée':!r.submitted_at?'Non commencée':r.grading_status==='pending'?'En attente de correction':published?'Résultat publié':'Soumise';return `<tr>${isStaff()?`<td><strong>${esc(r.name||'Étudiant')}</strong></td>`:''}<td>${esc(r.assessment_title||r.exam||'Évaluation')}<small class="muted-cell"><br>${esc(r.assessment_type||'')} · Tentative ${r.attempt_number||1}</small></td><td>${published&&score!==null?`<strong>${score}/${max}</strong>`:'—'}</td><td><span class="status ${published&&score!==null&&score/max>=.5?'green':''}">${label}</span></td><td class="muted-cell">${fmtDay(r.submitted_at||r.started_at||r.date)}</td></tr>`}).join('');
  const semesterCards = !isStaff() ? (() => {
    const groups = new Map();
    for (const r of D.results) { if (!r.course_id || !r.assessment_type) continue; const key=r.course_id; if(!groups.has(key))groups.set(key,{}); const g=groups.get(key); if(!g[r.assessment_type] || new Date(r.date||0)>new Date(g[r.assessment_type].date||0))g[r.assessment_type]=r; }
    return [...groups.entries()].map(([cid,g])=>{
      const d1=g.DST1?g.DST1.score/(g.DST1.max||20)*20:null, d2=g.DST2?g.DST2.score/(g.DST2.max||20)*20:null;
      const ordinary=g.SESSION_ORDINAIRE?g.SESSION_ORDINAIRE.score/(g.SESSION_ORDINAIRE.max||20)*20:null;
      const retake=g.SESSION_RATTRAPAGE?g.SESSION_RATTRAPAGE.score/(g.SESSION_RATTRAPAGE.max||20)*20:null;
      if(d1===null||d2===null||ordinary===null&&retake===null)return '';
      const session=retake!==null?retake:ordinary;
      const semester=(((d1+d2)/2)*0.4)+(session*0.6);
      const passed=semester>=10;
      return `<article class="panel semester-card"><div><span class="eyebrow blue">BILAN DU SEMESTRE</span><h3>${esc(courseTitle(cid))}</h3><p>DST1 : ${d1.toFixed(2).replace('.',',')}/20 · DST2 : ${d2.toFixed(2).replace('.',',')}/20 · ${retake!==null?'Rattrapage':'Session ordinaire'} : ${session.toFixed(2).replace('.',',')}/20</p><strong class="semester-grade">${semester.toFixed(2).replace('.',',')}/20</strong><span class="status ${passed?'green':'gray'}">${passed?'Semestre validé':'Rattrapage requis'}</span></div></article>`;
    }).filter(Boolean).join('');
  })() : '';
  return `${pageHead(isStaff() ? 'Résultats & performances' : 'Mes résultats', 'Consultez les résultats et suivez les performances.')}
  ${semesterCards ? `<div class="semester-results"><h3>Validation de mes cours</h3><p class="muted">Calcul : moyenne de DST1 et DST2 × 40 % + session ordinaire (ou rattrapage) × 60 %. La note de rattrapage remplace celle de la session ordinaire.</p>${semesterCards}</div>` : ''}
  <div class="stat-grid">${stat('fa-award', avg === null ? '—' : avg.toFixed(1) + '/20', 'Moyenne générale', 'green')}${stat('fa-users', ok === null ? '—' : ok + '%', 'Taux de réussite')}${stat('fa-file-circle-check', D.results.length, 'Copies corrigées', 'orange')}${stat('fa-clipboard-check', D.assessments.filter(a => a.is_published).length, 'Évaluations publiées')}</div>
  <div class="panel"><div class="panel-head"><h3>${isStaff() ? 'Derniers résultats enregistrés' : 'Historique de mes évaluations'}</h3>${isStaff() ? '<button data-act="exportCSV">Exporter <i class="fa-solid fa-download"></i></button>' : ''}</div>
  ${rows ? `<div class="table-wrap"><table class="data-table"><thead><tr>${isStaff() ? '<th>ÉTUDIANT</th>' : ''}<th>ÉVALUATION / TENTATIVE</th><th>NOTE</th><th>STATUT</th><th>DATE</th></tr></thead><tbody>${rows}</tbody></table></div>` : empty('fa-chart-column', 'Aucune tentative ni évaluation dans votre historique pour le moment.')}</div>`;
}
function studentsHTML() {
  const rows = D.students.map(s => `<tr><td><strong>${esc(s.name)}</strong></td><td>${esc(s.id)}</td><td>${esc(s.class)}</td><td><span class="status ${s.active ? 'green' : 'gray'}">${s.active ? 'Actif' : 'Désactivé'}</span></td></tr>`).join('');
  return `${pageHead('Gestion des étudiants', 'Consultez les comptes et les informations des apprenants.', S.role === 'admin' ? '<button class="btn btn-primary" data-act="newStudent"><i class="fa-solid fa-user-plus"></i> Créer un compte</button>' : '')}
  <div class="toolbar"><div class="search-box"><i class="fa-solid fa-magnifying-glass"></i><input id="studentSearch" placeholder="Nom, matricule ou classe..." aria-label="Rechercher"></div></div>
  ${rows ? `<div class="table-wrap"><table class="data-table"><thead><tr><th>ÉTUDIANT</th><th>MATRICULE</th><th>CLASSE</th><th>STATUT</th></tr></thead><tbody id="studentRows">${rows}</tbody></table></div>` : empty('fa-users', 'Aucun étudiant enregistré.')}`;
}

/* Lecture sécurisée des supports de cours : PDF, DOCX et TXT dans la plateforme. */
function loadExternalScript(src, globalName) {
  if (window[globalName]) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const existing = document.querySelector(`script[data-src="${src}"]`);
    if (existing) { existing.addEventListener('load', resolve, { once: true }); existing.addEventListener('error', reject, { once: true }); return; }
    const script = document.createElement('script'); script.src = src; script.async = true; script.dataset.src = src;
    script.onload = resolve; script.onerror = () => reject(new Error('Impossible de charger le lecteur de document.'));
    document.head.appendChild(script);
  });
}
async function previewCourseFile(file) {
  const ext = (file.name.split('.').pop() || '').toLowerCase();
  modal(`${mHead('Lecture du support')}<div class="file-preview-meta"><strong>${esc(file.name)}</strong><span>${fmtSize(file.size)}</span></div><div id="courseFilePreview" class="course-file-preview"><div class="empty-state"><i class="fa-solid fa-spinner fa-spin"></i><p>Ouverture du document…</p></div></div><div class="modal-actions"><button class="btn btn-light" type="button" data-act="closeModal">Fermer</button><button class="btn btn-primary" type="button" data-act="downloadPreviewFile" data-id="${esc(file.id)}"><i class="fa-solid fa-download"></i> Télécharger</button></div>`, 'wide file-preview-modal');
  try {
    const url = await api().fileUrl(file, false);
    const host = $('#courseFilePreview'); if (!host) return;
    if (ext === 'pdf' || file.mime === 'application/pdf') {
      host.innerHTML = `<iframe class="pdf-reader" title="${esc(file.name)}" src="${url}#toolbar=1&navpanes=0"></iframe>`;
    } else if (ext === 'txt' || file.mime === 'text/plain') {
      const response = await fetch(url); if (!response.ok) throw new Error('Le fichier texte ne peut pas être chargé.');
      const content = await response.text(); host.innerHTML = `<pre class="text-reader">${esc(content)}</pre>`;
    } else if (ext === 'docx' || file.mime === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
      await loadExternalScript('https://cdn.jsdelivr.net/npm/mammoth@1.9.0/mammoth.browser.min.js', 'mammoth');
      const response = await fetch(url); if (!response.ok) throw new Error('Le document Word ne peut pas être chargé.');
      const buffer = await response.arrayBuffer(); const result = await window.mammoth.convertToHtml({ arrayBuffer: buffer });
      host.innerHTML = `<article class="docx-reader">${result.value || '<p>Ce document ne contient pas de texte lisible.</p>'}</article>`;
    } else {
      host.innerHTML = `<div class="empty-state"><i class="fa-regular fa-file"></i><p>L’aperçu en ligne n’est pas disponible pour ce format. Téléchargez le fichier pour le consulter.</p></div>`;
    }
  } catch (error) {
    const host = $('#courseFilePreview'); if (host) host.innerHTML = `<div class="empty-state error-text"><i class="fa-solid fa-triangle-exclamation"></i><p>${esc(error.message || 'Impossible d’ouvrir ce document.')}</p><small>Vérifiez que le cours est publié et que votre accès est autorisé.</small></div>`;
  }
}

/* ====================================================================
   MODALES
   ==================================================================== */
function modal(html, cls = '') {
  $('#modalRoot').innerHTML = `<div class="modal-backdrop"><div class="modal ${cls}" role="dialog" aria-modal="true">${html}</div></div>`;
  $('.modal-backdrop').addEventListener('mousedown', e => { if (e.target.classList.contains('modal-backdrop')) closeModal(); });
  $('.modal input, .modal select, .modal textarea, .modal button.btn')?.focus();
}
const closeModal = () => { $('#modalRoot').innerHTML = ''; };

/* ===== Nouveaux espaces : Ma classe / Mon évolution / Le Professeur ===== */
async function maClasseHTML(){
 if(S.demo)return `${pageHead('Ma classe','Espace privé de discussion entre les étudiants d’une même classe.')}<div class="panel">${empty('fa-people-group','La messagerie de classe fonctionne avec les comptes connectés et les classes réelles.')}</div>`;
 const {data:rooms,error}=await sb.from('class_discussions').select('id,title,description,is_open,class_id,classes(name,level_code,academic_year)').order('created_at',{ascending:false}); if(error)throw error;
 const rows=rooms||[];
 const staffTools=isStaff()?`<div class="panel"><div class="panel-head"><h3>Créer un espace de discussion</h3></div><form id="classRoomForm" class="form-grid"><div class="field"><label>Classe</label><select name="class_id" id="roomClass" required><option value="">Chargement des classes…</option></select></div><div class="field"><label>Nom de l’espace</label><input name="title" value="Discussion de classe" maxlength="100" required></div><div class="field full"><label>Description</label><input name="description" maxlength="250" placeholder="Échanges, entraide et informations pédagogiques"></div><div class="field full"><button class="btn btn-primary">Créer l’espace</button></div></form></div>`:'';
 setTimeout(async()=>{const sel=$('#roomClass');if(sel){const q=await sb.from('classes').select('id,name,level_code').order('name');if(!q.error)sel.innerHTML='<option value="">Choisir une classe</option>'+(q.data||[]).map(c=>`<option value="${c.id}">${esc(c.name)} · ${esc(c.level_code||'')}</option>`).join('');}const cls=$('#resourceForm [name=class_id]');if(cls){const q=await sb.from('classes').select('id,name,level_code').order('name');if(!q.error)cls.innerHTML='<option value="">Toutes les classes autorisées</option>'+(q.data||[]).map(c=>`<option value="${c.id}">${esc(c.name)} · ${esc(c.level_code||'')}</option>`).join('');}},0);
 return `${pageHead('Ma classe','Un espace privé pour échanger, s’entraider et partager des informations avec les membres de votre classe.')} ${staffTools}<div class="class-room-grid">${rows.length?rows.map(r=>`<button class="class-room-card" data-act="openClassRoom" data-id="${r.id}"><span class="room-icon"><i class="fa-solid fa-comments"></i></span><span><strong>${esc(r.title)}</strong><small>${esc(r.classes?.name||'Classe')} · ${esc(r.classes?.level_code||'')} ${r.is_open?'':'· Discussion fermée'}</small><small>${esc(r.description||'Espace de discussion de la classe')}</small></span><i class="fa-solid fa-chevron-right"></i></button>`).join(''):empty('fa-comments','Aucun espace de discussion n’a encore été créé pour votre classe.')}</div>`;
}
async function classRoomHTML(id){
 const {data:room,error}=await sb.from('class_discussions').select('id,title,description,is_open,class_id,classes(name)').eq('id',id).single();if(error)throw error;
 const {data:msgs,error:me}=await sb.from('class_messages').select('id,sender_id,sender_name,body,created_at').eq('discussion_id',id).order('created_at',{ascending:true}).limit(150);if(me)throw me;
 const names=Object.fromEntries((msgs||[]).map(m=>[m.sender_id,m.sender_name||'Membre']));
 return `<button class="back-link" data-act="go" data-page="maClasse"><i class="fa-solid fa-arrow-left"></i> Mes espaces</button><div class="page-heading"><div><span class="eyebrow blue">${esc(room.classes?.name||'MA CLASSE')}</span><h1>${esc(room.title)}</h1><p>${esc(room.description||'Discussion privée de classe')}</p></div>${isStaff()?`<button class="btn btn-light" data-act="toggleRoom" data-id="${id}" data-open="${room.is_open}">${room.is_open?'Fermer la discussion':'Rouvrir la discussion'}</button>`:''}</div><div class="panel chat-panel"><div class="chat-messages" id="classMessages">${(msgs||[]).map(m=>`<div class="chat-message ${m.sender_id===S.user.id?'mine':''}"><strong>${esc(names[m.sender_id]||'Membre')}</strong><p>${esc(m.body).replace(/\n/g,'<br>')}</p><time>${fmtDate(m.created_at)}</time></div>`).join('')||empty('fa-comments','Soyez le premier à lancer la discussion.')}</div>${room.is_open?`<form id="classMessageForm" data-room="${id}" class="chat-compose"><textarea name="body" maxlength="5000" rows="2" placeholder="Écrivez votre message à la classe…" required></textarea><button class="btn btn-primary" aria-label="Envoyer"><i class="fa-solid fa-paper-plane"></i> Envoyer</button></form>`:`<p class="muted">Cette discussion est actuellement fermée par l’équipe pédagogique.</p>`}</div>`;
}
async function monEvolutionHTML(){
 if(S.demo)return `${pageHead('Mon évolution','Vos ressources pédagogiques, vos révisions et votre accompagnement intelligent.')}<div class="evolution-grid"><div class="evolution-card"><i class="fa-solid fa-book-open"></i><h3>Notes de cours</h3><p>Retrouvez les supports publiés par vos formateurs.</p></div><div class="evolution-card"><i class="fa-solid fa-list-check"></i><h3>Briefing de révision</h3><p>Organisez vos révisions et consolidez les notions importantes.</p></div><div class="evolution-card ai-card"><i class="fa-solid fa-graduation-cap"></i><h3>Le Professeur</h3><p>Votre professeur virtuel pour comprendre et progresser.</p></div></div><div class="panel">${empty('fa-cloud','Connectez-vous avec un compte réel pour accéder aux ressources et à l’assistant.')}</div>`;
 const {data:resources,error}=await sb.from('learning_resources').select('id,title,description,kind,body,created_at,courses(title),classes(name)').eq('is_published',true).order('created_at',{ascending:false}).limit(100);if(error)throw error;
 const notes=(resources||[]).filter(x=>x.kind==='note'),briefs=(resources||[]).filter(x=>x.kind==='briefing');
 setTimeout(async()=>{const cls=$('#resourceForm [name=class_id]');if(cls){const q=await sb.from('classes').select('id,name,level_code').order('name');if(!q.error)cls.innerHTML='<option value="">Toutes les classes autorisées</option>'+(q.data||[]).map(c=>`<option value="${c.id}">${esc(c.name)} · ${esc(c.level_code||'')}</option>`).join('');}},0);
 const card=(r)=>`<article class="resource-card" data-kind="${r.kind}"><span class="resource-kind">${r.kind==='note'?'NOTE DE COURS':'BRIEFING DE RÉVISION'}</span><h3>${esc(r.title)}</h3><p>${esc(r.description||'')}</p><small>${esc(r.courses?.title||r.classes?.name||'Ressource pédagogique')} · ${fmtDay(r.created_at)}</small><button class="text-link" data-act="readResource" data-id="${r.id}">Consulter <i class="fa-solid fa-arrow-right"></i></button></article>`;
 return `${pageHead('Mon évolution','Des ressources et un accompagnement pour progresser à votre rythme.')}<div class="evolution-grid"><button class="evolution-card" data-act="filterEvolution" data-kind="note"><i class="fa-solid fa-book-open"></i><h3>Notes de cours</h3><p>${notes.length} ressource(s) disponible(s)</p></button><button class="evolution-card" data-act="filterEvolution" data-kind="briefing"><i class="fa-solid fa-list-check"></i><h3>Briefing de révision</h3><p>${briefs.length} briefing(s) disponible(s)</p></button><button class="evolution-card ai-card" data-act="go" data-page="professeur"><i class="fa-solid fa-graduation-cap"></i><h3>Le Professeur</h3><p>Posez vos questions à votre enseignant virtuel.</p><span class="btn btn-primary">Discuter maintenant</span></button></div>${isStaff()?`<div class="panel"><div class="panel-head"><h3>Publier une ressource pédagogique</h3></div><form id="resourceForm" class="form-grid"><div class="field"><label>Titre</label><input name="title" required maxlength="150"></div><div class="field"><label>Type</label><select name="kind"><option value="note">Note de cours</option><option value="briefing">Briefing de révision</option></select></div><div class="field"><label>Cours (facultatif)</label><select name="course_id"><option value="">Aucun cours précis</option>${D.courses.map(c=>`<option value="${c.id}">${esc(c.title)}</option>`).join('')}</select></div><div class="field"><label>Classe (facultatif)</label><select name="class_id"><option value="">Toutes les classes autorisées</option></select></div><div class="field full"><label>Description</label><input name="description" maxlength="250"></div><div class="field full"><label>Contenu</label><textarea name="body" rows="6" required></textarea></div><div class="field full"><label><input type="checkbox" name="is_published"> Publier immédiatement</label><button class="btn btn-primary">Enregistrer la ressource</button></div></form></div>`:''}<div class="panel" id="notesResources"><div class="panel-head"><h3>Notes de cours</h3><span class="status">${notes.length}</span></div><div class="resource-grid">${notes.map(card).join('')||empty('fa-book-open','Aucune note de cours publiée pour le moment.')}</div></div><div class="panel" id="briefingResources"><div class="panel-head"><h3>Briefing de révision</h3><span class="status">${briefs.length}</span></div><div class="resource-grid">${briefs.map(card).join('')||empty('fa-list-check','Aucun briefing de révision publié pour le moment.')}</div></div>`;
}
async function professeurHTML(){
 if(S.demo)return `${pageHead('Le Professeur','Votre enseignant virtuel C-TECH, spécialisé dans l’apprentissage.')}<div class="panel">${empty('fa-graduation-cap','Le Professeur nécessite une connexion réelle et la configuration de la clé API.')}</div>`;
 const {data:history,error}=await sb.from('ai_chat_messages').select('id,role,content,created_at').eq('user_id',S.user.id).order('created_at',{ascending:true}).limit(80);if(error)throw error;
 return `${pageHead('Le Professeur','Votre enseignant virtuel : les cours C-TECH d’abord, puis des explications complémentaires pour approfondir.')}<div class="professor-intro"><div class="professor-avatar"><i class="fa-solid fa-graduation-cap"></i></div><div><strong>Bonjour ${esc((S.user.name||'').split(' ')[0])} !</strong><p>Je suis Le Professeur. Je peux vous aider à comprendre vos cours, préparer vos examens et vous entraîner. Je réponds uniquement aux questions liées aux études.</p></div></div><div class="panel professor-panel"><div id="professorChat" class="professor-chat">${(history||[]).map(m=>`<div class="ai-bubble ${m.role==='user'?'user-bubble':''}"><strong>${m.role==='user'?'Vous':'Le Professeur'}</strong><div>${esc(m.content).replace(/\n/g,'<br>')}</div></div>`).join('')||`<div class="ai-bubble"><strong>Le Professeur</strong><div>Bienvenue ! Quelle notion de vos cours souhaitez-vous comprendre aujourd’hui ?</div></div>`}</div><form id="professorForm" class="chat-compose"><textarea name="message" rows="2" maxlength="3000" placeholder="Posez votre question scolaire…" required></textarea><button class="btn btn-primary"><i class="fa-solid fa-paper-plane"></i> Envoyer</button></form><p class="ai-disclaimer"><i class="fa-solid fa-shield-halved"></i> Les échanges sont réservés à l’accompagnement éducatif. Les ressources C-TECH sont prioritaires.</p></div>`;
}

const mHead = t => `<div class="modal-head"><h3>${t}</h3><button class="modal-close" data-act="closeModal" aria-label="Fermer"><i class="fa-solid fa-xmark"></i></button></div>`;
const mActions = label => `<div class="modal-actions"><button type="button" class="btn btn-light fit" data-act="closeModal">Annuler</button><button class="btn btn-primary fit">${label}</button></div>`;
function confirmBox(text, label = 'Confirmer') {
  return new Promise(res => {
    modal(`${mHead('Confirmation')}<p>${esc(text)}</p><div class="modal-actions"><button type="button" class="btn btn-light fit" id="cNo">Annuler</button><button type="button" class="btn btn-primary fit" id="cYes">${esc(label)}</button></div>`);
    $('#cNo').onclick = () => { closeModal(); res(false); }; $('#cYes').onclick = () => { closeModal(); res(true); };
  });
}
const localInput = d => { const x = new Date(d.getTime() - d.getTimezoneOffset() * 60000); return x.toISOString().slice(0, 16); };
async function modalCourse() {
  try {
    const [classes, teachers] = await Promise.all([
      sb.from('classes').select('id,name').order('name').then(unwrap),
      sb.from('profiles').select('id,full_name').eq('role','teacher').eq('is_active',true).order('full_name').then(unwrap)
    ]);
    const teacherOptions = S.role === 'admin'
      ? `<option value="">Choisir un formateur</option>${teachers.map(x=>`<option value="${esc(x.id)}">${esc(x.full_name)}</option>`).join('')}`
      : `<option value="${esc(S.user.id)}">Moi-même</option>`;
    modal(`${mHead('Nouveau cours')}<form id="courseForm"><div class="form-grid">
      <div class="field full"><label>Nom du cours / matière <span class="required">*</span></label><input name="title" required maxlength="120" placeholder="Ex. : Informatique générale"></div>
      <div class="field"><label>Classe (facultatif)</label><select name="class_id"><option value="">Toutes / non définie</option>${classes.map(x=>`<option value="${esc(x.id)}">${esc(x.name)}</option>`).join('')}</select></div>
      <div class="field"><label>Formateur responsable <span class="required">*</span></label><select name="teacher_id" required>${teacherOptions}</select></div>
      <div class="field"><label>Publication</label><select name="published"><option value="0">Brouillon</option><option value="1">Publié</option></select></div>
      <div class="field full"><label>Description</label><textarea name="description" placeholder="Présentez brièvement le contenu du cours…"></textarea></div>
    </div><p class="muted">La matière correspond directement au cours : elle sera créée automatiquement à partir de son nom. Aucune affectation préalable de matière n’est nécessaire.</p>${mActions('Créer le cours')}</form>`);
  } catch(e) { toast('Impossible de préparer le formulaire : '+e.message); }
}
function modalModule(id) { modal(`${mHead('Nouveau module')}<form id="moduleForm" data-id="${esc(id)}"><div class="field"><label>Titre du module</label><input name="title" required maxlength="120" placeholder="Module 3 — Les réseaux"></div>${mActions('Ajouter')}</form>`); }
function modalChapter(id) { modal(`${mHead('Nouveau chapitre')}<form id="chapterForm" data-id="${esc(id)}"><div class="form-grid"><div class="field full"><label>Titre du chapitre</label><input name="title" required maxlength="140"></div><div class="field full"><label>Contenu (séparez les paragraphes par une ligne vide)</label><textarea name="content" style="min-height:200px"></textarea></div></div>${mActions('Ajouter')}</form>`); }
async function modalAssessment(id=null) {
  const a=id?D.assessments.find(x=>x.id===id):null;
  let domains,filieres,levels,targets;
  if(S.demo){domains=[{id:'demo-domain',name:'Informatique'}];filieres=[{id:'demo-filiere',name:'Informatique générale',domain_id:'demo-domain'}];levels=[{level_code:'L1'},{level_code:'L2'},{level_code:'L3'}];targets=a?await api().getAssessmentTargets(id):null;}
  else {[domains,filieres,levels,targets]=await Promise.all([
    sb.from('domains').select('id,name').order('name').then(unwrap),
    sb.from('filieres').select('id,name,domain_id').order('name').then(unwrap),
    sb.from('profiles').select('level_code').eq('role','student').not('level_code','is',null).then(unwrap),
    a?api().getAssessmentTargets(id):Promise.resolve(null)
  ]);}
  // Niveaux académiques proposés par défaut, même si aucun étudiant n'est encore inscrit.
  // Les niveaux déjà présents dans les profils sont conservés en complément.
  const levelList=[...new Set(['L1','L2','L3',...levels.map(x=>String(x.level_code||'').trim().toUpperCase()).filter(Boolean)])].sort((a,b)=>a.localeCompare(b,'fr',{numeric:true}));
  const selected=(arr,values)=>arr.filter(x=>(values||[]).includes(x.id)).map(x=>x.id);
  const domainIds=targets?.domain_ids||[], filiereIds=targets?.filiere_ids||[], levelCodes=targets?.level_codes||[];
  const s=a?new Date(a.start_at):new Date(Date.now()+3600e3); if(!a)s.setMinutes(0,0,0);
  const e=a?new Date(a.end_at):new Date(s.getTime()+2*3600e3);
  const multi=(name,label,options,vals)=>`<div class="field"><label>${label} <span class="muted">(sélection multiple)</span></label><select name="${name}" multiple size="${Math.min(5,Math.max(3,options.length))}" required>${options.map(o=>`<option value="${esc(o.value)}" ${(vals||[]).includes(o.value)?'selected':''}>${esc(o.label)}</option>`).join('')}</select><small class="muted">Maintenez la sélection pour choisir plusieurs éléments.</small></div>`;
  modal(`${mHead(a?'Modifier l’évaluation':'Créer une évaluation')}<form id="assessmentForm" data-id="${a?esc(a.id):''}">
  <div class="form-section"><span class="eyebrow blue">ÉTAPE 1 · IDENTIFICATION</span><h3>Informations générales</h3><div class="form-grid">
  <div class="field full"><label>Titre de l’évaluation</label><input name="title" required maxlength="140" value="${esc(a?.title||'')}"></div>
  <div class="field"><label>Type d’évaluation</label><select name="assessment_type"><option value="DST1" ${(a?.assessment_type||'DST1')==='DST1'?'selected':''}>DST1</option><option value="DST2" ${a?.assessment_type==='DST2'?'selected':''}>DST2</option><option value="SESSION_ORDINAIRE" ${a?.assessment_type==='SESSION_ORDINAIRE'?'selected':''}>Session ordinaire</option><option value="SESSION_RATTRAPAGE" ${a?.assessment_type==='SESSION_RATTRAPAGE'?'selected':''}>Session de rattrapage</option></select></div>
  <div class="field"><label>Matière / cours</label><select name="course_id" required>${D.courses.map(c=>`<option value="${esc(c.id)}" ${a?.course_id===c.id?'selected':''}>${esc(c.title)}</option>`).join('')}</select></div>
  <div class="field full"><label>Consignes destinées aux étudiants</label><textarea name="description" rows="3">${esc(a?.description||'')}</textarea></div></div></div>
  <div class="form-section"><span class="eyebrow blue">ÉTAPE 2 · PUBLIC CIBLE</span><h3>À qui s’adresse cette évaluation ?</h3><p class="muted">Les critères sont cumulatifs : l’étudiant doit correspondre à un domaine, une filière et un niveau sélectionnés.</p><div class="form-grid">
  ${multi('domain_ids','Domaines',domains.map(x=>({value:x.id,label:x.name})),domainIds)}
  ${multi('filiere_ids','Filières',filieres.map(x=>({value:x.id,label:x.name})),filiereIds)}
  ${multi('level_codes','Niveaux',levelList.map(x=>({value:x,label:x})),levelCodes)}
  </div></div>
  <div class="form-section"><span class="eyebrow blue">ÉTAPE 3 · PLANIFICATION</span><h3>Dates et paramètres</h3><div class="form-grid">
  <div class="field"><label>Date et heure de début</label><input name="start" type="datetime-local" required value="${localInput(s)}"></div><div class="field"><label>Date et heure de fin</label><input name="end" type="datetime-local" required value="${localInput(e)}"></div>
  <div class="field"><label>Durée (minutes)</label><input name="duration" type="number" min="1" max="600" value="${a?.duration_minutes||30}" required></div><div class="field"><label>Nombre de tentatives</label><input name="attempts" type="number" min="1" max="10" value="${a?.max_attempts||1}" required></div>
  <div class="field"><label>Note maximale</label><input name="points" type="number" min="1" step="0.5" value="${a?.points||20}" required></div></div></div>
  <div class="form-section"><span class="eyebrow blue">ÉTAPE 4 · VALIDATION</span><p class="muted">Vérifiez les informations et le public cible avant d’enregistrer. Les copies déjà soumises conservent leur version initiale.</p></div>
  ${mActions(a?'Enregistrer les modifications':'Créer l’évaluation')}</form>`,'assessment-editor-modal');
}
function modalQuestionEdit(q){
 const type=q.type||'mcq';
 const fields=type==='short_answer'?`<label>Réponses acceptées (séparées par ;)</label><input name="accepted" value="${esc((q.accepted||[]).join(' ; '))}" required>`:`<label>Options (une par ligne)</label><textarea name="options" required>${esc((q.options||[]).join('\n'))}</textarea><label>Numéro de la bonne option</label><input name="correct" type="number" min="1" value="${type==='true_false'?(String(q.correct)==='Faux'||q.correct===1?2:1):Math.max(1,(q.options||[]).indexOf(q.correct)+1)}" required>`;
 modal(`${mHead('Modifier la question')}<form id="editQuestionForm" data-id="${esc(q.id)}"><div class="form-grid"><div class="field full"><label>Énoncé</label><textarea name="prompt" required>${esc(q.prompt)}</textarea></div><div class="field"><label>Type</label><select name="type" disabled><option>${TYPE_LABEL[type]}</option></select><input type="hidden" name="type" value="${type}"></div><div class="field"><label>Points</label><input name="points" type="number" min="0.5" step="0.5" value="${q.points}" required></div><div class="field full">${fields}</div></div>${mActions('Enregistrer les modifications')}</form>`);
}

function modalReopenAssessment(id){
 const a=D.assessments.find(x=>x.id===id); if(!a)return;
 const start=new Date(Date.now()+5*60000), end=new Date(Date.now()+24*3600e3);
 modal(`${mHead('Relancer l’évaluation')}<p class="muted">L’historique des copies et des notes est conservé. Chaque étudiant disposera d’une tentative supplémentaire.</p><form id="reopenAssessmentForm" data-id="${esc(id)}"><div class="form-grid"><div class="field"><label>Nouvelle date de début</label><input name="start" type="datetime-local" required value="${localInput(start)}"></div><div class="field"><label>Nouvelle date de fin</label><input name="end" type="datetime-local" required value="${localInput(end)}"></div></div>${mActions('Relancer maintenant')}</form>`);
}
function showExamFeedback(data, assessment){
 const pending=!!data?.pending_manual_correction;
 const total=Number(data?.total_points||0), raw=Number(data?.auto_score||0), note=total>0?Math.max(0,Math.min(20,raw/total*20)):0;
 const label=({DST1:'DST 1',DST2:'DST 2',SESSION_ORDINAIRE:'Session ordinaire',SESSION_RATTRAPAGE:'Session de rattrapage'})[assessment?.assessment_type]||'Évaluation';
 let title='Copie envoyée', message='Votre copie a bien été transmise. Le formateur doit encore corriger certaines réponses. Ne vous inquiétez pas : votre résultat sera affiché dès que la correction sera terminée.', icon='fa-hourglass-half', color='';
 if(!pending){
   if(note<10){title='Ne baissez pas les bras !';message=`Vous avez obtenu ${note.toFixed(2).replace('.',',')}/20. Ce résultat ne doit pas vous décourager. Identifiez vos difficultés, appliquez-vous davantage et continuez vos efforts. Vous pouvez progresser !`;icon='fa-heart';}
   else if(note<15){title='Félicitations ! 🎉';message=`Vous avez obtenu ${note.toFixed(2).replace('.',',')}/20. C’est un bon résultat, bravo pour votre travail ! Continuez à apprendre et à fournir des efforts pour aller encore plus loin.`;icon='fa-award';}
   else {title='Excellente performance ! 🌟';message=`Remarquable ! Vous avez obtenu ${note.toFixed(2).replace('.',',')}/20. Votre sérieux et votre régularité portent leurs fruits. Félicitations : maintenez ce niveau d’excellence et continuez à viser haut !`;icon='fa-trophy';}
 }
 const gradeHtml=pending?'<span class="feedback-pending">Correction en attente</span>':`<div class="feedback-score">${note.toFixed(2).replace('.',',')}<small>/20</small></div><span class="feedback-validity ${note>=10?'is-valid':'is-not-valid'}">${note>=10?'Évaluation validée':'Évaluation non validée'}</span>`;
 modal(`<div class="exam-feedback"><div class="feedback-icon"><i class="fa-solid ${icon}"></i></div><span class="eyebrow blue">${esc(label.toUpperCase())} · RÉSULTAT</span><h2>${title}</h2>${gradeHtml}<p>${message}</p><button type="button" class="btn btn-primary btn-block" id="feedbackContinue">Continuer</button><small>La validation définitive du semestre dépend des notes des DST et de la session.</small></div>`,'feedback-modal');
 $('#feedbackContinue').onclick=()=>{closeModal();if(window.CTECHExam?.onExit)window.CTECHExam.onExit(data);};
}
function modalStudent() {
  modal(`${mHead('Créer un compte étudiant')}<form id="studentForm"><div class="form-grid"><div class="field"><label>Nom complet</label><input name="full_name" required></div><div class="field"><label>Matricule</label><input name="student_code" required placeholder="ICT12141110" pattern="[A-Za-z0-9\\-]{4,20}"></div>
  <div class="field"><label>Classe / promotion</label><input name="class_name" value="L1 Informatique" required></div><div class="field"><label>Mot de passe provisoire (8 car. min.)</label><input name="password" type="text" minlength="8" required value="${esc(tempPassword())}"></div></div>
  <p class="muted" style="font-size:11px">L’étudiant se connecte avec son <strong>matricule</strong> et ce mot de passe. Notez-le avant de valider : il ne sera plus affiché.</p>${mActions('Créer le compte')}</form>`);
}
function tempPassword() { const a = new Uint32Array(3); crypto.getRandomValues(a); return 'Ct' + [...a].map(n => n.toString(36)).join('').slice(0, 8) + '!'; }
function modalDemo() {
  modal(`${mHead('Démonstration')}<p class="muted">Choisissez un profil. Les données sont fictives et restent dans votre navigateur.</p><div class="demo-roles">
  <button class="btn btn-light" data-act="demoRole" data-role="student"><i class="fa-solid fa-user-graduate"></i> Étudiant</button><button class="btn btn-light" data-act="demoRole" data-role="teacher"><i class="fa-solid fa-chalkboard-user"></i> Enseignant</button><button class="btn btn-light" data-act="demoRole" data-role="admin"><i class="fa-solid fa-user-shield"></i> Administrateur</button></div>`);
}

/* ====================================================================
   IMPORT DE SUPPORTS (PDF / Word / texte)
   ==================================================================== */
function modalImport(courseId) {
  S.imp = { courseId };
  modal(`${mHead('Importer un support de cours')}<p class="muted" style="font-size:12px">PDF, Word (.docx) ou texte, 15 Mo maximum. Le contenu est découpé en modules et chapitres que vous pourrez corriger avant de valider. Le fichier est lu dans votre navigateur.</p>
  <label class="dropzone" for="impFile"><i class="fa-solid fa-cloud-arrow-up"></i><strong>Choisir un fichier ou le déposer ici</strong><small>.pdf · .docx · .txt</small></label><input id="impFile" type="file" accept="${ImportKit.ACCEPT}" hidden>
  <div id="impStatus" class="muted" role="status" style="margin-top:12px;font-size:12px"></div>`, 'wide');
}
async function handleImportFile(file) {
  if (!file) return; const st = $('#impStatus'); st.classList.remove('error-text'); st.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Analyse de « ' + esc(file.name) + ' »…';
  try {
    const r = await ImportKit.extract(file);
    Object.assign(S.imp, { file, stats: r.stats, attach: true, modules: r.modules.map(m => ({ title: m.title, chapters: m.chapters.map(c => ({ ...c })) })) });
    renderImportPreview();
  } catch (e) { st.classList.add('error-text'); st.textContent = e.message; }
}
function syncImport() {
  const I = S.imp; if (!I?.modules) return;
  $$('.imp-input').forEach(inp => { const m = I.modules[+inp.dataset.m]; if (!m) return; const v = inp.value.trim().slice(0, 140); if (inp.dataset.c !== undefined) { const c = m.chapters[+inp.dataset.c]; if (c && v) c.title = v; } else if (v) m.title = v; });
  const at = $('#impAttach'); if (at) I.attach = at.checked;
}
function renderImportPreview() {
  const I = S.imp, n = I.modules.reduce((t, m) => t + m.chapters.length, 0);
  const tree = I.modules.map((m, mi) => `<div class="imp-module"><div class="imp-mhead"><i class="fa-solid fa-layer-group"></i><input class="imp-input" data-m="${mi}" value="${esc(m.title)}" aria-label="Titre du module" maxlength="140"><button type="button" class="icon-btn" data-act="impDelM" data-m="${mi}" aria-label="Retirer ce module"><i class="fa-regular fa-trash-can"></i></button></div>
    ${m.chapters.map((c, ci) => `<div class="imp-chapter"><i class="fa-regular fa-file-lines"></i><div><input class="imp-input" data-m="${mi}" data-c="${ci}" value="${esc(c.title)}" aria-label="Titre du chapitre" maxlength="140"><small>${c.content.length.toLocaleString('fr-FR')} caractères${c.content ? ' · ' + esc(c.content.replace(/\s+/g, ' ').slice(0, 80)) + (c.content.length > 80 ? '…' : '') : ' · (vide)'}</small></div><button type="button" class="icon-btn" data-act="impDelC" data-m="${mi}" data-c="${ci}" aria-label="Retirer ce chapitre"><i class="fa-regular fa-trash-can"></i></button></div>`).join('')}</div>`).join('');
  $('.modal').innerHTML = `${mHead('Vérifier avant d’importer')}<p style="font-size:12px;margin:0 0 12px"><strong>${esc(I.file.name)}</strong> → ${I.modules.length} module(s), ${n} chapitre(s)${I.stats.pages ? ', ' + I.stats.pages + ' page(s) lues' : ''}. Corrigez les titres ou retirez ce que vous ne voulez pas.</p>
  <div class="imp-tree">${tree}</div><label class="check"><input type="checkbox" id="impAttach" ${I.attach ? 'checked' : ''}> Joindre le fichier original (téléchargeable par les étudiants)</label>
  <div class="modal-actions"><button type="button" class="btn btn-light fit" data-act="closeModal">Annuler</button><button type="button" class="btn btn-primary fit" id="impConfirm" data-act="impConfirm" ${n ? '' : 'disabled'}>Importer ${n} chapitre${n > 1 ? 's' : ''}</button></div>`;
}
document.addEventListener('change', e => { if (e.target.id === 'impFile') handleImportFile(e.target.files[0]); });
document.addEventListener('dragover', e => { if (e.target.closest?.('.dropzone')) e.preventDefault(); });
document.addEventListener('drop', e => { if (e.target.closest?.('.dropzone')) { e.preventDefault(); handleImportFile(e.dataTransfer.files[0]); } });

/* ====================================================================
   ÉVALUATION (épreuve)
   ==================================================================== */
async function startExam(id) {
  const a = D.assessments.find(x => x.id === id); if (!a) return;
  try {
    const attempt = await api().startAttempt(id), questions = await api().getQuestions(attempt);
    if (!questions.length) { toast('Aucune question publiée.'); return; }
    exam = { a, attempt, questions, index: 0, answers: Object.fromEntries(questions.filter(q => q.answer !== null && q.answer !== undefined).map(q => [q.id, q.answer])), saving: Promise.resolve(), timer: null };
    exam.timer = setInterval(tick, 1000); renderExam(); window.onbeforeunload = () => 'Une évaluation est en cours.';
  } catch (e) { toast(e.message); }
}
const remaining = () => Math.max(0, Math.round((exam.attempt.deadline - Date.now()) / 1000));
const timerText = s => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
function tick() { if (!exam) return; const r = remaining(), t = $('#examTimer'); if (t) { t.textContent = timerText(r); t.parentElement.classList.toggle('low', r <= 60); } if (r <= 0) submitExam(true); }
function renderExam() {
  const q = exam.questions[exam.index], ans = exam.answers[q.id], last = exam.index === exam.questions.length - 1;
  const input = q.type === 'short_answer' ? `<div class="field"><label for="shortAnswer">Votre réponse</label><input id="shortAnswer" autocomplete="off" value="${esc(ans ?? '')}" placeholder="Saisissez votre réponse..."></div>`
    : q.options.map((o, i) => `<label class="question-option"><input type="radio" name="answer" value="${i}" ${ans === i ? 'checked' : ''}> ${esc(o)}</label>`).join('');
  $('#pageContent').innerHTML = `<div class="exam-top"><div><span class="eyebrow blue">ÉVALUATION EN COURS</span><h1 style="font-size:21px;margin:6px 0">${esc(exam.a.title)}</h1><p class="muted" style="margin:0;font-size:11px">${esc(courseTitle(exam.a.course_id))} · ${exam.questions.length} questions</p></div><div class="timer"><i class="fa-regular fa-clock"></i> <span id="examTimer">${timerText(remaining())}</span></div></div>
  <div class="q-nav">${exam.questions.map((x, i) => `<button class="q-dot ${i === exam.index ? 'current' : ''} ${exam.answers[x.id] !== undefined && exam.answers[x.id] !== '' ? 'answered' : ''}" data-act="gotoQ" data-i="${i}" aria-label="Question ${i + 1}">${i + 1}</button>`).join('')}</div>
  <div class="question-box"><div class="question-index">QUESTION ${exam.index + 1} / ${exam.questions.length} · ${q.points} POINT${q.points > 1 ? 'S' : ''}</div><h3>${esc(q.prompt)}</h3>${input}</div>
  <div class="exam-navigation"><button class="btn btn-light fit" data-act="prevQ" ${exam.index === 0 ? 'disabled' : ''}>Précédent</button>${last ? '<button class="btn btn-orange fit" data-act="finishExam">Soumettre l’épreuve</button>' : '<button class="btn btn-primary fit" data-act="nextQ">Question suivante <i class="fa-solid fa-arrow-right"></i></button>'}</div>`;
  $('#shortAnswer')?.addEventListener('change', saveCurrent); $$('input[name="answer"]').forEach(x => x.addEventListener('change', () => { saveCurrent(); $$('.q-dot')[exam.index]?.classList.add('answered'); }));
}
function saveCurrent() {
  if (!exam) return; const q = exam.questions[exam.index]; let v;
  if (q.type === 'short_answer') v = $('#shortAnswer')?.value; else { const c = $('input[name="answer"]:checked'); v = c ? Number(c.value) : undefined; }
  if (v === undefined || v === exam.answers[q.id]) return; exam.answers[q.id] = v;
  exam.saving = exam.saving.then(() => api().saveAnswer(exam.attempt, q.id, v)).catch(e => toast('Réponse non enregistrée : ' + e.message));
}
async function submitExam(auto) {
  if (!exam) return; saveCurrent(); const e = exam; clearInterval(e.timer); window.onbeforeunload = null;
  try { await e.saving; const r = await api().submit(e.attempt); exam = null; await reload(false); renderResult(e.a, r, auto); }
  catch (err) { exam = null; toast('Soumission : ' + err.message); navigate('assessments'); }
}
function renderResult(a, r, auto) {
  const p = r.max ? Math.round(r.score / r.max * 100) : 0;
  $('#pageContent').innerHTML = `<div class="panel" style="max-width:620px;margin:45px auto;text-align:center;padding:40px"><div class="welcome-icon" style="margin:0 auto 20px;color:var(--green);background:#e9f8f2"><i class="fa-solid fa-check"></i></div><span class="eyebrow blue">ÉPREUVE SOUMISE</span><h1 style="font-size:25px">${auto ? 'Temps écoulé !' : 'Merci pour votre participation.'}</h1><p class="muted">${esc(a.title)}</p><div style="font-size:42px;font-weight:800;color:var(--blue)">${r.score}/${r.max}</div><p class="muted">${p}% de réussite · ${p >= 50 ? 'Bravo, continuez ainsi !' : 'Continuez vos efforts.'}</p><button class="btn btn-primary fit" data-act="go" data-page="assessments">Retour aux évaluations</button></div>`;
}

/* ====================================================================
   ACTIONS (délégation d'événements)
   ==================================================================== */
const guard = fn => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message); } };
const actions = {
  notifications: guard(async()=>openNotifications()),
  readNotification: guard(async el=>{await markNotification(el.dataset.id);const page=el.dataset.page;closeModal();if(page==='assessment'&&el.dataset.related)S.assessmentId=el.dataset.related;navigate(page);}),
  markAllNotifications: guard(async()=>{unwrap(await sb.from('notifications').update({read_at:new Date().toISOString()}).eq('recipient_id',S.user.id).is('read_at',null));await loadNotifications();closeModal();toast('Notifications marquées comme lues.');}),
  newAnnouncement: guard(async()=>{if(!adminOnly())return;modal(`${mHead('Nouvelle annonce à tous les étudiants')}<p class="muted">Le message sera ajouté au centre de notifications de chaque étudiant actif.</p><form id="announcementForm"><div class="field"><label>Titre</label><input name="title" maxlength="120" required></div><div class="field"><label>Message</label><textarea name="body" rows="4" maxlength="1200" required></textarea></div>${mActions('Envoyer à tous les étudiants')}</form>`);}),
  editAcademicYear: guard(async()=>{if(!adminOnly())return;modal(`${mHead('Année académique de l’établissement')}<p class="muted">Cette modification s’applique à tous les étudiants. Les archives et les anciennes notes sont conservées.</p><form id="academicYearForm"><div class="field"><label>Année académique active</label><input name="year" required pattern="[0-9]{4}-[0-9]{4}" value="${esc(S.academicYear||'2026-2027')}" placeholder="2026-2027"></div>${mActions('Appliquer à tous')}</form>`);}),
  go: el => navigate(el.dataset.page),
  closeModal,
  demoRole: el => { closeModal(); const r = el.dataset.role; showApp({ id: 'demo', name: { student: 'Grâce Mavoungou', teacher: 'Formateur Démo', admin: 'Administration C-TECH' }[r], email: 'demo@ctech.cg' }, r, true); toast('Mode démonstration : données fictives et locales.'); },
  openCourse: el => { S.courseId = el.dataset.id; S.chapterId = null; navigate('course'); },
  openAssessment: el => { S.assessmentId = el.dataset.id; navigate('assessment'); },
  readChapter: el => { S.chapterId = el.dataset.id; navigate('course'); },
  toggleRead: el => { const s = readSet(); s.has(el.dataset.id) ? s.delete(el.dataset.id) : s.add(el.dataset.id); writeSet(s); navigate('course'); },
  importCourse: el => modalImport(el.dataset.id),
  impDelM: el => { syncImport(); S.imp.modules.splice(+el.dataset.m, 1); renderImportPreview(); },
  impDelC: el => { syncImport(); const m = S.imp.modules[+el.dataset.m]; m.chapters.splice(+el.dataset.c, 1); if (!m.chapters.length) S.imp.modules.splice(+el.dataset.m, 1); renderImportPreview(); },
  impConfirm: guard(async el => {
    syncImport(); const I = S.imp, modules = I.modules.filter(m => m.chapters.length), n = modules.reduce((t, m) => t + m.chapters.length, 0); if (!n) return;
    el.disabled = true; el.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Import…';
    try { await api().importStructure(I.courseId, modules); }
    catch (e) { el.disabled = false; el.textContent = 'Importer'; throw e; }
    let warn = '';
    if (I.attach) { try { await api().attachFile(I.courseId, I.file); } catch (e) { warn = ' Le fichier original n’a pas pu être joint : ' + e.message; } }
    S.imp = null; closeModal(); await reload(); toast(`${n} chapitre${n > 1 ? 's' : ''} importé${n > 1 ? 's' : ''}.` + warn);
  }),
  previewFile: guard(async el => { const c = D.courses.find(x => x.id === S.courseId), f = c.files.find(x => x.id === el.dataset.id); await previewCourseFile(f); }),
  downloadPreviewFile: guard(async el => { const c = D.courses.find(x => x.id === S.courseId), f = c.files.find(x => x.id === el.dataset.id); const url = await api().fileUrl(f, true); window.open(url, '_blank', 'noopener'); }),
  closeModal: () => closeModal(),
  downloadFile: guard(async el => { const c = D.courses.find(x => x.id === S.courseId), f = c.files.find(x => x.id === el.dataset.id); const url = await api().fileUrl(f, true); const a = document.createElement('a'); a.href = url; a.download = f.name; a.target = '_blank'; document.body.appendChild(a); a.click(); a.remove(); }),
  deleteFile: guard(async el => { if (!await confirmBox('Supprimer ce fichier du cours ?', 'Supprimer')) return; const c = D.courses.find(x => x.id === S.courseId); await api().deleteFile(c.id, c.files.find(x => x.id === el.dataset.id)); await reload(); }),
  newCourse: modalCourse, newModule: el => modalModule(el.dataset.id), newChapter: el => modalChapter(el.dataset.id),
  newAssessment: () => D.courses.length ? modalAssessment() : toast('Créez d’abord un cours.'),
  editAssessment: guard(async el => modalAssessment(el.dataset.id)),
  deleteAssessment: guard(async el => { if(!await confirmBox('Supprimer définitivement cette évaluation ? Les évaluations ayant des copies seront protégées pour conserver les résultats.','Supprimer'))return; await api().deleteAssessment(el.dataset.id); await reload(); navigate('assessments'); toast('Évaluation supprimée.'); }),
  editQuestion: guard(async el => { const q=(await api().listQuestions(S.assessmentId)).find(x=>x.id===el.dataset.id); if(q)modalQuestionEdit(q); }),
  newStudent: modalStudent,
  togglePublishCourse: guard(async el => { const c = D.courses.find(x => x.id === el.dataset.id); await api().setCoursePublished(c.id, !c.is_published); await reload(); toast(c.is_published ? 'Cours repassé en brouillon.' : 'Cours publié.'); }),
  reopenAssessment: el => modalReopenAssessment(el.dataset.id),
  togglePublishAssessment: guard(async el => {
    const a = D.assessments.find(x => x.id === el.dataset.id);
    if (!a.is_published && !a.questions_count) { toast('Ajoutez au moins une question avant de publier.'); return; }
    await api().setAssessmentPublished(a.id, !a.is_published); await reload(); toast(a.is_published ? 'Évaluation dépubliée.' : 'Évaluation publiée.');
  }),
  delQuestion: guard(async el => { if (!await confirmBox('Supprimer cette question ?', 'Supprimer')) return; await api().deleteQuestion(S.assessmentId, el.dataset.id); await reload(); }),
  start: el => { if(!window.CTECHExam){toast('Moteur d’examen indisponible.');return;} $('#pageContent').innerHTML='<div id="examRoot"></div>'; window.CTECHExam.start(el.dataset.id,'#examRoot',D.assessments.find(a=>a.id===el.dataset.id)); },
  publishResults: guard(async el => { const r=unwrap(await sb.rpc('teacher_publish_assessment_results',{p_assessment_id:el.dataset.id})); await reload(); toast(`Résultats publiés : ${r.results_count} copie(s).`); }),
  gotoQ: el => { saveCurrent(); exam.index = Number(el.dataset.i); renderExam(); },
  prevQ: () => { saveCurrent(); exam.index--; renderExam(); }, nextQ: () => { saveCurrent(); exam.index++; renderExam(); },
  finishExam: async () => {
    saveCurrent(); const missing = exam.questions.filter(q => exam.answers[q.id] === undefined || exam.answers[q.id] === '').length;
    if (await confirmBox(missing ? `${missing} question(s) sans réponse. Soumettre quand même ?` : 'Confirmer la soumission de votre évaluation ?', 'Soumettre')) submitExam(false);
  },
  exportCSV: () => {
    const cell = v => { let s = String(v); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return '"' + s.replace(/"/g, '""') + '"'; };
    const rows = [['Étudiant', 'Évaluation', 'Note', 'Pourcentage', 'Date'], ...D.results.map(r => [r.name, r.exam, `${r.score}/${r.max}`, pct(r) + '%', r.date ? fmtDay(r.date) : ''])];
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + rows.map(r => r.map(cell).join(';')).join('\n')], { type: 'text/csv;charset=utf-8' })); a.download = 'ctech-resultats.csv'; a.click(); URL.revokeObjectURL(a.href);
  }
};
actions.openClassRoom=async el=>{S.roomId=el.dataset.id;const h=await classRoomHTML(el.dataset.id);$('#pageContent').innerHTML=h;S.page='classRoom';$('#crumb').textContent='Ma classe';};
actions.toggleRoom=guard(async el=>{await sb.from('class_discussions').update({is_open:el.dataset.open!=='true'}).eq('id',el.dataset.id);S.roomId=el.dataset.id;$('#pageContent').innerHTML=await classRoomHTML(S.roomId);});
actions.readResource=async el=>{const {data:r,error}=await sb.from('learning_resources').select('*').eq('id',el.dataset.id).single();if(error)throw error;modal(`${mHead(esc(r.title))}<p class="muted">${esc(r.description||'')}</p><div class="chapter-body">${esc(r.body).replace(/\n/g,'<br>')}</div><div class="modal-actions"><button class="btn btn-primary" data-act="closeModal">Fermer</button></div>`, 'wide');};
actions.filterEvolution=el=>{const kind=el.dataset.kind;$$('.resource-card').forEach(x=>x.hidden=x.dataset.kind!==kind);const target=$(kind==='note'?'#notesResources':'#briefingResources');target?.scrollIntoView({behavior:'smooth',block:'start'});};
actions.newClass=()=>classesHTML().then(()=>classModal());
actions.editClass=async el=>{if(!adminOnly())return;const {domains,filieres}=await adminLookups();const row=unwrap(await sb.from('classes').select('*').eq('id',el.dataset.id).single());const links=unwrap(await sb.from('class_filieres').select('class_id,filiere_id').eq('class_id',row.id));S.adminCache={domains,filieres,links};classModal(row);};
actions.deleteClass=guard(async el=>{if(!adminOnly()||!await confirmBox('Supprimer définitivement cette classe ? Les associations de filières seront supprimées. Les inscriptions ou cours liés peuvent empêcher la suppression.','Supprimer la classe'))return;unwrap(await sb.from('classes').delete().eq('id',el.dataset.id));await reload(false);navigate('classes');toast('Classe supprimée.');});
actions.newTeacher=()=>teacherModal();
actions.toggleTeacher=guard(async el=>{if(!adminOnly())return;unwrap(await sb.from('profiles').update({is_active:el.dataset.active!=='true'}).eq('id',el.dataset.id).eq('role','teacher'));navigate('teachers');toast('Statut du formateur mis à jour.');});
actions.deleteTeacher=guard(async el=>{if(!adminOnly()||!await confirmBox('Supprimer définitivement le compte formateur et son profil ?','Supprimer le compte'))return;const {data,error}=await sb.functions.invoke('create-user',{body:{action:'delete',user_id:el.dataset.id}});if(error)throw new Error(error.message);if(data?.error)throw new Error(data.error);navigate('teachers');toast('Compte formateur supprimé.');});
actions.viewAudit=el=>{const l=S.auditCache?.find(x=>String(x.id)===el.dataset.id);if(!l)return;const summary=humanAuditSummary(l,S.auditActors||{});modal(`${mHead('Détail de l’opération')}<div class="audit-readable"><i class="fa-solid fa-circle-info"></i><div><strong>${esc(summary)}</strong><small>${esc(auditDateLong(l.occurred_at))}</small></div></div><details class="audit-technical"><summary>Voir les données techniques</summary><div class="field"><label>Avant</label><pre class="audit-json">${esc(JSON.stringify(l.old_data,null,2)||'—')}</pre></div><div class="field"><label>Après</label><pre class="audit-json">${esc(JSON.stringify(l.new_data,null,2)||'—')}</pre></div><p class="muted">Table : ${esc(auditTableName(l.table_name))} · Référence : ${esc(l.record_id||'—')}</p></details><div class="modal-actions"><button class="btn btn-primary fit" data-act="closeModal">Fermer</button></div>`,'wide');};
actions.refreshAdmin=()=>navigate(S.page);
async function adminLookups(){const [domains,filieres]=await Promise.all([sb.from('domains').select('id,code,name').order('name').then(unwrap),sb.from('filieres').select('id,code,name,domain_id').order('name').then(unwrap)]);return {domains,filieres};}
document.addEventListener('click', e => { const el = e.target.closest('[data-act]'); if (el && actions[el.dataset.act]) { e.preventDefault(); actions[el.dataset.act](el, e); } });
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeModal();
  if ((e.key === 'Enter' || e.key === ' ') && e.target.matches?.('.course-card.clickable')) { e.preventDefault(); e.target.click(); }
});
document.addEventListener('input', e => {
  if (e.target.id === 'assessmentSearch') filterAssessments();
  if (e.target.id === 'studentSearch') $$('#studentRows tr').forEach(r => r.hidden = !r.textContent.toLowerCase().includes(e.target.value.toLowerCase()));
  if (e.target.id === 'auditSearch') $$('#auditRows tr').forEach(r => r.hidden = !r.textContent.toLowerCase().includes(e.target.value.toLowerCase()));
});
document.addEventListener('change', e => {
  if (e.target.id === 'assessmentFilter') filterAssessments();
  if (e.target.id === 'qType') $('#qDynamic').innerHTML = questionFields(e.target.value);
  if(e.target.name==='domain_id'){const sel=document.querySelector('#profileForm [name=filiere_id]');if(sel){const keep=sel.value;sel.innerHTML='<option value="">Non renseignée</option>'+((S.profileData?[]:[]));sb.from('filieres').select('id,name,code,domain_id').eq('domain_id',e.target.value).order('name').then(({data,error})=>{if(error)return toast(error.message);sel.innerHTML='<option value="">Non renseignée</option>'+(data||[]).map(x=>`<option value="${x.id}">${esc(x.name)}${x.code?' · '+esc(x.code):''}</option>`).join('');if((data||[]).some(x=>x.id===keep))sel.value=keep;});}}
});
function filterAssessments() { const q = $('#assessmentSearch').value.toLowerCase(), f = $('#assessmentFilter').value; $$('#assessmentGrid .assessment-card').forEach(c => c.hidden = !(c.dataset.title.includes(q) && (f === 'all' || c.dataset.status === f))); }


/* ===== Profil personnel ===== */
async function profileHTML(){
 if(S.demo) return `${pageHead('Mon Profil','La personnalisation du profil est disponible avec un compte connecté.')}<div class="panel">Connectez-vous à votre compte C-TECH pour modifier vos informations personnelles.</div>`;
 const [p,domains,filieres]=await Promise.all([
  sb.from('profiles').select('*').eq('id',S.user.id).single().then(unwrap),
  sb.from('domains').select('id,name,code').order('name').then(unwrap),
  sb.from('filieres').select('id,name,code,domain_id').order('name').then(unwrap)
 ]);
 S.profileData=p;
 const field=(label,name,type='text',value='',extra='')=>`<div class="field"><label>${label}</label><input name="${name}" type="${type}" value="${esc(value??'')}" ${extra}></div>`;
 const opts=(arr,val)=>`<option value="">Non renseigné</option>`+arr.map(x=>`<option value="${x.id}" ${x.id===val?'selected':''}>${esc(x.name)}${x.code?' · '+esc(x.code):''}</option>`).join('');
 const avatar=p.avatar_url?`<img src="${esc(p.avatar_url)}${String(p.avatar_url).includes('?')?'&':'?'}v=${Date.now()}" alt="Photo de profil" class="profile-photo" onerror="this.outerHTML='<div class=\"profile-photo profile-placeholder\">${initials(p.full_name)}</div>'">`:`<div class="profile-photo profile-placeholder">${esc(initials(p.full_name))}</div>`;
 return `${pageHead('Mon Profil','Personnalisez vos informations personnelles et vos préférences.')}
 <form id="profileForm" class="profile-layout"><section class="panel profile-card"><div class="profile-avatar-wrap">${avatar}<div><strong>Photo de profil</strong><p class="muted">JPG, PNG ou WebP · 5 Mo maximum</p><input type="file" name="avatar" accept="image/jpeg,image/png,image/webp"></div></div><div class="form-grid">
 ${field('Nom complet','full_name','text',p.full_name,'required maxlength="140"')}
 ${field('Nom d’utilisateur','username','text',p.username,'maxlength="60"')}
 ${field('Date de naissance','birth_date','date',p.birth_date)}
 ${field('Lieu de naissance','birth_place','text',p.birth_place)}
 ${field('Adresse e-mail','email','email',S.user.email,'required')}
 ${field('Adresse','address','text',p.address)}
 ${field('Arrondissement','arrondissement','text',p.arrondissement)}
 ${field('Quartier','neighborhood','text',p.neighborhood)}
 ${field('Ville','city','text',p.city)}
 ${S.role==='student'?`<div class="field"><label>Niveau académique</label><input value="${esc(p.level_code||'Non renseigné')}" disabled></div><div class="field"><label>Domaine</label><input value="${esc(domains.find(x=>x.id===p.domain_id)?.name||'Non renseigné')}" disabled></div><div class="field"><label>Filière</label><input value="${esc(filieres.find(x=>x.id===p.filiere_id)?.name||'Non renseignée')}" disabled></div>`:''}
 <div class="field"><label>Langue de l’interface</label><select name="preferred_language"><option value="fr" ${p.preferred_language!=='en'?'selected':''}>Français</option><option value="en" ${p.preferred_language==='en'?'selected':''}>English</option></select></div>
 <div class="field"><label>Année académique active</label><input value="${esc(S.academicYear||p.academic_year||'Non définie')}" disabled><small class="muted">Gérée exclusivement par l’administration et appliquée à tous les étudiants.</small></div>
 </div><div class="profile-section"><h3>Sécurité du compte</h3><p class="muted">Laissez le champ vide si vous ne souhaitez pas changer votre mot de passe.</p><div class="form-grid"><div class="field"><label>Nouveau mot de passe</label><input name="new_password" type="password" minlength="8" autocomplete="new-password" placeholder="8 caractères minimum"></div><div class="field"><label>Confirmer le mot de passe</label><input name="confirm_password" type="password" minlength="8" autocomplete="new-password"></div></div></div>
 <div class="modal-actions"><button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Enregistrer mon profil</button></div></section></form>`;
}

/* ===== Administration avancée — raccordement au schéma C-TECH réel ===== */
navItems.admin.push(
  ['STRUCTURE', 'classes', 'Classes & filières', 'fa-layer-group'],
  ['SÉCURITÉ', 'audit', 'Journal des opérations', 'fa-clipboard-list']
);
CRUMBS.classes = 'Classes & filières'; CRUMBS.teachers = 'Formateurs'; CRUMBS.audit = 'Journal des opérations';
const adminOnly = () => { if (S.role !== 'admin' || S.demo) { toast('Cette fonction nécessite un compte administrateur connecté à Supabase.'); return false; } return true; };
async function classesHTML() {
  if (!adminOnly()) return empty('fa-lock','Administration réelle requise.');
  const [classes, domains, filieres] = await Promise.all([
    sb.from('classes').select('id,name,academic_year,description,domain_id,filiere_id,level_code').order('academic_year',{ascending:false}).then(unwrap),
    sb.from('domains').select('id,code,name').order('name').then(unwrap),
    sb.from('filieres').select('id,code,name,domain_id').order('name').then(unwrap)
  ]);
  const links = unwrap(await sb.from('class_filieres').select('class_id,filiere_id'));
  S.adminCache={domains,filieres,classes};
  const domainMap=Object.fromEntries(domains.map(d=>[d.id,d.name])); const legacyMap=Object.fromEntries(filieres.map(f=>[f.id,f.code]));
  const rows=classes.map(c=>{const fs=links.filter(x=>x.class_id===c.id).map(x=>legacyMap[x.filiere_id]).filter(Boolean);return `<tr><td><strong>${esc(c.name)}</strong><br><span class="muted-cell">${esc(c.level_code||'')}</span></td><td>${esc(domainMap[c.domain_id]||'—')}</td><td>${fs.map(esc).join(', ')||esc(legacyMap[c.filiere_id]||'—')}</td><td>${esc(c.academic_year||'—')}</td><td><div class="head-actions"><button class="table-action" data-act="editClass" data-id="${esc(c.id)}">Modifier</button><button class="table-action" data-act="deleteClass" data-id="${esc(c.id)}" style="color:#c0392b">Supprimer</button></div></td></tr>`}).join('');
  return `${pageHead('Classes & filières','Créez, consultez, modifiez et supprimez les classes. Une classe peut regrouper plusieurs filières.','<button class="btn btn-primary" data-act="newClass"><i class="fa-solid fa-plus"></i> Nouvelle classe</button>')}
  <div class="stat-grid">${stat('fa-layer-group',classes.length,'Classes')}${stat('fa-sitemap',filieres.length,'Filières disponibles')}${stat('fa-building',domains.length,'Domaines')}</div>
  ${rows?`<div class="table-wrap"><table class="data-table"><thead><tr><th>CLASSE / NIVEAU</th><th>DOMAINE</th><th>FILIÈRES ASSOCIÉES</th><th>ANNÉE ACADÉMIQUE</th><th>ACTIONS</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('fa-layer-group','Aucune classe enregistrée.')}`;
}
async function teachersHTML(){
 if(!adminOnly())return empty('fa-lock','Administration réelle requise.');
 const teachers=unwrap(await sb.from('profiles').select('id,full_name,username,phone,is_active,created_at').eq('role','teacher').order('full_name'));
 const rows=teachers.map(t=>`<tr><td><strong>${esc(t.full_name)}</strong></td><td>${esc(t.username||'—')}</td><td>${esc(t.phone||'—')}</td><td><span class="status ${t.is_active?'green':'gray'}">${t.is_active?'Actif':'Désactivé'}</span></td><td><div class="head-actions"><button class="table-action" data-act="toggleTeacher" data-id="${esc(t.id)}" data-active="${t.is_active}">${t.is_active?'Désactiver':'Activer'}</button><button class="table-action" data-act="deleteTeacher" data-id="${esc(t.id)}" style="color:#c0392b">Supprimer</button></div></td></tr>`).join('');
 return `${pageHead('Gestion des formateurs','Créez les comptes formateurs et gérez leur accès à la plateforme.','<button class="btn btn-primary" data-act="newTeacher"><i class="fa-solid fa-user-plus"></i> Créer un formateur</button>')}
 ${rows?`<div class="table-wrap"><table class="data-table"><thead><tr><th>FORMATEUR</th><th>IDENTIFIANT</th><th>TÉLÉPHONE</th><th>STATUT</th><th>ACTIONS</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('fa-chalkboard-user','Aucun formateur enregistré.')}`;
}
function auditTableName(t){return ({profiles:'comptes utilisateurs',courses:'cours',subjects:'matières',classes:'classes',class_filieres:'associations de filières',filieres:'filières',domains:'domaines',teacher_assignments:'affectations des formateurs',assessments:'évaluations',questions:'questions',modules:'modules',lessons:'leçons',results:'résultats',class_memberships:'inscriptions en classe'})[t]||String(t||'données').replaceAll('_',' ');}
function auditDateLong(v){return new Date(v).toLocaleString('fr-CG',{weekday:'long',day:'numeric',month:'long',year:'numeric',hour:'2-digit',minute:'2-digit'});}
function humanAuditSummary(l,actors={}){
 const actor=actors[l.actor_id]||'un utilisateur du système', d=l.new_data||l.old_data||{};
 const target=d.full_name||d.name||d.title||d.username||d.matricule||d.code||'l’élément concerné';
 const table=auditTableName(l.table_name); const who=l.table_name==='profiles'?(d.role==='teacher'?'le formateur':d.role==='student'?'l’étudiant':d.role==='admin'?'l’administrateur':'l’utilisateur'):'l’élément';
 const verb=l.action==='INSERT'?'Création':l.action==='UPDATE'?'Modification':l.action==='DELETE'?'Suppression':'Opération';
 if(l.table_name==='profiles') return `${verb} d’un compte utilisateur pour ${who} ${target}, par ${actor}.`;
 if(l.table_name==='courses'||l.table_name==='subjects') return `${verb} du cours / de la matière « ${target} », par ${actor}.`;
 return `${verb} : ${table} « ${target} », par ${actor}.`;
}
async function auditHTML(){
 if(!adminOnly())return empty('fa-lock','Administration réelle requise.');
 const logs=unwrap(await sb.from('audit_logs').select('id,actor_id,action,table_name,record_id,old_data,new_data,occurred_at').order('occurred_at',{ascending:false}).limit(250));
 const ids=[...new Set(logs.flatMap(x=>[x.actor_id,x.table_name==='profiles'?x.record_id:null]).filter(Boolean))]; let actors={};
 if(ids.length){const ps=unwrap(await sb.from('profiles').select('id,full_name,role').in('id',ids));actors=Object.fromEntries(ps.map(x=>[x.id,`${x.full_name}${x.role==='admin'?' (administrateur)':x.role==='teacher'?' (formateur)':x.role==='student'?' (étudiant)':''}`]));}
 S.auditActors=actors; S.auditCache=logs;
 const rows=logs.map(l=>{const summary=humanAuditSummary(l,actors);return `<tr><td>${esc(auditDateLong(l.occurred_at))}</td><td>${esc(actors[l.actor_id]||'Système')}</td><td><span class="status ${l.action==='DELETE'?'gray':l.action==='INSERT'?'green':''}">${l.action==='INSERT'?'Création':l.action==='UPDATE'?'Modification':l.action==='DELETE'?'Suppression':esc(l.action)}</span></td><td>${esc(summary)}</td><td><button class="table-action" data-act="viewAudit" data-id="${l.id}">Détails</button></td></tr>`}).join('');
 return `${pageHead('Journal des opérations','Un historique compréhensible des actions réalisées sur la plateforme. Les 250 événements les plus récents sont affichés.','<button class="btn btn-light" data-act="refreshAdmin"><i class="fa-solid fa-rotate"></i> Actualiser</button>')}
 <div class="toolbar"><div class="search-box"><i class="fa-solid fa-magnifying-glass"></i><input id="auditSearch" placeholder="Rechercher un nom, une action ou un élément…"></div></div>
 ${rows?`<div class="table-wrap"><table class="data-table"><thead><tr><th>DATE ET HEURE</th><th>AUTEUR</th><th>OPÉRATION</th><th>RÉSUMÉ</th><th>DÉTAILS</th></tr></thead><tbody id="auditRows">${rows}</tbody></table></div>`:empty('fa-clipboard-list','Aucune opération enregistrée pour le moment.')}`;
}
function classModal(row=null){const {domains,filieres}=S.adminCache||{domains:[],filieres:[]};const chosen=row?(S.adminCache.links||[]).filter(x=>x.class_id===row.id).map(x=>x.filiere_id):[];
 modal(`${mHead(row?'Modifier la classe':'Créer une classe')}<form id="classForm" data-id="${esc(row?.id||'')}"><div class="form-grid">
 <div class="field full"><label>Nom de la classe</label><input name="name" required maxlength="120" value="${esc(row?.name||'')}"></div>
 <div class="field"><label>Niveau</label><select name="level_code" required>${['L1','L2','L3','M1','M2','BTS1','BTS2'].map(x=>`<option ${row?.level_code===x?'selected':''}>${x}</option>`).join('')}</select></div>
 <div class="field"><label>Année académique</label><input name="academic_year" required value="${esc(row?.academic_year||'2026-2027')}" placeholder="2026-2027"></div>
 <div class="field full"><label>Domaine</label><select name="domain_id" id="classDomain" required><option value="">Choisir un domaine</option>${domains.map(d=>`<option value="${d.id}" ${row?.domain_id===d.id?'selected':''}>${esc(d.name)} (${esc(d.code)})</option>`).join('')}</select></div>
 <div class="field full"><label>Filières associées (sélection multiple)</label><select name="filiere_ids" id="classFilieres" multiple size="7" required>${filieres.filter(f=>!row||f.domain_id===row.domain_id).map(f=>`<option value="${f.id}" ${chosen.includes(f.id)||(!chosen.length&&row?.filiere_id===f.id)?'selected':''}>${esc(f.name)} (${esc(f.code)})</option>`).join('')}</select><small class="muted">Maintenez plusieurs éléments sélectionnés. Les filières proposées appartiennent au domaine choisi.</small></div>
 <div class="field full"><label>Description</label><textarea name="description">${esc(row?.description||'')}</textarea></div></div>${mActions(row?'Enregistrer les modifications':'Créer la classe')}</form>`,'wide');
 $('#classDomain').onchange=()=>{const d=$('#classDomain').value;$('#classFilieres').innerHTML=filieres.filter(f=>f.domain_id===d).map(f=>`<option value="${f.id}">${esc(f.name)} (${esc(f.code)})</option>`).join('');};
}
function teacherModal(){modal(`${mHead('Créer un compte formateur')}<form id="teacherForm"><div class="form-grid"><div class="field full"><label>Nom complet</label><input name="full_name" required maxlength="140"></div><div class="field"><label>Adresse e-mail</label><input name="email" type="email" required></div><div class="field"><label>Téléphone</label><input name="phone" type="tel"></div><div class="field full"><label>Mot de passe provisoire (8 caractères minimum)</label><input name="password" type="text" minlength="8" required value="${esc(tempPassword())}"></div></div><p class="muted">Le formateur se connectera avec son adresse e-mail et ce mot de passe provisoire.</p>${mActions('Créer le compte formateur')}</form>`);}

const forms = {
  announcementForm: async f=>{if(!adminOnly())return;const n=unwrap(await sb.rpc('admin_broadcast_notification',{p_title:f.title.trim(),p_body:f.body.trim()}));closeModal();toast(`Annonce envoyée à ${n} étudiant(s).`);},
  academicYearForm: async f=>{if(!adminOnly())return;unwrap(await sb.rpc('admin_set_academic_year',{p_year:f.year.trim()}));closeModal();await reload();toast('Année académique appliquée à tous les étudiants.');},
  profileForm: async (f, form) => {
    if(S.demo) throw new Error('Connectez-vous pour modifier votre profil.');
    if(f.new_password && f.new_password!==f.confirm_password) throw new Error('Les deux mots de passe ne correspondent pas.');
    const patch={full_name:f.full_name.trim(),username:f.username.trim()||null,birth_date:f.birth_date||null,birth_place:f.birth_place.trim()||null,address:f.address.trim()||null,arrondissement:f.arrondissement.trim()||null,neighborhood:f.neighborhood.trim()||null,city:f.city.trim()||null,preferred_language:f.preferred_language};
    const file=form.querySelector('[name=avatar]').files[0];
    if(file){
      const mime=file.type||''; if(!['image/jpeg','image/png','image/webp'].includes(mime))throw new Error('Format non pris en charge. Utilisez une image JPG, PNG ou WebP.');
      if(file.size>5*1024*1024)throw new Error('La photo ne doit pas dépasser 5 Mo.');
      const ext=mime==='image/png'?'png':mime==='image/webp'?'webp':'jpg';
      const path=`${S.user.id}/avatar.${ext}`;
      const bucket=sb.storage.from('profile-avatars');
      const up=await bucket.upload(path,file,{upsert:true,contentType:mime,cacheControl:'3600'});
      if(up.error)throw new Error(`Envoi de la photo impossible : ${up.error.message}`);
      const pub=bucket.getPublicUrl(path); if(!pub?.data?.publicUrl)throw new Error('URL publique de la photo indisponible.');
      patch.avatar_url=pub.data.publicUrl;
    }
    const emailChanged=f.email.trim().toLowerCase()!==String(S.user.email||'').toLowerCase();
    if(emailChanged){const {error}=await sb.auth.updateUser({email:f.email.trim().toLowerCase()});if(error)throw error;}
    if(f.new_password){const {error}=await sb.auth.updateUser({password:f.new_password});if(error)throw error;}
    unwrap(await sb.from('profiles').update(patch).eq('id',S.user.id));
    const savedProfile=unwrap(await sb.from('profiles').select('avatar_url,full_name').eq('id',S.user.id).single());
    S.user.name=savedProfile.full_name;S.user.email=emailChanged?f.email.trim().toLowerCase():S.user.email;S.user.avatar_url=savedProfile.avatar_url;$('#sideName').textContent=savedProfile.full_name;setAvatar($('#sideAvatar'),S.user.avatar_url,savedProfile.full_name);setAvatar($('#topAvatar'),S.user.avatar_url,savedProfile.full_name);
    toast(emailChanged?'Profil enregistré. Vérifiez votre nouvelle adresse e-mail pour confirmer le changement.':'Profil enregistré avec succès.');navigate('profile');
  },
  loginForm: async () => { const b = $('#loginBtn'); b.disabled = true; b.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Connexion...'; try { await login($('#email').value, $('#password').value); } finally { b.disabled = false; b.innerHTML = 'Se connecter <i class="fa-solid fa-arrow-right"></i>'; } },
  courseForm: async f => { await api().createCourse({ title: f.title.trim(), class_id: f.class_id, teacher_id: f.teacher_id, description: f.description.trim(), is_published: f.published === '1' }); closeModal(); await reload(); toast('Cours créé.'); },
  moduleForm: async (f, form) => { await api().addModule(form.dataset.id, f.title.trim()); closeModal(); await reload(); },
  chapterForm: async (f, form) => { await api().addChapter(form.dataset.id, f.title.trim(), f.content.trim()); closeModal(); await reload(); },
  assessmentForm: async (f,form) => {
    const start=new Date(f.start),end=new Date(f.end); if(!(end>start))throw new Error('La fin doit être postérieure au début.');
    const selected=n=>[...form.querySelector(`[name="${n}"]`).selectedOptions].map(o=>o.value);
    const target={domain_ids:selected('domain_ids'),filiere_ids:selected('filiere_ids'),level_codes:selected('level_codes')};
    if(!target.domain_ids.length||!target.filiere_ids.length||!target.level_codes.length)throw new Error('Sélectionnez au moins un domaine, une filière et un niveau.');
    const filiereDomainRows=S.demo?filieres.filter(x=>target.filiere_ids.includes(x.id)):await sb.from('filieres').select('id,domain_id').in('id',target.filiere_ids).then(unwrap);
    const validFiliereIds=new Set(filiereDomainRows.filter(x=>target.domain_ids.includes(x.domain_id)).map(x=>x.id));
    if(validFiliereIds.size!==target.filiere_ids.length)throw new Error('Chaque filière sélectionnée doit appartenir à l’un des domaines choisis.');
    const data={course_id:f.course_id,title:f.title.trim(),description:f.description.trim(),start_at:start.toISOString(),end_at:end.toISOString(),duration_minutes:+f.duration,max_attempts:+f.attempts,points:num(f.points),assessment_type:f.assessment_type,target};
    if(form.dataset.id){await api().updateAssessment(form.dataset.id,data);closeModal();await reload(false);S.assessmentId=form.dataset.id;navigate('assessment');toast('Évaluation et affectations mises à jour.');}
    else {const a=await api().createAssessment(data);await api().saveAssessmentTargets(a.id,target);closeModal();await reload(false);S.assessmentId=a.id;navigate('assessment');toast('Évaluation créée. Ajoutez les questions puis publiez-la.');}
  },
  reopenAssessmentForm: async (f,form) => { const start=new Date(f.start),end=new Date(f.end); if(!(end>start))throw new Error('La date de fin doit être postérieure à la date de début.'); await api().reopenAssessment(form.dataset.id,start.toISOString(),end.toISOString()); closeModal(); await reload(false); S.assessmentId=form.dataset.id; navigate('assessment'); toast('Évaluation relancée. Une tentative supplémentaire est disponible pour chaque étudiant.'); },
  studentForm: async f => { await api().createStudent({ full_name: f.full_name.trim(), student_code: f.student_code.trim().toUpperCase(), class_name: f.class_name.trim(), password: f.password }); closeModal(); await reload(); toast('Compte étudiant créé.'); },
  questionForm: async f => {
    const q = { type: f.type, prompt: f.prompt.trim(), points: num(f.points) };
    if (!(q.points > 0)) { toast('Points invalides.'); return; }
    if (q.type === 'mcq') {
      q.options = f.options.split('\n').map(x => x.trim()).filter(Boolean);
      const correctIndex = parseInt(f.correct, 10) - 1;
      if (q.options.length < 2) { toast('Un QCM demande au moins 2 options.'); return; }
      if (!Number.isInteger(correctIndex) || correctIndex < 0 || correctIndex >= q.options.length) { toast('Numéro de bonne option invalide.'); return; }
      q.correct = q.options[correctIndex];
    } else if (q.type === 'true_false') { q.options = ['Vrai', 'Faux']; q.correct = q.options[parseInt(f.correctTF, 10)]; }
    else { q.options = []; q.accepted = f.accepted.split(';').map(x => x.trim()).filter(Boolean); if (!q.accepted.length) { toast('Indiquez au moins une réponse acceptée.'); return; } }
    await api().addQuestion(S.assessmentId, q); await reload(); toast('Question ajoutée.');
  },
  classForm: async f => {
    if(!adminOnly())return; const id=$('#classForm').dataset.id; const ids=[...$('#classFilieres').selectedOptions].map(o=>o.value); if(!ids.length)throw new Error('Sélectionnez au moins une filière.');
    const classId=unwrap(await sb.rpc('admin_save_class',{p_class_id:id||null,p_name:f.name.trim(),p_academic_year:f.academic_year.trim(),p_description:f.description.trim()||null,p_domain_id:f.domain_id,p_level_code:f.level_code,p_filiere_ids:ids}));
    closeModal(); await reload(false); navigate('classes'); toast(id?'Classe modifiée.':'Classe créée.');
  },
  teacherForm: async f => { if(!adminOnly())return; const {data,error}=await sb.functions.invoke('create-user',{body:{role:'teacher',full_name:f.full_name.trim(),email:f.email.trim().toLowerCase(),phone:f.phone.trim()||null,password:f.password}}); if(error)throw new Error((await error.context?.json?.().catch(()=>null))?.error||error.message); if(data?.error)throw new Error(data.error); closeModal(); navigate('teachers'); toast('Compte formateur créé.'); }
};
document.addEventListener('submit', async e => {
 if(e.target.matches('#classRoomForm')){e.preventDefault();try{const f=Object.fromEntries(new FormData(e.target));if(!f.class_id)throw new Error('Choisissez une classe.');const {error}=await sb.from('class_discussions').upsert({class_id:f.class_id,title:f.title,description:f.description||'',created_by:S.user.id},{onConflict:'class_id'});if(error)throw error;toast('Espace de discussion créé.');navigate('maClasse');}catch(err){toast(err.message);}return;}
 if(e.target.matches('#classMessageForm')){e.preventDefault();try{const f=Object.fromEntries(new FormData(e.target));const {error}=await sb.from('class_messages').insert({discussion_id:e.target.dataset.room,sender_id:S.user.id,body:f.body.trim()});if(error)throw error;const id=e.target.dataset.room;$('#pageContent').innerHTML=await classRoomHTML(id);}catch(err){toast(err.message);}return;}
 if(e.target.matches('#resourceForm')){e.preventDefault();try{const f=Object.fromEntries(new FormData(e.target));const {error}=await sb.from('learning_resources').insert({title:f.title,kind:f.kind,description:f.description||'',body:f.body,class_id:f.class_id||null,course_id:f.course_id||null,is_published: e.target.querySelector('[name=is_published]').checked,created_by:S.user.id});if(error)throw error;toast('Ressource enregistrée.');navigate('monEvolution');}catch(err){toast(err.message);}return;}
 if(e.target.matches('#professorForm')){e.preventDefault();const form=e.target, message=new FormData(form).get('message').trim();if(!message)return;const chat=$('#professorChat');chat.insertAdjacentHTML('beforeend',`<div class="ai-bubble user-bubble"><strong>Vous</strong><div>${esc(message)}</div></div><div class="ai-bubble" id="aiPending"><strong>Le Professeur</strong><div><i class="fa-solid fa-circle-notch fa-spin"></i> Je prépare votre explication…</div></div>`);form.reset();chat.scrollTop=chat.scrollHeight;try{const prior=unwrap(await sb.from('ai_chat_messages').select('role,content').eq('user_id',S.user.id).order('created_at',{ascending:false}).limit(8));prior.reverse();const {error:saveErr}=await sb.from('ai_chat_messages').insert({user_id:S.user.id,role:'user',content:message});if(saveErr)throw saveErr;const {data,error}=await sb.functions.invoke('professeur-ia',{body:{message,history:prior}});if(error){let detail=data?.error;try{if(!detail&&error.context?.json){const body=await error.context.json();detail=body?.error;}}catch(_){}throw new Error(detail||error.message||'Le service IA est momentanément indisponible.');}if(data?.error)throw new Error(data.error);const reply=data.reply||'Je n’ai pas pu répondre.';const {error:saveReply}=await sb.from('ai_chat_messages').insert({user_id:S.user.id,role:'assistant',content:reply});if(saveReply)throw saveReply;$('#aiPending')?.remove();chat.insertAdjacentHTML('beforeend',`<div class="ai-bubble"><strong>Le Professeur</strong><div>${esc(reply).replace(/\\n/g,'<br>')}</div></div>`);}catch(err){$('#aiPending')?.remove();chat.insertAdjacentHTML('beforeend',`<div class="ai-bubble"><strong>Le Professeur</strong><div>${esc(err.message)}</div></div>`);}chat.scrollTop=chat.scrollHeight;return;}
});
document.addEventListener('submit', async e => {
  if(e.target.matches('#editQuestionForm')){e.preventDefault();try{const f=Object.fromEntries(new FormData(e.target));const q={prompt:f.prompt.trim(),type:f.type,points:num(f.points)};if(q.type==='short_answer')q.accepted=f.accepted.split(';').map(x=>x.trim()).filter(Boolean);else{q.options=q.type==='true_false'?['Vrai','Faux']:f.options.split('\n').map(x=>x.trim()).filter(Boolean);const ix=Number(f.correct)-1;if(ix<0||ix>=q.options.length)throw new Error('Bonne réponse invalide.');q.correct=q.options[ix];}await api().updateQuestion(e.target.dataset.id,q);closeModal();await reload();toast('Question modifiée.');}catch(err){toast(err.message);}return;}
  if(e.target.matches('.gradeForm')){e.preventDefault();try{const f=new FormData(e.target);unwrap(await sb.rpc('teacher_grade_answer',{p_attempt_id:e.target.dataset.attempt,p_question_id:e.target.dataset.question,p_points_awarded:Number(f.get('points'))}));toast('Note enregistrée.');await reload();}catch(err){toast(err.message);}return;}
  const form = e.target, fn = forms[form.id]; if (!fn) return; e.preventDefault();
  const fields = Object.fromEntries(new FormData(form)); const btn = form.querySelector('button:not([type]),button[type=submit]');
  if (btn && form.id !== 'loginForm') btn.disabled = true;
  try { await fn(fields, form); } catch (err) { toast(err.message); } finally { if (btn) btn.disabled = false; }
});

/* ---------- Démarrage ---------- */
$('#demoBtn').onclick = modalDemo;
$('.toggle-password').onclick = () => { const p = $('#password'); p.type = p.type === 'password' ? 'text' : 'password'; $('.toggle-password i').className = p.type === 'password' ? 'fa-regular fa-eye' : 'fa-regular fa-eye-slash'; };
$('.notification-btn').onclick = () => actions.notifications();
$('#logoutBtn').onclick = async () => { if (exam || window.CTECHExam?.isActive?.()) { toast('Soumettez votre évaluation avant de vous déconnecter.'); return; } if (sb && !S.demo) { if(notificationChannel)await sb.removeChannel(notificationChannel); notificationChannel=null; await sb.auth.signOut(); } S.user = null; D = { courses: [], assessments: [], students: [], results: [] }; showAuth(); toast('Vous êtes déconnecté.'); };
const openSidebar = () => { $('#sidebar').classList.add('open'); document.body.classList.add('sidebar-open'); };
const closeSidebar = () => { $('#sidebar').classList.remove('open'); document.body.classList.remove('sidebar-open'); };
$('#openSidebar').onclick = openSidebar; $('#closeSidebar').onclick = closeSidebar;
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeSidebar(); });
$$('[data-year]').forEach(x => x.textContent = new Date().getFullYear());
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
async function runStartupExperience() {
  const logoSplash = $('#startupSplash');
  const welcomeSplash = $('#welcomeSplash');
  let session = null;
  if (sb) {
    try { const result = await sb.auth.getSession(); session = result.data?.session || null; }
    catch (e) { console.warn('Session non restaurée :', e); }
  }
  // Splash 1 : identité visuelle, affichée à chaque chargement ou actualisation.
  await wait(1450);
  logoSplash?.classList.add('splash-exit');
  await wait(420);
  logoSplash?.classList.add('hidden');
  if (session) {
    const { data: p, error } = await sb.from('profiles').select('*').eq('id', session.user.id).single();
    if (!error && p && p.is_active) {
      await showApp({ name: p.full_name, email: session.user.email, id: session.user.id, avatar_url: p.avatar_url }, p.role, false);
      return; // Utilisateur connecté : accès direct à l'application après le logo.
    }
    try { await sb.auth.signOut(); } catch (_) {}
  }
  // Splash 2 : message d'accueil uniquement pour les visiteurs non connectés.
  welcomeSplash?.classList.remove('hidden');
  await wait(1850);
  welcomeSplash?.classList.add('welcome-exit');
  await wait(380);
  welcomeSplash?.classList.add('hidden');
  showAuth();
}
runStartupExperience();
