/* C-TECH Academy — import de supports de cours (PDF, Word .docx, texte) → modules et chapitres.
   Tout se passe dans le navigateur : le fichier n'est lu que localement.
   - DOCX : lecteur ZIP natif (DecompressionStream) + analyse de word/document.xml (styles Titre 1 / Titre 2, listes, tableaux).
   - PDF  : pdf.js (chargé à la demande depuis jsDelivr), détection des titres par taille de police et numérotation.
   - TXT/MD : détection des titres par numérotation et mots-clés. */
(function (root) {
  'use strict';
  const MAX_BYTES = 15 * 1024 * 1024;
  const PDFJS_BASE = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@6.2.108/build/';

  /* ---------- Détection des titres (texte) ---------- */
  const RE_MOD = /^(module|partie|unité|unite|part|unit)\s+([0-9]+|[ivxlc]+)\b/i;
  const RE_CHAP = /^(chapitre|chapter|leçon|lecon|séquence|sequence|section)\s+([0-9]+|[ivxlc]+)\b/i;
  const RE_N2 = /^\d+\.\d+(\.\d+)?[.)]?\s+\S/;
  const RE_N1 = /^\d+[.)]\s+\S/;
  const looksLikeTitle = t => t.length >= 3 && t.length <= 110 && !/[.;,]$/.test(t);
  function kindOf(text) {
    if (!looksLikeTitle(text)) return null;
    if (RE_MOD.test(text)) return 'mod';
    if (RE_CHAP.test(text)) return 'chap';
    if (RE_N2.test(text)) return 'n2';
    if (RE_N1.test(text) && text.length <= 80 && /^\d+[.)]\s+[A-ZÀ-ÖØ-Þ]/.test(text)) return 'n1';
    return null;
  }
  const BULLET = /^\s*([•●▪◦·–—*-]|\d{1,2}[.)])\s+/;
  const isBullet = t => /^\s*[•●▪◦·–—*-]\s+/.test(t);
  const clean = t => String(t).replace(/\s+/g, ' ').trim();

  /* Affecte un niveau (1 = module, 2 = chapitre, 0 = paragraphe) aux lignes candidates.
     cand: [{text, kind, size}] — kind issu des mots-clés/numérotation, size = taille de police (PDF) ou null. */
  function assignLevels(cands) {
    const kinds = new Set(cands.map(c => c.kind).filter(Boolean));
    const hasKw = kinds.has('mod') || kinds.has('chap');
    return cands.map(c => {
      if (hasKw) return c.kind === 'mod' ? 1 : c.kind === 'chap' ? 2 : 0;
      if (kinds.has('n1') || kinds.has('n2')) return c.kind === 'n2' ? 2 : c.kind === 'n1' ? (kinds.has('n2') ? 1 : 2) : 0;
      return 0;
    });
  }

  /* ---------- Construction de la structure ---------- */
  function titleFromName(name) {
    const t = String(name || 'Support de cours').replace(/\.[a-z0-9]+$/i, '').replace(/[_]+/g, ' ').replace(/\s+/g, ' ').trim();
    return t ? t.charAt(0).toUpperCase() + t.slice(1) : 'Support de cours';
  }
  const joinBlocks = blocks => blocks.reduce((out, b, i) => {
    const bullet = b.bullet; const prev = blocks[i - 1];
    return out + (i === 0 ? '' : (bullet && prev && prev.bullet ? '\n' : '\n\n')) + (bullet ? '• ' + b.text.replace(BULLET, '') : b.text);
  }, '');

  /* blocks: [{lvl:0|1|2, text, bullet?}] → { modules:[{title, chapters:[{title, content}]}] } */
  function structure(blocks, docTitle) {
    const title = docTitle || 'Support de cours';
    const heads = blocks.filter(b => b.lvl > 0);
    // Un seul niveau de titres → ce sont des chapitres dans un module unique.
    const has1 = heads.some(b => b.lvl === 1), has2 = heads.some(b => b.lvl === 2);
    if (has1 && !has2) blocks = blocks.map(b => b.lvl === 1 ? { ...b, lvl: 2 } : b);
    const modules = []; let mod = null, ch = null, buf = [];
    const flush = () => {
      if (!ch) { buf = []; return; }
      ch.content = joinBlocks(buf); buf = [];
    };
    const ensureMod = t => { if (!mod) { mod = { title: t || title, chapters: [] }; modules.push(mod); } };
    for (const b of blocks) {
      if (b.lvl === 1) { flush(); mod = { title: clean(b.text), chapters: [] }; modules.push(mod); ch = null; }
      else if (b.lvl === 2) { flush(); ensureMod(); ch = { title: clean(b.text), content: '' }; mod.chapters.push(ch); }
      else {
        if (!ch) { ensureMod(); ch = { title: 'Introduction', content: '', intro: true }; mod.chapters.push(ch); }
        buf.push(b);
      }
    }
    flush();
    // Nettoyage : introductions trop courtes, modules vides.
    modules.forEach(m => { m.chapters = m.chapters.filter(c => !(c.intro && c.content.length < 40)); m.chapters.forEach(c => delete c.intro); });
    let out = modules.filter(m => m.chapters.length);
    if (!heads.length) out = chunk(blocks, title);
    return { modules: out };
  }
  /* Aucun titre détecté : découpage en parties d'environ 2 200 caractères. */
  function chunk(blocks, title) {
    const chapters = []; let cur = [], len = 0;
    const push = () => { if (cur.length) { chapters.push({ title: 'Partie ' + (chapters.length + 1), content: joinBlocks(cur) }); cur = []; len = 0; } };
    for (const b of blocks) { cur.push(b); len += b.text.length; if (len >= 2200) push(); }
    push();
    return chapters.length ? [{ title, chapters }] : [];
  }

  /* ---------- Texte brut / Markdown ---------- */
  function blocksFromText(text) {
    const paras = String(text).replace(/\r\n?/g, '\n').split(/\n{2,}/).flatMap(p => {
      const lines = p.split('\n').map(l => l.trim()).filter(Boolean);
      // une ligne courte qui ressemble à un titre est isolée même sans ligne vide
      const out = []; let acc = [];
      lines.forEach(l => { const md = l.match(/^(#{1,3})\s+(.*)$/); if (isBullet(l)) { if (acc.length) out.push(acc.join(' ')); acc = []; out.push(l); } else if (md || kindOf(l)) { if (acc.length) out.push(acc.join(' ')); acc = []; out.push(md ? { md: md[1].length, text: md[2] } : l); } else acc.push(l); });
      if (acc.length) out.push(acc.join(' '));
      return out;
    });
    const cands = paras.map(p => typeof p === 'string' ? { text: clean(p), kind: kindOf(clean(p)) } : { text: clean(p.text), kind: p.md === 1 ? 'mod' : 'chap' });
    const hasMd = paras.some(p => typeof p !== 'string');
    const lv = hasMd ? cands.map((c, i) => typeof paras[i] === 'string' ? 0 : (paras[i].md === 1 ? 1 : 2)) : assignLevels(cands);
    return cands.map((c, i) => ({ lvl: lv[i], text: c.text, bullet: lv[i] === 0 && isBullet(c.text) })).filter(b => b.text);
  }

  /* ---------- DOCX ---------- */
  async function zipEntry(buf, name) {
    const dv = new DataView(buf), u8 = new Uint8Array(buf);
    let i = buf.byteLength - 22; while (i >= 0 && dv.getUint32(i, true) !== 0x06054b50) i--;
    if (i < 0) throw new Error('Fichier Word invalide.');
    const count = dv.getUint16(i + 10, true); let p = dv.getUint32(i + 16, true);
    for (let k = 0; k < count; k++) {
      if (dv.getUint32(p, true) !== 0x02014b50) break;
      const method = dv.getUint16(p + 10, true), csize = dv.getUint32(p + 20, true), nlen = dv.getUint16(p + 28, true), elen = dv.getUint16(p + 30, true), clen = dv.getUint16(p + 32, true), lho = dv.getUint32(p + 42, true);
      const fname = new TextDecoder().decode(u8.subarray(p + 46, p + 46 + nlen));
      if (fname === name) {
        const start = lho + 30 + dv.getUint16(lho + 26, true) + dv.getUint16(lho + 28, true), data = u8.subarray(start, start + csize);
        if (method === 0) return data;
        if (method !== 8) throw new Error('Compression Word non prise en charge.');
        const ds = new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
        return new Uint8Array(await new Response(ds).arrayBuffer());
      }
      p += 46 + nlen + elen + clen;
    }
    return null;
  }
  async function blocksFromDocx(buf) {
    const raw = await zipEntry(buf, 'word/document.xml');
    if (!raw) throw new Error('Ce fichier n’est pas un document Word (.docx) valide.');
    const doc = new DOMParser().parseFromString(new TextDecoder().decode(raw), 'application/xml');
    if (doc.getElementsByTagName('parsererror').length) throw new Error('Document Word illisible.');
    const W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
    const kids = (el, n) => [...el.childNodes].filter(c => c.localName === n && c.namespaceURI === W);
    const textOf = el => { let s = ''; (function walk(n) { for (const c of n.childNodes) { if (c.namespaceURI !== W) continue; if (c.localName === 't') s += c.textContent; else if (c.localName === 'tab' || c.localName === 'br') s += ' '; else if (c.localName !== 'instrText') walk(c); } })(el); return clean(s); };
    const body = doc.getElementsByTagNameNS(W, 'body')[0]; const blocks = []; let title = '';
    const para = p => {
      const text = textOf(p); if (!text) return;
      const pPr = kids(p, 'pPr')[0]; let lvl = 0, bullet = false;
      if (pPr) {
        const st = kids(pPr, 'pStyle')[0]?.getAttributeNS(W, 'val') || '';
        const m = st.match(/^(?:heading|titre)\s*([1-9])$/i), ol = kids(pPr, 'outlineLvl')[0]?.getAttributeNS(W, 'val');
        if (/^(title|titre)$/i.test(st)) { title = title || text; return; }
        if (m) lvl = +m[1] === 1 ? 1 : 2; else if (ol !== undefined && ol !== null && ol !== '' && +ol <= 1) lvl = +ol === 0 ? 1 : 2;
        if (!lvl && (kids(pPr, 'numPr')[0] || /list|liste/i.test(st))) bullet = true;
      }
      blocks.push({ lvl, text, bullet });
    };
    for (const el of body.childNodes) {
      if (el.namespaceURI !== W) continue;
      if (el.localName === 'p') para(el);
      else if (el.localName === 'tbl') kids(el, 'tr').forEach(tr => { const row = kids(tr, 'tc').map(textOf).filter(Boolean).join(' | '); if (row) blocks.push({ lvl: 0, text: row }); });
    }
    return { blocks, title };
  }

  /* ---------- PDF ---------- */
  let pdfjsP = null;
  function loadPdfjs() {
    return pdfjsP || (pdfjsP = (async () => {
      const lib = await import(/* @vite-ignore */ PDFJS_BASE + 'pdf.min.mjs');
      const code = await (await fetch(PDFJS_BASE + 'pdf.worker.min.mjs')).text();
      lib.GlobalWorkerOptions.workerSrc = URL.createObjectURL(new Blob([code], { type: 'text/javascript' }));
      return lib;
    })().catch(e => { pdfjsP = null; throw new Error('Lecteur PDF indisponible (connexion Internet requise) : ' + e.message); }));
  }
  /* items pdf.js → lignes [{text, x, y, h}] triées de haut en bas. */
  function linesFromItems(items) {
    const its = items.filter(i => i.str && i.str.trim() !== '' || i.str === ' ').map(i => ({ s: i.str, x: i.transform[4], y: i.transform[5], h: Math.hypot(i.transform[0], i.transform[1]) || i.height || 10, w: i.width || 0 }));
    its.sort((a, b) => b.y - a.y || a.x - b.x);
    const lines = [];
    for (const it of its) {
      const L = lines.find(l => Math.abs(l.y - it.y) <= Math.max(2, 0.4 * Math.min(l.h, it.h)));
      if (L) { L.items.push(it); L.h = Math.max(L.h, it.h); } else lines.push({ y: it.y, h: it.h, items: [it] });
    }
    return lines.sort((a, b) => b.y - a.y).map(l => {
      l.items.sort((a, b) => a.x - b.x); let t = '', end = null;
      for (const it of l.items) { if (end !== null && it.x - end > 0.12 * it.h && !/\s$/.test(t) && !/^\s/.test(it.s)) t += ' '; t += it.s; end = it.x + it.w; }
      return { text: clean(t), x: l.items[0].x, y: l.y, h: Math.round(l.h * 2) / 2 };
    }).filter(l => l.text);
  }
  /* pages: [[{text,x,y,h}]] → blocks */
  function blocksFromPdfPages(pages) {
    const N = pages.length, norm = t => t.replace(/\d+/g, '#').toLowerCase();
    const isPageNo = t => /^(page\s*)?[-–]?\s*\d{1,4}\s*[-–]?(\s*(\/|sur|of)\s*\d+)?$/i.test(t);
    // en-têtes / pieds de page répétés
    const count = {};
    pages.forEach(p => new Set([...p.slice(0, 2), ...p.slice(-2)].map(l => norm(l.text))).forEach(k => { count[k] = (count[k] || 0) + 1; }));
    const repeated = k => N >= 3 && count[k] >= Math.ceil(N * 0.5);
    const lines = [];
    pages.forEach((p, pi) => p.forEach((l, li) => {
      const edge = li < 2 || li >= p.length - 2;
      if (isPageNo(l.text) || (edge && repeated(norm(l.text)))) return;
      lines.push({ ...l, page: pi });
    }));
    if (!lines.length) return [];
    // taille de corps = taille la plus fréquente (pondérée par la longueur du texte)
    const weight = {}; lines.forEach(l => { weight[l.h] = (weight[l.h] || 0) + l.text.length; });
    const bodyH = +Object.keys(weight).sort((a, b) => weight[b] - weight[a])[0];
    lines.forEach(l => { l.kind = kindOf(l.text); l.big = l.h >= bodyH * 1.2 && looksLikeTitle(l.text); });
    // les lignes en grande police sans mot-clé : niveau selon le rang de taille
    const anyKw = lines.some(l => l.kind === 'mod' || l.kind === 'chap' || l.kind === 'n1' || l.kind === 'n2');
    let sizeLvl = () => 0;
    if (!anyKw) {
      const sizes = [...new Set(lines.filter(l => l.big).map(l => l.h))].sort((a, b) => b - a);
      sizeLvl = h => { const r = sizes.indexOf(h); return sizes.length >= 2 ? (r === 0 ? 1 : r === 1 ? 2 : 0) : (r === 0 ? 2 : 0); };
    }
    const lv = anyKw ? assignLevels(lines.map(l => ({ text: l.text, kind: l.kind }))) : lines.map(l => l.big ? sizeLvl(l.h) : 0);
    const blocks = []; let prev = null;
    lines.forEach((l, i) => {
      const lvl = lv[i];
      if (lvl > 0) {
        const last = blocks[blocks.length - 1];
        if (last && last.lvl === lvl && prev && prev.h === l.h && prev.page === l.page && Math.abs(prev.y - l.y) < 1.8 * l.h && !(anyKw && l.kind)) last.text = clean(last.text + ' ' + l.text); // titre sur deux lignes
        else blocks.push({ lvl, text: l.text });
      } else {
        const last = blocks[blocks.length - 1], gap = prev ? prev.y - l.y : 0, newPara = !last || last.lvl > 0 || isBullet(l.text) || (prev && prev.page === l.page && gap > 1.7 * l.h);
        if (newPara) blocks.push({ lvl: 0, text: l.text, bullet: isBullet(l.text) });
        else last.text = /[a-zà-ÿ]-$/i.test(last.text) ? last.text.slice(0, -1) + l.text : last.text + ' ' + l.text;
      }
      prev = l;
    });
    return blocks;
  }
  async function blocksFromPdf(buf) {
    const lib = await loadPdfjs();
    const pdf = await lib.getDocument({ data: new Uint8Array(buf) }).promise;
    const pages = [];
    for (let n = 1; n <= pdf.numPages; n++) { const pg = await pdf.getPage(n); const tc = await pg.getTextContent(); pages.push(linesFromItems(tc.items)); }
    const blocks = blocksFromPdfPages(pages);
    const chars = blocks.reduce((s, b) => s + b.text.length, 0);
    if (chars < 20) throw new Error('Aucun texte trouvé : ce PDF semble être un scan (image). Utilisez un PDF texte ou un fichier Word.');
    return { blocks, pages: pdf.numPages };
  }

  /* ---------- Point d'entrée ---------- */
  async function extract(file) {
    if (!file) throw new Error('Aucun fichier.');
    if (file.size > MAX_BYTES) throw new Error('Fichier trop volumineux (15 Mo maximum).');
    const ext = (file.name.split('.').pop() || '').toLowerCase(); const title = titleFromName(file.name);
    let blocks, meta = {}, docTitle = title;
    if (ext === 'pdf') { const r = await blocksFromPdf(await file.arrayBuffer()); blocks = r.blocks; meta.pages = r.pages; }
    else if (ext === 'docx') { const r = await blocksFromDocx(await file.arrayBuffer()); blocks = r.blocks; if (r.title) docTitle = r.title; }
    else if (ext === 'txt' || ext === 'md') blocks = blocksFromText(await file.text());
    else if (ext === 'doc') throw new Error('Le format Word ancien (.doc) n’est pas pris en charge : enregistrez le fichier en .docx.');
    else throw new Error('Format non pris en charge. Utilisez PDF, Word (.docx) ou texte (.txt).');
    const res = structure(blocks, docTitle);
    if (!res.modules.length) throw new Error('Aucun contenu exploitable trouvé dans ce fichier.');
    const chapters = res.modules.reduce((s, m) => s + m.chapters.length, 0);
    return { modules: res.modules, title: docTitle, stats: { modules: res.modules.length, chapters, chars: blocks.reduce((s, b) => s + b.text.length, 0), ...meta } };
  }

  root.ImportKit = { extract, structure, blocksFromText, blocksFromPdfPages, linesFromItems, blocksFromDocx, titleFromName, MAX_BYTES, ACCEPT: '.pdf,.docx,.txt,.md' };
  if (typeof module !== 'undefined') module.exports = root.ImportKit;
})(typeof window !== 'undefined' ? window : globalThis);
