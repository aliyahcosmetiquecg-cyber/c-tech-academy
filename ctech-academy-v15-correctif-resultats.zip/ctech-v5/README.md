# C-TECH Academy — interface d'administration raccordée

Application statique HTML/CSS/JavaScript, hébergée sur Netlify et connectée au projet Supabase C-TECH Academy.

## Corrections incluses dans cette version

- Nouvelle rubrique **Classes & filières** réservée à l'administrateur : consultation, création, modification et suppression des classes.
- Sélection multiple des filières d'une classe (relation N-N via `class_filieres`). Les associations préexistantes ont été migrées sans suppression.
- Enregistrement des classes et associations via la fonction transactionnelle `admin_save_class`.
- Nouvelle rubrique **Formateurs** : création sécurisée, activation/désactivation et suppression des comptes via l'Edge Function `create-user`.
- Nouvelle rubrique **Journal des opérations** : consultation, recherche et détail des événements enregistrés dans `audit_logs`.
- Configuration publique Supabase déjà renseignée. La clé utilisée est une clé publishable, jamais une clé `service_role`.
- La fonction `create-user` vérifie la session et le rôle admin côté serveur. Elle crée les utilisateurs teacher/student et supprime réellement leur compte Auth en cas de suppression.

## Déploiement

1. Décompresser l'archive.
2. Publier le contenu du dossier `ctech-academy` sur le site Netlify `myctech-academia` (remplacement des fichiers du site par cette version).
3. Se connecter avec le compte administrateur C-TECH existant.
4. Ouvrir **Classes & filières**, puis vérifier les deux associations déjà présentes avant de créer/modifier des classes.

## État du backend de production

Les migrations de relation N-N, de journalisation, des politiques administrateur et de la fonction `admin_save_class` ont déjà été appliquées sur le projet Supabase de C-TECH Academy. L'Edge Function `create-user` est déployée et active.

La migration de production conserve volontairement `classes.filiere_id` pour compatibilité avec les anciennes parties de l'application. La nouvelle interface utilise aussi `class_filieres`.

**Ne pas exécuter `supabase/schema.sql` sur le projet de production existant.** Ce fichier décrit un ancien schéma v2 de référence et ne correspond pas à la structure actuelle du backend. Les migrations déjà appliquées ne doivent pas être rejouées aveuglément.

## Limites de cette livraison

Cette livraison raccorde les écrans d'administration des classes, formateurs et journaux. Elle ne constitue pas encore un CRUD complet de toutes les ressources pédagogiques (matières, programmes, cours, modules, leçons, évaluations, questions, résultats) et ne remplace pas les tests fonctionnels de chaque parcours. Ces modules doivent être alignés progressivement sur le schéma réel avant de les déclarer prêts pour la production.

## Sécurité

- Ne jamais ajouter une clé Supabase `service_role` au code navigateur.
- La création/suppression de comptes Auth passe par l'Edge Function `create-user`.
- Les permissions réelles sont imposées par RLS et les fonctions SQL sécurisées, pas seulement par l'affichage des menus.

## Logique cours / matière / formateur (correctif 2026-11-08)
- Un cours représente directement une matière : l'interface ne demande plus de sélectionner une matière séparément.
- À la création, le nom du cours sert de nom de matière. La matière est créée automatiquement si elle n'existe pas déjà, puis le cours est rattaché à celle-ci.
- Le formateur est affecté directement au cours via `courses.teacher_id`. Il n'est plus nécessaire de créer au préalable une ligne dans `teacher_assignments`.
- La validation serveur vérifie uniquement que le formateur sélectionné est un compte enseignant actif.
- Migration Supabase appliquée : `create_course_from_subject_name` et adaptation du trigger / des droits de gestion des cours.

## Profil utilisateur
- Menu « Mon Profil » accessible aux administrateurs, formateurs et étudiants.
- Informations personnelles, coordonnées, photo, identifiant, e-mail, niveau, domaine, filière et langue.
- Changement de mot de passe via Supabase Auth; changement d'e-mail soumis aux règles de confirmation de Supabase.
- Les utilisateurs peuvent modifier leur propre profil sans pouvoir changer leur rôle, leur statut d'activation ou les paramètres administratifs.
- Migration `supabase/migrations/20261108_user_profiles.sql` à conserver comme référence; elle a été appliquée sur le projet Supabase de production.
- Migration `supabase/migrations/20261108_allow_users_update_own_profile.sql` (policy et protection des champs privilégiés) déjà appliquée en production.


## Moteur d'évaluation intégré — version 2026-11-08

- Le module `js/exam-engine.js` est chargé après Supabase et raccordé au client existant.
- Les étudiants démarrent/reprennent une épreuve via `student_start_attempt`, sauvegardent via `student_save_answer` et soumettent via `student_submit_attempt`.
- Les questions sont désormais enregistrées dans `questions.correct_answer` et `questions.accepted_answers` ; aucune lecture de l'ancienne table `question_keys`.
- Les copies soumises sont affichées dans le détail d'une évaluation pour le formateur responsable. Les réponses à correction manuelle peuvent recevoir une note via `teacher_grade_answer`.
- Le bouton de publication appelle `teacher_publish_assessment_results`; la publication est refusée si des copies restent à corriger.
- Les bonnes réponses ne sont jamais envoyées dans le module étudiant.

### À tester avant mise en production

Cette archive a passé les vérifications syntaxiques JavaScript (`node --check`). Elle n'a pas encore été validée par une composition réelle avec un compte étudiant et un compte formateur. Il faut notamment vérifier les politiques RLS de lecture des copies pour le formateur, les formats de réponses QCM/Vrai-Faux, la correction manuelle, puis la publication. Aucun déploiement Netlify n'a été effectué.


Correctifs interface et évaluations : API questions alignée sur `questions.correct_answer` / `accepted_answers` (suppression de l'ancien accès `question_keys`), verrouillage de navigation pendant une épreuve, avertissement avant fermeture, menu Utilisateurs regroupé et affichage des photos de profil dans l'en-tête et la barre latérale.

## Correctifs complémentaires — 8 novembre 2026
- Stockage `profile-avatars` créé et vérifié sur le projet Supabase C-TECH, avec lecture publique et écriture limitée au dossier de chaque utilisateur.
- Les photos sont maintenant envoyées sous un chemin stable par compte (`<user_id>/avatar.<extension>`), puis l'URL enregistrée dans `profiles.avatar_url` est relue après sauvegarde.
- Les évaluations acceptent les catégories `DST1`, `DST2`, `SESSION_ORDINAIRE` et `SESSION_RATTRAPAGE`.
- Une évaluation terminée peut être relancée avec une nouvelle période et une tentative supplémentaire par étudiant. Les anciennes copies et leurs résultats sont conservés.
- Après soumission, un popup interactif affiche la note sur 20 et un message adapté au résultat. Les réponses nécessitant une correction manuelle affichent un message d'attente.
- Dans « Mes résultats », le bilan semestriel est calculé lorsque les notes publiées de DST1, DST2 et de la session sont disponibles : `((DST1 + DST2) / 2) × 0,4 + session × 0,6`. La note de rattrapage remplace la note de session ordinaire.

La migration `20261108_assessment_types_and_profile_avatar_storage.sql` a été appliquée au projet Supabase C-TECH. Le déploiement Netlify et les essais de bout en bout avec de vrais comptes étudiant/formateur restent à effectuer.

## Gestion complète des évaluations — correctif 2026-11-08
- Formulaire de création/modification structuré en étapes : identification, public cible, planification et validation.
- Gestion de plusieurs domaines, filières et niveaux pour une même évaluation. Les critères sont cumulatifs et les filières doivent appartenir à l'un des domaines sélectionnés.
- Consultation des paramètres, modification de l'évaluation et des questions, suppression protégée et relance.
- Une évaluation ayant déjà des copies ne peut pas être supprimée depuis l'interface afin de préserver l'historique et les notes.
- Nouvelle table `assessment_targets` et contrôle d'accès côté serveur. Le moteur de démarrage d'épreuve vérifie désormais le domaine, la filière et le niveau de l'étudiant. Les anciennes évaluations sans ciblage conservent le contrôle historique par classe.
- Migration `20261108_assessment_targeting_and_access_control.sql` appliquée en production sur le projet Supabase C-TECH.

Les vérifications syntaxiques JavaScript ont été exécutées. Les tests de parcours réels (admin/formateur/étudiant de plusieurs filières et niveaux) restent nécessaires avant de considérer le module comme entièrement validé.

## Correctifs fonctionnels — Version 7 (2026-11-08)

- Centre de notifications persistant avec compteur de non-lus, mise à jour en temps réel, et marquage individuel ou global comme lu.
- Notifications automatiques lors de la publication d'un cours, d'une évaluation ciblée et des résultats ; annonces générales envoyées par l'administrateur.
- Historique des tentatives d'évaluation distinct de la seule liste des notes. Les notes étudiant restent masquées jusqu'à publication et activation de leur visibilité.
- Année académique centralisée dans `academic_settings`, affichée en lecture seule pour les étudiants et modifiable uniquement depuis l'espace administrateur. Le changement est propagé aux profils étudiants et aux classes sans supprimer les archives de résultats.
- Informations académiques du profil étudiant en lecture seule ; les étudiants ne peuvent pas modifier leur niveau, domaine, filière ou année académique. Le contrôle est également effectué côté base de données.
- Création de `course_files` et du bucket privé `course-files` pour conserver le PDF/DOCX original importé et le rendre téléchargeable selon les droits d'accès au cours.
- L'importateur existant analyse le contenu PDF/DOCX, propose les modules et leçons détectés, puis enregistre le contenu extrait dans le cours après validation du formateur.

### Migrations supplémentaires de cette version

- `20261108_academy_notifications_academic_year_history.sql`
- `20261108_course_document_storage_and_metadata.sql`

Ces migrations ont été appliquées au projet Supabase C-TECH et les objets essentiels ont été vérifiés. Ne pas exécuter `supabase/schema.sql` sur la production. Les tests de parcours réels avec des comptes étudiant, formateur et administrateur restent nécessaires avant diffusion aux utilisateurs.

### Déploiement Netlify

Cette archive contient les fichiers du site à sa racine. Décompresser puis publier tous les fichiers et dossiers de cette archive dans le dossier de publication Netlify, en remplaçant l'ancienne version. La mise à jour du backend Supabase est déjà appliquée ; le site Netlify n'est pas déployé automatiquement par cette livraison.

## Évolution du 8 novembre 2026 — Ma classe / Mon évolution / Le Professeur
- `Ma classe` : discussions privées par classe, messages persistants, création et fermeture par l'administration ou les formateurs affectés.
- `Mon évolution` : publication de notes de cours et de briefings de révision par les équipes pédagogiques.
- `Le Professeur` : Edge Function Supabase `professeur-ia`, avec authentification JWT, priorité aux cours C-TECH accessibles et refus des demandes hors éducation.
- Tables ajoutées : `class_discussions`, `class_messages`, `learning_resources`, `ai_chat_messages`.
- Sécurité : politiques RLS, contrôle d'accès à la classe, historique IA privé par étudiant.

### Activation de l'API IA (étape nécessaire)
La fonction Edge est déployée, mais l'IA nécessite le secret `OPENAI_API_KEY` dans Supabase : Dashboard du projet → Edge Functions → Secrets (ou Project Settings → Edge Functions → Secrets) → ajouter `OPENAI_API_KEY` avec une clé API OpenAI. Ne jamais mettre cette clé dans `config.js`, le HTML ou le navigateur. Une clé API OpenAI est facturée séparément d'un abonnement ChatGPT.

### Limites connues de cette livraison
- Les supports PDF/DOCX déjà stockés sont proposés au téléchargement dans les cours, mais leur texte n'est pas encore indexé dans la base de connaissance du Professeur. Celui-ci s'appuie actuellement sur les titres, descriptions et contenus des leçons publiées dans C-TECH Academy.
- Les briefings de révision sont publiés par les formateurs/administrateurs sous forme de ressources pédagogiques; leur génération automatique à partir des notes n'est pas encore activée.
- Le déploiement Netlify du front-end reste manuel.


## Déploiement Vercel

Ce projet est une application statique HTML/CSS/JavaScript. Dans Vercel, connecter le dépôt GitHub, définir `ctech-v5` comme Root Directory, laisser Build Command vide et utiliser `.` comme Output Directory. Les secrets Supabase restent configurés dans Supabase; ne jamais exposer une clé service_role dans le navigateur. Le fichier `vercel.json` fournit les règles de routage statique.

## Lecture et téléchargement des supports de cours (V13)
- Les étudiants peuvent ouvrir les PDF directement dans la plateforme.
- Les fichiers DOCX sont affichés dans un lecteur intégré via Mammoth.js.
- Les fichiers TXT sont lisibles dans un panneau intégré.
- Un bouton de téléchargement reste disponible pour tous les supports accessibles.
- Les URL signées Storage sont temporaires et émises après contrôle RLS.
- Correction de la politique Storage : comparaison `course_files.path = storage.objects.name` (l'ancienne comparaison utilisait `f.name`, empêchant l'accès aux objets).
- Migration SQL : `20261108_fix_course_file_student_read_access.sql` (déjà appliquée au projet Supabase C-TECH).

## Import intelligent des sujets d'examen

Les administrateurs et formateurs peuvent, lors de la création d'une évaluation, importer un sujet PDF ou Word (.docx). Le navigateur extrait le texte (PDF.js / Mammoth), puis la fonction Supabase `generer-evaluation` utilise Gemini (`GEMINI_API_KEY`) pour proposer des QCM, vrai/faux et réponses courtes. L'évaluation est créée en brouillon et les questions peuvent être vérifiées/modifiées avant publication. Le document source est conservé dans le bucket privé `assessment-sources`.

Limites : 12 Mo par fichier, 100 pages PDF, 30 000 caractères transmis au modèle. Les PDF scannés sans couche texte ne sont pas pris en charge (OCR non inclus). Appliquer la migration `20261108_assessment_source_document_storage.sql` et déployer `supabase/functions/generer-evaluation` avec vérification JWT activée.
