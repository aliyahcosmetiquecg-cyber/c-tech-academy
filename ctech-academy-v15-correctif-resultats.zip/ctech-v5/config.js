/* Configuration publique C-TECH Academy. La clé publishable est destinée au navigateur. */
window.CTECH_CONFIG = {
  SUPABASE_URL: 'https://laodwznvhlhcfomuzpzk.supabase.co',
  SUPABASE_ANON_KEY: 'sb_publishable_C_kjqP_-ujwgvWTR__v3pA_GjHUnFCE',
  STUDENT_EMAIL_DOMAIN: 'students.ctech.cg'
};
