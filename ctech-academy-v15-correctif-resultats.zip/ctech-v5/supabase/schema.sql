-- C-TECH Academy — schéma Supabase v2 (PostgreSQL) — sécurisé
-- À exécuter en entier dans Supabase > SQL Editor sur un projet neuf.
--
-- Principes de sécurité :
--  * Le rôle d'un compte n'est JAMAIS lu depuis les métadonnées fournies par l'utilisateur :
--    tout nouveau compte est « student ». Seul un admin (ou l'Edge Function create-user) change le rôle.
--  * Les bonnes réponses sont dans une table séparée (question_keys), lisible uniquement par le personnel.
--  * Les étudiants n'écrivent jamais directement dans attempts/answers : tout passe par des fonctions
--    serveur (start_attempt, get_attempt_questions, save_answer, submit_attempt) qui contrôlent
--    la fenêtre horaire, la durée, le nombre de tentatives et corrigent côté serveur.

create extension if not exists pgcrypto;

create type public.app_role as enum ('admin','teacher','student');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  username text unique,
  role public.app_role not null default 'student',
  student_code text unique,
  class_name text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.courses (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  code text unique not null,
  description text,
  is_published boolean not null default false,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.modules (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  title text not null,
  position int not null default 0
);

create table public.chapters (
  id uuid primary key default gen_random_uuid(),
  module_id uuid not null references public.modules(id) on delete cascade,
  title text not null,
  content text,
  position int not null default 0
);

create table public.assessments (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  title text not null,
  instructions text,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  duration_minutes int not null check (duration_minutes > 0),
  max_attempts int not null default 1 check (max_attempts > 0),
  max_score numeric(7,2) not null default 20,
  is_published boolean not null default false,
  shuffle_questions boolean not null default true,
  questions_count int not null default 0,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  constraint valid_assessment_window check (ends_at > starts_at)
);

-- Énoncés (visibles pendant l'épreuve via la fonction get_attempt_questions uniquement).
create table public.questions (
  id uuid primary key default gen_random_uuid(),
  assessment_id uuid not null references public.assessments(id) on delete cascade,
  prompt text not null,
  question_type text not null check (question_type in ('mcq','true_false','short_answer')),
  options jsonb not null default '[]'::jsonb,
  points numeric(7,2) not null default 1 check (points > 0),
  position int not null default 0
);

-- Corrigé : jamais lisible par les étudiants.
create table public.question_keys (
  question_id uuid primary key references public.questions(id) on delete cascade,
  correct_answer jsonb,                                  -- mcq / true_false : index (nombre) de l'option correcte
  accepted_answers jsonb not null default '[]'::jsonb    -- short_answer : liste de réponses acceptées (texte)
);

create table public.attempts (
  id uuid primary key default gen_random_uuid(),
  assessment_id uuid not null references public.assessments(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  started_at timestamptz not null default now(),
  deadline timestamptz not null,
  submitted_at timestamptz,
  status text not null default 'in_progress' check (status in ('in_progress','graded','expired')),
  score numeric(7,2)
);
create index attempts_student_idx on public.attempts(student_id, assessment_id);

create table public.answers (
  id uuid primary key default gen_random_uuid(),
  attempt_id uuid not null references public.attempts(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  answer jsonb,
  is_correct boolean,
  awarded_points numeric(7,2) default 0,
  updated_at timestamptz not null default now(),
  unique (attempt_id, question_id)
);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id),
  event text not null,
  entity_type text,
  entity_id uuid,
  details jsonb default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- Profil automatique : TOUJOURS étudiant. Le rôle n'est pas lu dans les métadonnées.
-- ---------------------------------------------------------------------------
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, full_name, username, role, student_code, class_name)
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data->>'full_name',''), 'Utilisateur'),
    nullif(new.raw_user_meta_data->>'username',''),
    'student',
    nullif(new.raw_user_meta_data->>'student_code',''),
    nullif(new.raw_user_meta_data->>'class_name','')
  );
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute procedure public.handle_new_user();

create or replace function public.app_role_of_user() returns public.app_role
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid() and is_active; $$;

create or replace function public.is_staff() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.app_role_of_user() in ('admin','teacher'), false); $$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.app_role_of_user() = 'admin', false); $$;

-- Compteur de questions tenu à jour automatiquement.
create or replace function public.refresh_questions_count() returns trigger
language plpgsql security definer set search_path = public as $$
declare aid uuid := coalesce(new.assessment_id, old.assessment_id);
begin
  update public.assessments set questions_count = (select count(*) from public.questions where assessment_id = aid) where id = aid;
  return null;
end; $$;
create trigger questions_count_trg after insert or delete on public.questions
  for each row execute procedure public.refresh_questions_count();

-- Un compte ne peut pas modifier son propre rôle / code via l'API (seul un admin le peut).
-- ---------------------------------------------------------------------------
-- Row Level Security
-- ---------------------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.courses enable row level security;
alter table public.modules enable row level security;
alter table public.chapters enable row level security;
alter table public.assessments enable row level security;
alter table public.questions enable row level security;
alter table public.question_keys enable row level security;
alter table public.attempts enable row level security;
alter table public.answers enable row level security;
alter table public.audit_logs enable row level security;

create policy "profiles self or staff read" on public.profiles for select
  using (id = auth.uid() or public.is_staff());
create policy "admin manage profiles" on public.profiles for update
  using (public.is_admin()) with check (public.is_admin());

create policy "courses read" on public.courses for select using (is_published or public.is_staff());
create policy "staff manage courses" on public.courses for all using (public.is_staff()) with check (public.is_staff());

create policy "modules read" on public.modules for select
  using (public.is_staff() or exists (select 1 from public.courses c where c.id = course_id and c.is_published));
create policy "staff manage modules" on public.modules for all using (public.is_staff()) with check (public.is_staff());

create policy "chapters read" on public.chapters for select
  using (public.is_staff() or exists (select 1 from public.modules m join public.courses c on c.id = m.course_id where m.id = module_id and c.is_published));
create policy "staff manage chapters" on public.chapters for all using (public.is_staff()) with check (public.is_staff());

create policy "assessments read" on public.assessments for select
  using (public.is_staff() or (is_published and exists (select 1 from public.courses c where c.id = course_id and c.is_published)));
create policy "staff manage assessments" on public.assessments for all using (public.is_staff()) with check (public.is_staff());

-- Questions et corrigés : personnel uniquement (les étudiants passent par get_attempt_questions).
create policy "staff manage questions" on public.questions for all using (public.is_staff()) with check (public.is_staff());
create policy "staff manage keys" on public.question_keys for all using (public.is_staff()) with check (public.is_staff());

-- Tentatives et réponses : lecture seule pour l'étudiant (écriture uniquement par les fonctions serveur).
create policy "attempts read own or staff" on public.attempts for select
  using (student_id = auth.uid() or public.is_staff());
create policy "answers read own or staff" on public.answers for select
  using (exists (select 1 from public.attempts t where t.id = attempt_id and (t.student_id = auth.uid() or public.is_staff())));

create policy "staff read audit logs" on public.audit_logs for select using (public.is_staff());
create policy "authenticated write own audit log" on public.audit_logs for insert with check (actor_id = auth.uid());

-- Défense en profondeur : aucun droit d'écriture direct sur ces tables pour les clients.
revoke insert, update, delete on public.attempts from anon, authenticated;
revoke insert, update, delete on public.answers from anon, authenticated;

-- ---------------------------------------------------------------------------
-- Fonctions serveur de l'évaluation
-- ---------------------------------------------------------------------------

-- Démarre (ou reprend) une tentative : vérifie rôle, publication, fenêtre horaire, nombre de tentatives.
create or replace function public.start_attempt(p_assessment uuid) returns public.attempts
language plpgsql security definer set search_path = public as $$
declare a public.assessments; t public.attempts; n int;
begin
  if public.app_role_of_user() is distinct from 'student' then raise exception 'Réservé aux étudiants'; end if;
  select * into a from public.assessments where id = p_assessment and is_published;
  if not found then raise exception 'Évaluation introuvable'; end if;
  if now() < a.starts_at or now() > a.ends_at then raise exception 'Évaluation fermée'; end if;

  -- reprise d'une tentative en cours encore valide
  select * into t from public.attempts
    where assessment_id = a.id and student_id = auth.uid() and status = 'in_progress' and deadline > now()
    order by started_at desc limit 1;
  if found then return t; end if;

  -- clôturer les tentatives dépassées
  update public.attempts set status = 'expired' where student_id = auth.uid() and status = 'in_progress' and deadline <= now();

  select count(*) into n from public.attempts where assessment_id = a.id and student_id = auth.uid();
  if n >= a.max_attempts then raise exception 'Nombre maximal de tentatives atteint'; end if;
  if a.questions_count = 0 then raise exception 'Aucune question publiée'; end if;

  insert into public.attempts(assessment_id, student_id, deadline)
  values (a.id, auth.uid(), least(now() + make_interval(mins => a.duration_minutes), a.ends_at))
  returning * into t;
  return t;
end; $$;

-- Questions de la tentative, SANS le corrigé.
create or replace function public.get_attempt_questions(p_attempt uuid)
returns table (id uuid, prompt text, question_type text, options jsonb, points numeric, "position" int, answer jsonb)
language plpgsql stable security definer set search_path = public as $$
begin
  if not exists (select 1 from public.attempts t where t.id = p_attempt and t.student_id = auth.uid() and t.status = 'in_progress' and t.deadline > now()) then
    raise exception 'Tentative indisponible';
  end if;
  return query
    select q.id, q.prompt, q.question_type, q.options, q.points, q."position", ans.answer
    from public.attempts t
    join public.questions q on q.assessment_id = t.assessment_id
    left join public.answers ans on ans.attempt_id = t.id and ans.question_id = q.id
    where t.id = p_attempt
    order by q."position";
end; $$;

-- Enregistre une réponse (autorisée tant que la tentative est en cours, +10 s de tolérance réseau).
create or replace function public.save_answer(p_attempt uuid, p_question uuid, p_answer jsonb) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.attempts t where t.id = p_attempt and t.student_id = auth.uid()
                 and t.status = 'in_progress' and now() <= t.deadline + interval '10 seconds') then
    raise exception 'Tentative terminée';
  end if;
  if not exists (select 1 from public.questions q join public.attempts t on t.assessment_id = q.assessment_id
                 where q.id = p_question and t.id = p_attempt) then
    raise exception 'Question invalide';
  end if;
  insert into public.answers(attempt_id, question_id, answer) values (p_attempt, p_question, p_answer)
  on conflict (attempt_id, question_id) do update set answer = excluded.answer, updated_at = now();
end; $$;

-- Soumission + correction automatique côté serveur. Note ramenée à max_score.
create or replace function public.submit_attempt(p_attempt uuid)
returns table (score numeric, max_score numeric, status text)
language plpgsql security definer set search_path = public as $$
declare t public.attempts; a public.assessments; total numeric; got numeric;
begin
  select * into t from public.attempts where id = p_attempt and student_id = auth.uid() for update;
  if not found then raise exception 'Tentative introuvable'; end if;
  if t.status <> 'in_progress' then
    select * into a from public.assessments where id = t.assessment_id;
    return query select t.score, a.max_score, t.status; return;
  end if;
  select * into a from public.assessments where id = t.assessment_id;

  update public.answers ans set
    is_correct = case
      when q.question_type = 'short_answer' then
        exists (select 1 from jsonb_array_elements_text(coalesce(k.accepted_answers,'[]'::jsonb)) x
                where lower(btrim(x)) = lower(btrim(ans.answer #>> '{}')))
      else (ans.answer is not null and ans.answer = k.correct_answer) end
  from public.questions q left join public.question_keys k on k.question_id = q.id
  where ans.attempt_id = t.id and ans.question_id = q.id;

  update public.answers ans set awarded_points = case when ans.is_correct then q.points else 0 end
  from public.questions q where ans.attempt_id = t.id and q.id = ans.question_id;

  select coalesce(sum(points),0) into total from public.questions where assessment_id = t.assessment_id;
  select coalesce(sum(awarded_points),0) into got from public.answers where attempt_id = t.id;

  update public.attempts set
    submitted_at = now(),
    status = case when now() > t.deadline + interval '10 seconds' then 'expired' else 'graded' end,
    score = case when total > 0 then round(got / total * a.max_score, 2) else 0 end
  where id = t.id returning * into t;
  return query select t.score, a.max_score, t.status;
end; $$;

-- Droits d'exécution : uniquement les utilisateurs connectés.
revoke execute on function public.start_attempt(uuid), public.get_attempt_questions(uuid),
  public.save_answer(uuid, uuid, jsonb), public.submit_attempt(uuid) from public, anon;
grant execute on function public.start_attempt(uuid), public.get_attempt_questions(uuid),
  public.save_answer(uuid, uuid, jsonb), public.submit_attempt(uuid) to authenticated;
revoke execute on function public.app_role_of_user(), public.is_staff(), public.is_admin() from public, anon;
grant execute on function public.app_role_of_user(), public.is_staff(), public.is_admin() to authenticated;


-- ---------------------------------------------------------------------------
-- Supports de cours originaux (PDF / Word) : métadonnées + stockage privé
-- ---------------------------------------------------------------------------
create table public.course_files (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  name text not null,
  path text not null unique,
  size bigint,
  mime text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);
alter table public.course_files enable row level security;
create policy "course files read" on public.course_files for select
  using (public.is_staff() or exists (select 1 from public.courses c where c.id = course_id and c.is_published));
create policy "staff manage course files" on public.course_files for all using (public.is_staff()) with check (public.is_staff());

insert into storage.buckets (id, name, public, file_size_limit)
values ('course-files', 'course-files', false, 15728640)
on conflict (id) do nothing;

create policy "staff upload course files" on storage.objects for insert to authenticated
  with check (bucket_id = 'course-files' and public.is_staff());
create policy "staff delete course files" on storage.objects for delete to authenticated
  using (bucket_id = 'course-files' and public.is_staff());
create policy "read course files" on storage.objects for select to authenticated
  using (bucket_id = 'course-files' and (public.is_staff() or exists (
    select 1 from public.course_files f join public.courses c on c.id = f.course_id where f.path = name and c.is_published)));

-- ---------------------------------------------------------------------------
-- PREMIER ADMINISTRATEUR : après avoir créé un compte dans Supabase > Authentication > Users,
-- exécutez (en remplaçant l'e-mail) :
--   update public.profiles set role = 'admin' where id = (select id from auth.users where email = 'vous@exemple.com');
-- Ensuite, l'admin crée enseignants et étudiants depuis l'application (Edge Function create-user).
-- Désactivez aussi « Allow new users to sign up » dans Authentication > Providers > Email.
-- Ne jamais mettre la clé service_role dans le navigateur.
-- ---------------------------------------------------------------------------
