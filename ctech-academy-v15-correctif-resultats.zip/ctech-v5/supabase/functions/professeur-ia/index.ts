import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = {"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
const json=(data:unknown,status=200)=>new Response(JSON.stringify(data),{status,headers:{...cors,"Content-Type":"application/json"}});
Deno.serve(async(req:Request)=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:cors});
 if(req.method!=="POST")return json({error:"Méthode non autorisée."},405);
 try{
  const apiKey=Deno.env.get("OPENAI_API_KEY");
  if(!apiKey)return json({error:"La clé OpenAI est absente des secrets Supabase."},503);
  const authorization=req.headers.get("Authorization")||"";
  if(!authorization.startsWith("Bearer "))return json({error:"Connexion requise."},401);
  const supabase=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_ANON_KEY")!,{global:{headers:{Authorization:authorization}}});
  const {data:{user},error:authError}=await supabase.auth.getUser();
  if(authError||!user)return json({error:"Session invalide. Déconnectez-vous puis reconnectez-vous."},401);
  const payload=await req.json().catch(()=>({}));
  const question=String(payload.message||"").trim();
  if(!question||question.length>3000)return json({error:"La question doit contenir entre 1 et 3 000 caractères."},400);
  let courseContext="";
  const {data:courses,error:coursesError}=await supabase.from("courses").select("id,title,description").eq("is_published",true).limit(30);
  if(coursesError)console.error("COURSES_READ_ERROR",coursesError.message);
  if(courses?.length){
   const courseIds=courses.map((c:any)=>c.id);
   const {data:modules,error:modulesError}=await supabase.from("modules").select("id,course_id,title,position").in("course_id",courseIds).order("position");
   if(modulesError)console.error("MODULES_READ_ERROR",modulesError.message);
   const moduleIds=(modules||[]).map((m:any)=>m.id); let lessons:any[]=[];
   if(moduleIds.length){const {data:ls,error:lessonsError}=await supabase.from("lessons").select("module_id,title,content,position,is_published").in("module_id",moduleIds).eq("is_published",true).order("position");if(lessonsError)console.error("LESSONS_READ_ERROR",lessonsError.message);lessons=ls||[];}
   courseContext=courses.map((c:any)=>"COURS : "+c.title+"\n"+(c.description||"")+"\n"+(modules||[]).filter((m:any)=>m.course_id===c.id).map((m:any)=>"MODULE : "+m.title+"\n"+lessons.filter((l:any)=>l.module_id===m.id).map((l:any)=>"CHAPITRE : "+l.title+"\n"+(l.content||"")).join("\n")).join("\n")).join("\n\n").slice(0,18000);
  }
  const history=Array.isArray(payload.history)?payload.history.slice(-8).map((m:any)=>({role:m.role==="assistant"?"assistant":"user",content:String(m.content||"").slice(0,2500)})):[];
  const system=`Tu es « Le Professeur », enseignant virtuel de l'Institut Congo Technologie (C-TECH). Tu es patient, encourageant, rigoureux et pédagogique. Réponds uniquement aux questions liées aux études, à l'école, aux matières, aux sciences, aux technologies, à la formation, aux examens et à l'apprentissage. Pour toute demande sans rapport avec l'éducation, refuse poliment et rappelle ton rôle. PRIORITÉ ABSOLUE : exploite d'abord les ressources officielles C-TECH ci-dessous. Si elles répondent à la question, base-toi dessus et cite le titre du cours/module si disponible. Si elles ne suffisent pas, complète avec tes connaissances générales en précisant explicitement « Complément pédagogique général ». N'invente jamais le contenu d'un cours ni une référence. Si aucune ressource n'est fournie, indique-le puis donne une explication générale utile. Explique progressivement avec exemples et vérifie la compréhension. Réponds en français.\n\nRESSOURCES C-TECH :\n${courseContext||"Aucun contenu de cours publié n'est actuellement accessible."}`;
  const openai=await fetch("https://api.openai.com/v1/chat/completions",{method:"POST",headers:{"Authorization":`Bearer ${apiKey}`,"Content-Type":"application/json"},body:JSON.stringify({model:"gpt-4.1-mini",temperature:0.35,max_tokens:900,messages:[{role:"system",content:system},...history,{role:"user",content:question}]})});
  const result=await openai.json().catch(()=>({}));
  if(!openai.ok){console.error("OPENAI_API_ERROR",openai.status,JSON.stringify(result).slice(0,1200));const detail=result?.error?.message;return json({error:openai.status===401?"La clé API OpenAI est refusée. Vérifie la clé enregistrée dans Supabase.":openai.status===429?"Le quota ou le crédit de l’API OpenAI est insuffisant. Vérifie la facturation de ton compte API.":(detail||"Le service OpenAI a refusé la demande. Vérifie la configuration de l’API.")},502);}
  const reply=result?.choices?.[0]?.message?.content;
  if(!reply)return json({error:"Le service IA n’a pas retourné de réponse. Réessaie."},502);
  return json({reply});
 }catch(error){console.error("PROFESSEUR_UNEXPECTED_ERROR",error instanceof Error?error.stack:String(error));return json({error:"Une erreur technique est survenue dans Le Professeur. Réessaie dans un instant."},500);}
});
