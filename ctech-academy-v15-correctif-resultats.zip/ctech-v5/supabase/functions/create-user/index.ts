import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Méthode non autorisée." }, 405);
  const url = Deno.env.get("SUPABASE_URL")!; const anon = Deno.env.get("SUPABASE_ANON_KEY")!; const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const authHeader = req.headers.get("Authorization") || ""; if (!authHeader.startsWith("Bearer ")) return json({ error: "Authentification requise." }, 401);
  const caller = createClient(url, anon, { global: { headers: { Authorization: authHeader } } }); const { data: auth, error: authError } = await caller.auth.getUser();
  if (authError || !auth.user) return json({ error: "Session invalide." }, 401);
  const admin = createClient(url, service, { auth: { autoRefreshToken: false, persistSession: false } });
  const { data: actor, error: actorError } = await admin.from("profiles").select("role,is_active").eq("id", auth.user.id).single();
  if (actorError || actor?.role !== "admin" || actor?.is_active !== true) return json({ error: "Droits administrateur requis." }, 403);
  let body: Record<string, unknown>; try { body = await req.json(); } catch { return json({ error: "Corps JSON invalide." }, 400); }
  if (body.action === "delete" && typeof body.user_id === "string") {
    if (body.user_id === auth.user.id) return json({ error: "Vous ne pouvez pas supprimer votre propre compte." }, 400);
    const { data: target, error: targetError } = await admin.from("profiles").select("id,role").eq("id", body.user_id).single();
    if (targetError || !target || !["teacher", "student"].includes(target.role)) return json({ error: "Compte introuvable ou suppression non autorisée." }, 404);
    const { error } = await admin.auth.admin.deleteUser(body.user_id); if (error) return json({ error: error.message }, 400); return json({ success: true });
  }
  const role = body.role; if (role !== "teacher" && role !== "student") return json({ error: "Rôle invalide." }, 400);
  const fullName = String(body.full_name || "").trim(), password = String(body.password || "");
  if (!fullName || password.length < 8) return json({ error: "Nom complet et mot de passe (8 caractères minimum) requis." }, 400);
  let email = "";
  if (role === "student") {
    const matricule = String(body.student_code || body.matricule || "").trim().toUpperCase(); if (!/^[A-Z0-9-]{4,24}$/.test(matricule)) return json({ error: "Matricule invalide." }, 400);
    email = `${matricule.toLowerCase()}@${Deno.env.get("STUDENT_EMAIL_DOMAIN") || "students.ctech.cg"}`;
    const { data: existing } = await admin.from("profiles").select("id").eq("matricule", matricule).maybeSingle(); if (existing) return json({ error: "Ce matricule existe déjà." }, 409); body.matricule = matricule;
  } else { email = String(body.email || "").trim().toLowerCase(); if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({ error: "Adresse e-mail invalide." }, 400); }
  const { data: created, error: createError } = await admin.auth.admin.createUser({ email, password, email_confirm: true, user_metadata: { full_name: fullName } });
  if (createError || !created.user) return json({ error: createError?.message || "Création Auth impossible." }, 400);
  const profile: Record<string, unknown> = { id: created.user.id, full_name: fullName, role, is_active: true, must_change_password: true, username: role === "student" ? String(body.matricule) : email.split("@")[0], phone: body.phone ? String(body.phone).trim() : null };
  if (role === "student") { profile.matricule = body.matricule; for (const key of ["level_code", "academic_year", "domain_id", "filiere_id"]) if (body[key]) profile[key] = body[key]; }
  const { error: profileError } = await admin.from("profiles").insert(profile); if (profileError) { await admin.auth.admin.deleteUser(created.user.id); return json({ error: "Profil non créé : " + profileError.message }, 400); }
  return json({ success: true, user_id: created.user.id, email, role });
});
