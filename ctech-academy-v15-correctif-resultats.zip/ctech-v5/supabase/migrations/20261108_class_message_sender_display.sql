alter table public.class_messages add column if not exists sender_name text;
create or replace function public.set_class_message_sender_name()
returns trigger language plpgsql security definer set search_path=public as $$
begin select full_name into new.sender_name from public.profiles where id=new.sender_id; if new.sender_name is null then new.sender_name:='Membre'; end if; return new; end; $$;
drop trigger if exists class_message_sender_name on public.class_messages;
create trigger class_message_sender_name before insert on public.class_messages for each row execute function public.set_class_message_sender_name();
revoke all on function public.set_class_message_sender_name() from public,anon,authenticated;
