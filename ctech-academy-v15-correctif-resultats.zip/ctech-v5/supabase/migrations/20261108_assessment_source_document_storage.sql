alter table public.assessments add column if not exists source_document_path text;
alter table public.assessments add column if not exists source_document_name text;

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('assessment-sources','assessment-sources',false,12582912,
 array['application/pdf','application/vnd.openxmlformats-officedocument.wordprocessingml.document'])
on conflict (id) do update set public=false,file_size_limit=12582912,allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists "staff upload assessment source documents" on storage.objects;
create policy "staff upload assessment source documents" on storage.objects
for insert to authenticated with check (bucket_id='assessment-sources' and public.is_staff());

drop policy if exists "staff read assessment source documents" on storage.objects;
create policy "staff read assessment source documents" on storage.objects
for select to authenticated using (bucket_id='assessment-sources' and public.is_staff());

drop policy if exists "staff delete assessment source documents" on storage.objects;
create policy "staff delete assessment source documents" on storage.objects
for delete to authenticated using (bucket_id='assessment-sources' and public.is_staff());
