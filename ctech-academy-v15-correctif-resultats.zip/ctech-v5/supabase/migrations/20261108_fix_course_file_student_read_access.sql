-- Autorise les étudiants authentifiés à lire/télécharger les supports
-- uniquement lorsque le cours associé est publié.
drop policy if exists "read course documents when course visible" on storage.objects;
create policy "read course documents when course visible"
on storage.objects for select to authenticated
using (
  bucket_id = 'course-files'
  and exists (
    select 1
    from public.course_files f
    join public.courses c on c.id = f.course_id
    where f.path = storage.objects.name
      and (c.is_published = true or public.is_staff())
  )
);
