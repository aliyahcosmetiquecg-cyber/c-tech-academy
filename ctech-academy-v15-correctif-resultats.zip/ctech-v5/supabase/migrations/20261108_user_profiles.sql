alter table public.profiles
  add column if not exists birth_date date,
  add column if not exists birth_place text,
  add column if not exists address text,
  add column if not exists arrondissement text,
  add column if not exists neighborhood text,
  add column if not exists city text,
  add column if not exists avatar_url text,
  add column if not exists preferred_language text not null default 'fr';

alter table public.profiles drop constraint if exists profiles_preferred_language_check;
alter table public.profiles add constraint profiles_preferred_language_check check (preferred_language in ('fr','en'));

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('profile-avatars','profile-avatars',true,5242880,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public=true,file_size_limit=5242880,allowed_mime_types=array['image/jpeg','image/png','image/webp'];

drop policy if exists "Profile avatars are publicly readable" on storage.objects;
create policy "Profile avatars are publicly readable" on storage.objects for select using (bucket_id='profile-avatars');
drop policy if exists "Users upload own profile avatar" on storage.objects;
create policy "Users upload own profile avatar" on storage.objects for insert to authenticated with check (bucket_id='profile-avatars' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "Users update own profile avatar" on storage.objects;
create policy "Users update own profile avatar" on storage.objects for update to authenticated using (bucket_id='profile-avatars' and (storage.foldername(name))[1]=auth.uid()::text) with check (bucket_id='profile-avatars' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "Users delete own profile avatar" on storage.objects;
create policy "Users delete own profile avatar" on storage.objects for delete to authenticated using (bucket_id='profile-avatars' and (storage.foldername(name))[1]=auth.uid()::text);
