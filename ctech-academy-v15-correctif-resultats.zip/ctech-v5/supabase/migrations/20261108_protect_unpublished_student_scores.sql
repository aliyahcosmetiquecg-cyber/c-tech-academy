create or replace function public.student_assessment_history()
returns table(
 attempt_id uuid,
 assessment_id uuid,
 attempt_number integer,
 started_at timestamptz,
 submitted_at timestamptz,
 status text,
 score numeric,
 total_points numeric,
 grading_status text,
 published_at timestamptz,
 assessment_title text,
 assessment_type text,
 course_title text
)
language sql
stable
set search_path = public
as $function$
 select
  a.id,
  a.assessment_id,
  a.attempt_number,
  a.started_at,
  a.submitted_at,
  a.status,
  case when r.published_at is not null then r.score else null end,
  r.total_points,
  r.grading_status,
  r.published_at,
  ass.title,
  ass.assessment_type,
  c.title
 from public.attempts a
 join public.assessments ass on ass.id=a.assessment_id
 join public.courses c on c.id=ass.course_id
 left join public.results r on r.attempt_id=a.id
 where a.student_id=auth.uid()
    or exists(select 1 from public.profiles p where p.id=auth.uid() and p.role in ('admin','teacher'))
 order by coalesce(a.submitted_at,a.started_at) desc;
$function$;
revoke all on function public.student_assessment_history() from public, anon;
grant execute on function public.student_assessment_history() to authenticated;
