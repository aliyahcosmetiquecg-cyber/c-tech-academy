-- Paramètres académiques globaux, notifications persistantes et historique des tentatives.
create table if not exists public.academic_settings (
  id boolean primary key default true check (id),
  academic_year text not null,
  updated_by uuid references auth.users(id),
  updated_at timestamptz not null default now()
);
alter table public.academic_settings enable row level security;
grant select,insert,update on public.academic_settings to authenticated;
drop policy if exists "academic settings read authenticated" on public.academic_settings;
create policy "academic settings read authenticated" on public.academic_settings for select to authenticated using (true);
drop policy if exists "academic settings admin update" on public.academic_settings;
create policy "academic settings admin update" on public.academic_settings for all to authenticated
using (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and p.is_active))
with check (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and p.is_active));
insert into public.academic_settings(id,academic_year)
select true, coalesce((select academic_year from public.profiles where academic_year is not null order by updated_at desc limit 1),'2026-2027')
on conflict(id) do nothing;

create or replace function public.guard_profile_academic_fields()
returns trigger language plpgsql security definer set search_path=public as $$
declare v_role text;
begin
 select role into v_role from public.profiles where id=auth.uid();
 if auth.uid() is not null and v_role <> 'admin' then
   if new.academic_year is distinct from old.academic_year then raise exception 'Seul l’administrateur peut modifier l’année académique.'; end if;
   if new.level_code is distinct from old.level_code or new.domain_id is distinct from old.domain_id or new.filiere_id is distinct from old.filiere_id then
     raise exception 'Les informations académiques sont gérées par l’administration.';
   end if;
 end if;
 return new;
end; $$;
drop trigger if exists profiles_guard_academic_fields on public.profiles;
create trigger profiles_guard_academic_fields before update on public.profiles for each row execute function public.guard_profile_academic_fields();

create or replace function public.admin_set_academic_year(p_year text)
returns void language plpgsql security invoker set search_path=public as $$
begin
 if not exists(select 1 from public.profiles where id=auth.uid() and role='admin' and is_active) then raise exception 'Accès administrateur requis.'; end if;
 if p_year !~ '^[0-9]{4}-[0-9]{4}$' then raise exception 'Format attendu : AAAA-AAAA.'; end if;
 insert into public.academic_settings(id,academic_year,updated_by,updated_at) values(true,p_year,auth.uid(),now())
 on conflict(id) do update set academic_year=excluded.academic_year,updated_by=excluded.updated_by,updated_at=now();
 update public.profiles set academic_year=p_year,updated_at=now() where role='student';
 update public.classes set academic_year=p_year where true;
 insert into public.audit_logs(actor_id,action,table_name,record_id,new_data,occurred_at)
 values(auth.uid(),'UPDATE','academic_settings','global',jsonb_build_object('academic_year',p_year),now());
end; $$;
grant execute on function public.admin_set_academic_year(text) to authenticated;
revoke execute on function public.admin_set_academic_year(text) from anon;

create table if not exists public.notifications (
 id uuid primary key default gen_random_uuid(),
 recipient_id uuid not null references public.profiles(id) on delete cascade,
 title text not null,
 body text not null default '',
 category text not null default 'general',
 link_page text,
 related_id uuid,
 created_at timestamptz not null default now(),
 read_at timestamptz
);
create index if not exists notifications_recipient_created_idx on public.notifications(recipient_id,created_at desc);
alter table public.notifications enable row level security;
grant select on public.notifications to authenticated;
drop policy if exists "users read own notifications" on public.notifications;
create policy "users read own notifications" on public.notifications for select to authenticated using(recipient_id=auth.uid());
drop policy if exists "users update own notifications" on public.notifications;
create policy "users update own notifications" on public.notifications for update to authenticated using(recipient_id=auth.uid()) with check(recipient_id=auth.uid());
revoke insert,delete,update on public.notifications from anon,authenticated;
grant update(read_at) on public.notifications to authenticated;
do $$ begin
  if exists(select 1 from pg_publication where pubname='supabase_realtime')
     and not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='notifications') then
    alter publication supabase_realtime add table public.notifications;
  end if;
end $$;

create or replace function public.notify_course_publication()
returns trigger language plpgsql security definer set search_path=public as $$
begin
 if new.is_published is true and (tg_op='INSERT' or old.is_published is distinct from true) then
  insert into public.notifications(recipient_id,title,body,category,link_page,related_id)
  select p.id,'Nouveau cours disponible',new.title,'course','courses',new.id from public.profiles p
  where p.role='student' and p.is_active;
 end if;
 return new;
end; $$;
drop trigger if exists courses_notify_publication on public.courses;
create trigger courses_notify_publication after insert or update of is_published on public.courses for each row execute function public.notify_course_publication();

create or replace function public.notify_assessment_publication()
returns trigger language plpgsql security definer set search_path=public as $$
begin
 if new.status in ('published','scheduled') and (tg_op='INSERT' or old.status not in ('published','scheduled')) then
  insert into public.notifications(recipient_id,title,body,category,link_page,related_id)
  select p.id,'Nouvelle évaluation',new.title,'assessment','assessments',new.id
  from public.profiles p join public.assessment_targets t on t.assessment_id=new.id
  where p.role='student' and p.is_active and p.domain_id=any(t.domain_ids) and p.filiere_id=any(t.filiere_ids)
    and upper(p.level_code)=any(select upper(x) from unnest(t.level_codes) x);
 end if;
 return new;
end; $$;
drop trigger if exists assessments_notify_publication on public.assessments;
create trigger assessments_notify_publication after insert or update of status on public.assessments for each row execute function public.notify_assessment_publication();

create or replace function public.notify_result_publication()
returns trigger language plpgsql security definer set search_path=public as $$
begin
 if new.published_at is not null and (tg_op='INSERT' or old.published_at is null) then
  insert into public.notifications(recipient_id,title,body,category,link_page,related_id)
  values(new.student_id,'Résultat publié','Votre résultat est maintenant disponible.','result','results',new.assessment_id);
 end if;
 return new;
end; $$;
drop trigger if exists results_notify_publication on public.results;
create trigger results_notify_publication after insert or update of published_at on public.results for each row execute function public.notify_result_publication();

create or replace function public.student_assessment_history()
returns table(attempt_id uuid,assessment_id uuid,attempt_number integer,started_at timestamptz,submitted_at timestamptz,status text,score numeric,total_points numeric,grading_status text,published_at timestamptz,assessment_title text,assessment_type text,course_title text)
language sql stable security invoker set search_path=public as $$
 select a.id,a.assessment_id,a.attempt_number,a.started_at,a.submitted_at,a.status,r.score,r.total_points,r.grading_status,r.published_at,ass.title,ass.assessment_type,c.title
 from public.attempts a join public.assessments ass on ass.id=a.assessment_id join public.courses c on c.id=ass.course_id
 left join public.results r on r.attempt_id=a.id
 where (a.student_id=auth.uid() or exists(select 1 from public.profiles p where p.id=auth.uid() and p.role in ('admin','teacher')))
 order by coalesce(a.submitted_at,a.started_at) desc;
$$;
grant execute on function public.student_assessment_history() to authenticated;
revoke execute on function public.student_assessment_history() from anon;
revoke execute on function public.guard_profile_academic_fields() from public,anon,authenticated;
revoke execute on function public.notify_course_publication() from public,anon,authenticated;
revoke execute on function public.notify_assessment_publication() from public,anon,authenticated;
revoke execute on function public.notify_result_publication() from public,anon,authenticated;

-- Annonces administratives à l'ensemble des étudiants actifs.
create or replace function public.admin_broadcast_notification(p_title text,p_body text)
returns integer language plpgsql security invoker set search_path=public as $$
declare n integer;
begin
 if not exists(select 1 from public.profiles where id=auth.uid() and role='admin' and is_active) then raise exception 'Accès administrateur requis.'; end if;
 if length(trim(coalesce(p_title,'')))<3 or length(trim(coalesce(p_body,'')))<5 then raise exception 'Titre ou message trop court.'; end if;
 insert into public.notifications(recipient_id,title,body,category,link_page)
 select id,trim(p_title),trim(p_body),'announcement','dashboard' from public.profiles where role='student' and is_active;
 get diagnostics n = row_count;
 return n;
end; $$;
grant execute on function public.admin_broadcast_notification(text,text) to authenticated;
revoke execute on function public.admin_broadcast_notification(text,text) from anon;
