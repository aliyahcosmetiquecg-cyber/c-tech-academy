create table if not exists public.course_files (
 id uuid primary key default gen_random_uuid(),
 course_id uuid not null references public.courses(id) on delete cascade,
 name text not null,
 path text not null unique,
 size bigint not null default 0,
 mime text,
 created_by uuid references auth.users(id),
 created_at timestamptz not null default now()
);
alter table public.course_files enable row level security;
drop policy if exists "course files visible with course" on public.course_files;
create policy "course files visible with course" on public.course_files for select to authenticated
using (public.is_staff() or exists(select 1 from public.courses c where c.id=course_id and c.is_published));
drop policy if exists "staff manage course files" on public.course_files;
create policy "staff manage course files" on public.course_files for all to authenticated
using (public.is_staff()) with check (public.is_staff());
grant select,insert,update,delete on public.course_files to authenticated;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('course-files','course-files',false,15728640,array['application/pdf','application/vnd.openxmlformats-officedocument.wordprocessingml.document','text/plain'])
on conflict(id) do update set public=false,file_size_limit=15728640,allowed_mime_types=excluded.allowed_mime_types;
drop policy if exists "staff upload course documents" on storage.objects;
create policy "staff upload course documents" on storage.objects for insert to authenticated
with check (bucket_id='course-files' and public.is_staff() and exists(select 1 from public.courses c where c.id::text=(storage.foldername(name))[1]));
drop policy if exists "read course documents when course visible" on storage.objects;
create policy "read course documents when course visible" on storage.objects for select to authenticated
using (bucket_id='course-files' and exists(select 1 from public.course_files f join public.courses c on c.id=f.course_id where f.path=name and (c.is_published or public.is_staff())));
drop policy if exists "staff update course documents" on storage.objects;
create policy "staff update course documents" on storage.objects for update to authenticated
using (bucket_id='course-files' and public.is_staff()) with check (bucket_id='course-files' and public.is_staff());
drop policy if exists "staff delete course documents" on storage.objects;
create policy "staff delete course documents" on storage.objects for delete to authenticated
using (bucket_id='course-files' and public.is_staff());
