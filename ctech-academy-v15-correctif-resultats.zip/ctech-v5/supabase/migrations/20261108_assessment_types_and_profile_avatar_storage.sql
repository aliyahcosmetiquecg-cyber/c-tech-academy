alter table public.assessments
  add column if not exists assessment_type text not null default 'DST1';

alter table public.assessments
  drop constraint if exists assessments_assessment_type_check;

alter table public.assessments
  add constraint assessments_assessment_type_check
  check (assessment_type in ('DST1','DST2','SESSION_ORDINAIRE','SESSION_RATTRAPAGE'));

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('profile-avatars','profile-avatars',true,5242880,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update
set public = true,
    file_size_limit = 5242880,
    allowed_mime_types = array['image/jpeg','image/png','image/webp'];

drop policy if exists "ctech_profile_avatar_public_read" on storage.objects;
create policy "ctech_profile_avatar_public_read" on storage.objects
for select to public using (bucket_id = 'profile-avatars');

drop policy if exists "ctech_profile_avatar_insert_own" on storage.objects;
create policy "ctech_profile_avatar_insert_own" on storage.objects
for insert to authenticated with check (bucket_id = 'profile-avatars' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "ctech_profile_avatar_update_own" on storage.objects;
create policy "ctech_profile_avatar_update_own" on storage.objects
for update to authenticated using (bucket_id = 'profile-avatars' and (storage.foldername(name))[1] = auth.uid()::text)
with check (bucket_id = 'profile-avatars' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "ctech_profile_avatar_delete_own" on storage.objects;
create policy "ctech_profile_avatar_delete_own" on storage.objects
for delete to authenticated using (bucket_id = 'profile-avatars' and (storage.foldername(name))[1] = auth.uid()::text);
