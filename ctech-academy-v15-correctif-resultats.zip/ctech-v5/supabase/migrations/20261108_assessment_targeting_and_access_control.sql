create table if not exists public.assessment_targets (
  assessment_id uuid primary key references public.assessments(id) on delete cascade,
  domain_ids uuid[] not null default '{}',
  filiere_ids uuid[] not null default '{}',
  level_codes text[] not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint assessment_targets_nonempty check (cardinality(domain_ids)>0 and cardinality(filiere_ids)>0 and cardinality(level_codes)>0)
);
alter table public.assessment_targets enable row level security;
drop policy if exists assessment_targets_staff_all on public.assessment_targets;
create policy assessment_targets_staff_all on public.assessment_targets for all to authenticated
using (public.current_role()='admin' or exists(select 1 from public.assessments a join public.courses c on c.id=a.course_id where a.id=assessment_targets.assessment_id and c.teacher_id=auth.uid()))
with check (public.current_role()='admin' or exists(select 1 from public.assessments a join public.courses c on c.id=a.course_id where a.id=assessment_targets.assessment_id and c.teacher_id=auth.uid()));
drop policy if exists assessment_targets_student_read on public.assessment_targets;
create policy assessment_targets_student_read on public.assessment_targets for select to authenticated using (
 exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='student' and p.is_active=true and p.domain_id=any(domain_ids) and p.filiere_id=any(filiere_ids) and p.level_code=any(level_codes))
);
create or replace function public.student_can_access_assessment(p_assessment_id uuid,p_student_id uuid)
returns boolean language sql stable security definer set search_path=public as $$
 select case when exists(select 1 from public.assessment_targets t where t.assessment_id=p_assessment_id)
 then exists(select 1 from public.assessment_targets t join public.profiles p on p.id=p_student_id where t.assessment_id=p_assessment_id and p.role='student' and p.is_active=true and p.domain_id=any(t.domain_ids) and p.filiere_id=any(t.filiere_ids) and p.level_code=any(t.level_codes))
 else exists(select 1 from public.assessments a join public.courses c on c.id=a.course_id join public.class_memberships cm on cm.class_id=c.class_id where a.id=p_assessment_id and cm.student_id=p_student_id) end
$$;
revoke all on function public.student_can_access_assessment(uuid,uuid) from public;
grant execute on function public.student_can_access_assessment(uuid,uuid) to authenticated;
create or replace function public.student_list_assessment_ids()
returns table(assessment_id uuid) language sql stable security definer set search_path=public as $$
 select a.id from public.assessments a where public.student_can_access_assessment(a.id,auth.uid())
$$;
revoke all on function public.student_list_assessment_ids() from public;
grant execute on function public.student_list_assessment_ids() to authenticated;
-- The production student_start_attempt RPC is patched to call the helper above
-- instead of relying exclusively on the course's single class_id.
DO $$
DECLARE v_def text; v_new text;
BEGIN
 v_def:=pg_get_functiondef('public.student_start_attempt(uuid)'::regprocedure);
 v_new:=regexp_replace(v_def,'if v_class_id is null or not exists\s*\(\s*select 1 from public.class_memberships cm\s*where cm.class_id=v_class_id and cm.student_id=v_student\s*\) then','if not public.student_can_access_assessment(p_assessment_id,v_student) then','i');
 IF v_new=v_def THEN RAISE EXCEPTION 'Could not safely patch student_start_attempt access validation'; END IF;
 EXECUTE v_new;
END $$;
