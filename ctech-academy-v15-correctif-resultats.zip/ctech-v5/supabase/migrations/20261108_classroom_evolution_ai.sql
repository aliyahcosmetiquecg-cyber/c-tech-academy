-- C-TECH Academy: Ma classe, Mon évolution et historique du Professeur IA
create table if not exists public.class_discussions (
 id uuid primary key default gen_random_uuid(),
 class_id uuid not null unique references public.classes(id) on delete cascade,
 title text not null default 'Discussion de classe',
 description text not null default '',
 is_open boolean not null default true,
 created_by uuid references auth.users(id),
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create table if not exists public.class_messages (
 id uuid primary key default gen_random_uuid(),
 discussion_id uuid not null references public.class_discussions(id) on delete cascade,
 sender_id uuid not null references auth.users(id) on delete cascade,
 body text not null check (char_length(body) between 1 and 5000),
 created_at timestamptz not null default now()
);
create index if not exists class_messages_discussion_created_idx on public.class_messages(discussion_id,created_at);

create table if not exists public.learning_resources (
 id uuid primary key default gen_random_uuid(),
 title text not null,
 description text not null default '',
 kind text not null check(kind in ('note','briefing')),
 body text not null default '',
 class_id uuid references public.classes(id) on delete cascade,
 course_id uuid references public.courses(id) on delete cascade,
 created_by uuid references auth.users(id),
 is_published boolean not null default false,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 check (class_id is not null or course_id is not null)
);
create index if not exists learning_resources_class_idx on public.learning_resources(class_id,kind,is_published);
create index if not exists learning_resources_course_idx on public.learning_resources(course_id,kind,is_published);

create table if not exists public.ai_chat_messages (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 role text not null check(role in ('user','assistant')),
 content text not null check(char_length(content) between 1 and 12000),
 created_at timestamptz not null default now()
);
create index if not exists ai_chat_user_created_idx on public.ai_chat_messages(user_id,created_at);

alter table public.class_discussions enable row level security;
alter table public.class_messages enable row level security;
alter table public.learning_resources enable row level security;
alter table public.ai_chat_messages enable row level security;

-- Discussion management: administrator or formateur affecté à la classe.
drop policy if exists class_discussions_read on public.class_discussions;
create policy class_discussions_read on public.class_discussions for select to authenticated using (
 public.is_staff() or exists(select 1 from public.class_memberships cm where cm.class_id=class_discussions.class_id and cm.student_id=auth.uid())
);
drop policy if exists class_discussions_manage on public.class_discussions;
create policy class_discussions_manage on public.class_discussions for all to authenticated using (
 exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin') or
 exists(select 1 from public.teacher_assignments ta where ta.class_id=class_discussions.class_id and ta.teacher_id=auth.uid() and ta.is_active)
) with check (
 exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin') or
 exists(select 1 from public.teacher_assignments ta where ta.class_id=class_discussions.class_id and ta.teacher_id=auth.uid() and ta.is_active)
);
drop policy if exists class_messages_read on public.class_messages;
create policy class_messages_read on public.class_messages for select to authenticated using (
 exists(select 1 from public.class_discussions d where d.id=discussion_id and (
 exists(select 1 from public.class_memberships cm where cm.class_id=d.class_id and cm.student_id=auth.uid()) or
 exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin') or
 exists(select 1 from public.teacher_assignments ta where ta.class_id=d.class_id and ta.teacher_id=auth.uid() and ta.is_active)
 ))
);
drop policy if exists class_messages_insert on public.class_messages;
create policy class_messages_insert on public.class_messages for insert to authenticated with check (
 sender_id=auth.uid() and exists(select 1 from public.class_discussions d where d.id=discussion_id and d.is_open and (
 exists(select 1 from public.class_memberships cm where cm.class_id=d.class_id and cm.student_id=auth.uid()) or
 exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin') or
 exists(select 1 from public.teacher_assignments ta where ta.class_id=d.class_id and ta.teacher_id=auth.uid() and ta.is_active)
 ))
);

drop policy if exists learning_resources_read on public.learning_resources;
create policy learning_resources_read on public.learning_resources for select to authenticated using (
 (is_published and (class_id is null or exists(select 1 from public.class_memberships cm where cm.class_id=learning_resources.class_id and cm.student_id=auth.uid()))) or public.is_staff()
);
drop policy if exists learning_resources_manage on public.learning_resources;
create policy learning_resources_manage on public.learning_resources for all to authenticated using (public.is_staff()) with check (public.is_staff());

drop policy if exists ai_chat_own on public.ai_chat_messages;
create policy ai_chat_own on public.ai_chat_messages for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());

grant select,insert,update,delete on public.class_discussions to authenticated;
grant select,insert on public.class_messages to authenticated;
grant select,insert,update,delete on public.learning_resources to authenticated;
grant select,insert,delete on public.ai_chat_messages to authenticated;

-- Realtime for class messages
DO $$ BEGIN
 if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='class_messages') then
  alter publication supabase_realtime add table public.class_messages;
 end if;
END $$;
