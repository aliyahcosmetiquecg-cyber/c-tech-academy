-- Déjà appliquée sur le projet de production C-TECH Academy.
-- Enregistre une classe et ses associations filières en une transaction.
create or replace function public.admin_save_class(
  p_class_id uuid, p_name text, p_academic_year text, p_description text,
  p_domain_id uuid, p_level_code text, p_filiere_ids uuid[]
) returns uuid
language plpgsql security definer set search_path = '' as $$
declare v_id uuid; v_first uuid;
begin
  if public.current_role() <> 'admin' then raise exception 'Droits administrateur requis' using errcode='42501'; end if;
  if coalesce(array_length(p_filiere_ids,1),0)=0 then raise exception 'Au moins une filière est obligatoire'; end if;
  if exists (select 1 from unnest(p_filiere_ids) x(id) left join public.filieres f on f.id=x.id where f.id is null or f.domain_id<>p_domain_id) then raise exception 'Toutes les filières doivent appartenir au domaine sélectionné'; end if;
  v_first:=p_filiere_ids[1];
  if p_class_id is null then
    insert into public.classes(name,academic_year,description,domain_id,level_code,filiere_id) values(p_name,p_academic_year,p_description,p_domain_id,p_level_code,v_first) returning id into v_id;
  else
    update public.classes set name=p_name,academic_year=p_academic_year,description=p_description,domain_id=p_domain_id,level_code=p_level_code,filiere_id=v_first where id=p_class_id returning id into v_id;
    if v_id is null then raise exception 'Classe introuvable'; end if;
  end if;
  delete from public.class_filieres where class_id=v_id;
  insert into public.class_filieres(class_id,filiere_id) select v_id,x.id from unnest(p_filiere_ids) x(id) on conflict(class_id,filiere_id) do nothing;
  return v_id;
end; $$;
revoke all on function public.admin_save_class(uuid,text,text,text,uuid,text,uuid[]) from public;
grant execute on function public.admin_save_class(uuid,text,text,text,uuid,text,uuid[]) to authenticated;
