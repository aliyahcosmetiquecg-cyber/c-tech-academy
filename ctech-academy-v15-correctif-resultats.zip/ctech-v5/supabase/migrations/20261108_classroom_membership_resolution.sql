create or replace function public.user_can_access_class(p_class_id uuid)
returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.profiles p join public.classes c on c.id=p_class_id where p.id=auth.uid() and (
  p.role='admin' or
  (p.role='teacher' and exists(select 1 from public.teacher_assignments ta where ta.class_id=c.id and ta.teacher_id=p.id and ta.is_active)) or
  (p.role='student' and (exists(select 1 from public.class_memberships cm where cm.class_id=c.id and cm.student_id=p.id) or
   (p.domain_id=c.domain_id and p.level_code=c.level_code and (c.academic_year is null or p.academic_year=c.academic_year) and
   (p.filiere_id=c.filiere_id or exists(select 1 from public.class_filieres cf where cf.class_id=c.id and cf.filiere_id=p.filiere_id))))
 ));
$$;
revoke all on function public.user_can_access_class(uuid) from public,anon;
grant execute on function public.user_can_access_class(uuid) to authenticated;
drop policy if exists class_discussions_read on public.class_discussions;
create policy class_discussions_read on public.class_discussions for select to authenticated using (public.user_can_access_class(class_id));
drop policy if exists class_messages_read on public.class_messages;
create policy class_messages_read on public.class_messages for select to authenticated using (exists(select 1 from public.class_discussions d where d.id=discussion_id and public.user_can_access_class(d.class_id)));
drop policy if exists class_messages_insert on public.class_messages;
create policy class_messages_insert on public.class_messages for insert to authenticated with check (sender_id=auth.uid() and exists(select 1 from public.class_discussions d where d.id=discussion_id and d.is_open and public.user_can_access_class(d.class_id)));
