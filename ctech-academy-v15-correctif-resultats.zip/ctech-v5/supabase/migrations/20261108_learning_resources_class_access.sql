drop policy if exists learning_resources_read on public.learning_resources;
create policy learning_resources_read on public.learning_resources for select to authenticated using (public.is_staff() or (is_published and (class_id is null or public.user_can_access_class(class_id))));
