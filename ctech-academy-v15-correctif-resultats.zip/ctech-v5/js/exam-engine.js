/* C-TECH Academy — moteur étudiant relié aux RPC Supabase sécurisées. */
(function () {
  'use strict';

  const state = { client:null, attempt:null, starting:false, questions:[], answers:{}, index:0, timer:null, saving:new Map(), submitting:false, root:null };
  const esc = (v = '') => String(v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const isText = q => /short|text|essay|written|open|redaction|rédaction/i.test(q.question_type || '');
  const isMulti = q => /multi|checkbox|multiple_select/i.test(q.question_type || '');
  const getOptionValue = option => {
    if (option && typeof option === 'object' && !Array.isArray(option)) {
      for (const k of ['value','id','key','code','label','text']) if (option[k] !== undefined) return option[k];
    }
    return option;
  };
  const getOptionLabel = option => {
    if (option && typeof option === 'object' && !Array.isArray(option)) return option.label ?? option.text ?? option.title ?? option.value ?? option.id ?? JSON.stringify(option);
    return option;
  };
  const notify = msg => {
    if (typeof window.toast === 'function') window.toast(msg);
    else if (state.root) state.root.dispatchEvent(new CustomEvent('ctech:message', { bubbles: true, detail: msg }));
  };

  function setClient(client) { state.client = client; }
  function getRoot(target) {
    const root = typeof target === 'string' ? document.querySelector(target) : target;
    if (!root) throw new Error('Zone d’affichage de l’épreuve introuvable.');
    state.root = root;
    return root;
  }

  async function start(assessmentId, target, assessmentMeta = null) {
    state.starting = true;
    state.assessmentMeta = assessmentMeta || null;
    try {
      if (!state.client) throw new Error('Client Supabase non configuré. Appelez CTECHExam.configure(sb).');
      const root = getRoot(target);
      root.innerHTML = '<div class="ctech-exam-loading"><i class="fa-solid fa-spinner fa-spin"></i><p>Préparation sécurisée de votre épreuve…</p></div>';
      const { data, error } = await state.client.rpc('student_start_attempt', { p_assessment_id: assessmentId });
      if (error) throw error;
      if (!data || !data.attempt_id || !Array.isArray(data.questions) || !data.questions.length) throw new Error('Aucune question n’a été attribuée à cette tentative.');
      state.attempt = data;
      state.starting = false;
      state.questions = data.questions;
      state.index = 0;
      state.answers = {};
      (data.saved_answers || []).forEach(row => { state.answers[row.question_id] = row.answer; });
      state.submitting = false;
      window.onbeforeunload = () => 'Une évaluation est en cours. Vos réponses sont enregistrées, mais veuillez terminer avant de quitter.';
      render();
      clearInterval(state.timer);
      state.timer = setInterval(tick, 1000);
      tick();
    } catch (err) {
      state.starting = false;
      if (state.root) state.root.innerHTML = `<div class="ctech-exam-error"><i class="fa-solid fa-circle-exclamation"></i><p>${esc(err.message || 'Impossible de démarrer cette épreuve.')}</p></div>`;
    }
  }

  function remainingSeconds() {
    const deadline = new Date(state.attempt.deadline_at).getTime();
    return Math.max(0, Math.floor((deadline - Date.now()) / 1000));
  }
  function formatTime(s) { return `${String(Math.floor(s / 60)).padStart(2,'0')}:${String(s % 60).padStart(2,'0')}`; }
  function tick() {
    if (!state.attempt) return;
    const left = remainingSeconds();
    const el = state.root?.querySelector('[data-exam-timer]');
    if (el) { el.textContent = formatTime(left); el.classList.toggle('is-urgent', left <= 300); }
    if (left <= 0) submit(true);
  }

  function optionHtml(q, option, idx) {
    const value = getOptionValue(option);
    const current = state.answers[q.id];
    const checked = isMulti(q) ? Array.isArray(current) && current.some(v => JSON.stringify(v) === JSON.stringify(value)) : JSON.stringify(current) === JSON.stringify(value);
    const inputType = isMulti(q) ? 'checkbox' : 'radio';
    const label = getOptionLabel(option);
    return `<label class="ctech-exam-option"><input type="${inputType}" name="answer-${esc(q.id)}" value="${idx}" data-option-index="${idx}" ${checked ? 'checked' : ''}><span>${esc(label)}</span></label>`;
  }

  function render() {
    const q = state.questions[state.index];
    if (!q || !state.root) return;
    const a = state.attempt.assessment || {};
    const answer = state.answers[q.id];
    const options = Array.isArray(q.options) ? q.options : [];
    const input = isText(q)
      ? `<textarea class="ctech-exam-text" data-text-answer rows="6" placeholder="Rédigez votre réponse…">${esc(answer ?? '')}</textarea>`
      : options.map((o,i) => optionHtml(q,o,i)).join('') || '<p class="ctech-exam-muted">Aucune option disponible pour cette question.</p>';
    const nav = state.questions.map((item,i) => `<button type="button" class="ctech-exam-dot ${i===state.index?'active':''} ${state.answers[item.id]!==undefined && state.answers[item.id]!==null && state.answers[item.id]!==''?'answered':''}" data-jump="${i}" aria-label="Question ${i+1}">${i+1}</button>`).join('');
    state.root.innerHTML = `
      <section class="ctech-exam-shell">
        <header class="ctech-exam-header"><div><span class="ctech-exam-kicker">ÉVALUATION EN COURS</span><h2>${esc(a.title || 'Évaluation')}</h2><p>${state.questions.length} questions · ${Number(a.total_points || 0)} points</p></div><div class="ctech-exam-clock"><i class="fa-regular fa-clock"></i><strong data-exam-timer>--:--</strong></div></header>
        <div class="ctech-exam-progress"><span style="width:${((state.index+1)/state.questions.length)*100}%"></span></div>
        <div class="ctech-exam-layout"><aside class="ctech-exam-sidebar"><strong>Navigation</strong><div class="ctech-exam-dots">${nav}</div><small>${Object.keys(state.answers).length} réponse(s) enregistrée(s)</small></aside>
          <article class="ctech-exam-question"><div class="ctech-exam-question-meta"><span>QUESTION ${state.index+1} / ${state.questions.length}</span><b>${esc(q.points)} point(s)</b></div><h3>${esc(q.prompt)}</h3><div class="ctech-exam-answer">${input}</div><div class="ctech-exam-save-state" data-save-state>Vos réponses sont enregistrées au fur et à mesure.</div>
          <footer class="ctech-exam-actions"><button type="button" class="ctech-exam-btn secondary" data-prev ${state.index===0?'disabled':''}>Précédent</button><button type="button" class="ctech-exam-btn primary" data-next ${state.index===state.questions.length-1?'hidden':''}>Suivant <i class="fa-solid fa-arrow-right"></i></button><button type="button" class="ctech-exam-btn submit" data-submit ${state.index!==state.questions.length-1?'hidden':''}>Soumettre l’épreuve</button></footer></article>
        </div><p class="ctech-exam-footnote"><i class="fa-solid fa-shield-halved"></i> Ne quittez pas la page avant la soumission. Votre progression est sauvegardée sur le serveur.</p>
      </section>`;
    state.root.querySelector('[data-prev]')?.addEventListener('click', () => move(-1));
    state.root.querySelector('[data-next]')?.addEventListener('click', () => move(1));
    state.root.querySelector('[data-submit]')?.addEventListener('click', () => {
      if (confirm('Confirmer la soumission définitive de votre épreuve ? Cette action est irréversible.')) submit(false);
    });
    state.root.querySelectorAll('[data-jump]').forEach(b => b.addEventListener('click', () => { state.index = Number(b.dataset.jump); render(); }));
    const textarea = state.root.querySelector('[data-text-answer]');
    if (textarea) textarea.addEventListener('input', () => saveCurrent(textarea.value, true));
    state.root.querySelectorAll('[data-option-index]').forEach(el => el.addEventListener('change', () => {
      const idx = Number(el.dataset.optionIndex), value = getOptionValue(options[idx]);
      if (isMulti(q)) {
        const list = Array.isArray(state.answers[q.id]) ? [...state.answers[q.id]] : [];
        const at = list.findIndex(v => JSON.stringify(v) === JSON.stringify(value));
        if (el.checked && at < 0) list.push(value);
        if (!el.checked && at >= 0) list.splice(at,1);
        saveCurrent(list, false);
      } else saveCurrent(value, false);
    }));
  }

  function move(delta) {
    if (!state.attempt) return;
    state.index = Math.max(0, Math.min(state.questions.length-1, state.index+delta));
    render();
  }

  async function saveCurrent(value, debounce) {
    const q = state.questions[state.index];
    if (!q) return;
    state.answers[q.id] = value;
    const status = state.root?.querySelector('[data-save-state]');
    if (status) status.textContent = 'Enregistrement…';
    const old = state.saving.get(q.id);
    if (old) clearTimeout(old);
    const run = async () => {
      try {
        const { error } = await state.client.rpc('student_save_answer', {
          p_attempt_id: state.attempt.attempt_id,
          p_question_id: q.id,
          p_answer: value === undefined ? null : value
        });
        if (error) throw error;
        const live = state.root?.querySelector('[data-save-state]');
        if (live) live.textContent = 'Réponse enregistrée.';
      } catch (err) {
        const live = state.root?.querySelector('[data-save-state]');
        if (live) live.textContent = `Échec de sauvegarde : ${err.message}`;
      }
    };
    if (debounce) state.saving.set(q.id, setTimeout(run, 450));
    else { state.saving.delete(q.id); await run(); }
  }

  async function flushSaves() {
    for (const timer of state.saving.values()) clearTimeout(timer);
    state.saving.clear();
    const pending = state.questions.filter(q => Object.prototype.hasOwnProperty.call(state.answers,q.id));
    for (const q of pending) {
      const { error } = await state.client.rpc('student_save_answer', {
        p_attempt_id: state.attempt.attempt_id, p_question_id: q.id, p_answer: state.answers[q.id]
      });
      if (error) throw error;
    }
  }

  async function submit(auto) {
    if (!state.attempt || state.submitting) return;
    state.submitting = true;
    clearInterval(state.timer);
    state.root.innerHTML = '<div class="ctech-exam-loading"><i class="fa-solid fa-spinner fa-spin"></i><p>Soumission et correction sécurisées de votre copie…</p></div>';
    try {
      if (!auto) await flushSaves();
      const { data, error } = await state.client.rpc('student_submit_attempt', { p_attempt_id: state.attempt.attempt_id });
      if (error) throw error;
      window.onbeforeunload = null;
      state.root.innerHTML = `<section class="ctech-exam-finish"><div class="ctech-exam-finish-icon"><i class="fa-solid fa-check"></i></div><span class="ctech-exam-kicker">ÉPREUVE SOUMISE</span><h2>${auto ? 'Temps écoulé : votre copie a été soumise.' : 'Votre épreuve a bien été soumise.'}</h2><p>Préparation de votre bilan…</p></section>`;
      state.attempt = null;
      state.starting = false;
      if (typeof window.CTECHExam.onSubmitted === 'function') {
        await window.CTECHExam.onSubmitted(data, state.assessmentMeta, { auto });
      } else {
        state.root.innerHTML += '<p>Votre copie a bien été enregistrée.</p>';
      }
    } catch (err) {
      state.submitting = false;
      if (state.attempt) { window.onbeforeunload = () => 'Une évaluation est en cours. Veuillez terminer avant de quitter.'; clearInterval(state.timer); state.timer = setInterval(tick,1000); }
      state.root.innerHTML = `<div class="ctech-exam-error"><i class="fa-solid fa-triangle-exclamation"></i><p>${esc(err.message || 'La soumission a échoué. Réessayez.')}</p><button type="button" class="ctech-exam-btn primary" data-retry>Réessayer</button></div>`;
      state.root.querySelector('[data-retry]')?.addEventListener('click', () => submit(auto));
    }
  }

  window.CTECHExam = { configure:setClient, start, onExit:null, onSubmitted:null, isActive:() => !!(state.starting || state.attempt), getAttempt:() => state.attempt };
})();
